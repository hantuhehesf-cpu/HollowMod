package com.hollowmod.client.dev;

import com.hollowmod.client.visual.VisualMath;
import com.hollowmod.dev.HollowInfo;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.UUID;

/**
 * Isometric map of the world on a white plane. Every Hollow the server knows about is drawn as a glowing sphere with a
 * shadow on the ground. Click one to open its control panel. Controls:
 *  - drag with the mouse to move, mouse wheel or the +/- buttons to zoom, the rotate buttons turn the view
 *  - middle click (or the "Pick centre" button then a click) moves the centre of the view to that point
 *  - "Pick" modes (set by actions like Overflow) let you click a spot on the ground
 */
public final class HollowMapView {

    public enum Pick { NONE, OVERFLOW, MOVE }

    private static final double IX = 0.70711;
    private static final double IY = 0.40825;
    private static final double IZ = 0.81650;
    private static final double[] GRID_STEPS = {10, 20, 50, 100, 200, 500, 1000, 2000, 5000, 10000, 20000, 50000, 100000};

    private int x;
    private int y;
    private int w;
    private int h;
    private int midX;
    private int midY;

    private double cx = 0.0;
    private double cz = 0.0;
    private float scale = 0.45f;
    private int rot = 0;
    private double planeY = 63.0;
    private boolean initialised = false;

    private Pick pick = Pick.NONE;
    private UUID pickFor = null;
    private boolean pickCenterMode = false;

    private boolean dragging = false;
    private double dragMoved = 0.0;
    private double lastMx = 0;
    private double lastMy = 0;

    // panel
    private final Rows.RowList panelList = new Rows.RowList();
    private UUID panelFor = null;
    private int panelX;
    private int panelW;
    private boolean panelOpen = false;

    private final List<Widgets.Button> buttons = new ArrayList<>();
    private final DevMenuScreen screen;

    // temp projection result
    private double psx;
    private double psy;
    private double pdepth;

    public HollowMapView(DevMenuScreen screen) {
        this.screen = screen;
        buttons.add(new Widgets.Button("+", Widgets.Button.Style.SECONDARY, () -> zoom(1.35f)));
        buttons.add(new Widgets.Button("-", Widgets.Button.Style.SECONDARY, () -> zoom(1.0f / 1.35f)));
        buttons.add(new Widgets.Button("<", Widgets.Button.Style.SECONDARY, () -> rot = (rot + 3) % 4));
        buttons.add(new Widgets.Button(">", Widgets.Button.Style.SECONDARY, () -> rot = (rot + 1) % 4));
        buttons.add(new Widgets.Button("Me", Widgets.Button.Style.SECONDARY, this::centerOnPlayer));
        buttons.add(new Widgets.Button("Target", Widgets.Button.Style.SECONDARY, this::centerOnTarget));
        buttons.add(new Widgets.Button("Fit", Widgets.Button.Style.SECONDARY, this::fitAll));
        buttons.add(new Widgets.Button(() -> pickCenterMode ? "Click map..." : "Pick centre", Widgets.Button.Style.SECONDARY,
                () -> pickCenterMode = !pickCenterMode));
    }

    // ------------------------------------------------------------------ public control

    public void startPick(Pick mode, UUID forHollow) {
        this.pick = mode;
        this.pickFor = forHollow;
    }

    public boolean isPicking() {
        return pick != Pick.NONE;
    }

    public void cancelPick() {
        pick = Pick.NONE;
        pickFor = null;
        pickCenterMode = false;
    }

    public void select(UUID id) {
        ClientHollows.selected = id;
    }

    private void zoom(float f) {
        scale = Math.max(0.004f, Math.min(6.0f, scale * f));
    }

    private void centerOnPlayer() {
        ClientPlayerEntity p = MinecraftClient.getInstance().player;
        if (p != null) {
            cx = p.getX();
            cz = p.getZ();
        }
    }

    private void centerOnTarget() {
        HollowInfo t = ClientHollows.target();
        if (t != null) {
            cx = t.x;
            cz = t.z;
            planeY = t.y;
        }
    }

    private void fitAll() {
        List<HollowInfo> list = visibleHollows();
        ClientPlayerEntity p = MinecraftClient.getInstance().player;
        double minX = Double.MAX_VALUE;
        double maxX = -Double.MAX_VALUE;
        double minZ = Double.MAX_VALUE;
        double maxZ = -Double.MAX_VALUE;
        for (HollowInfo hi : list) {
            minX = Math.min(minX, hi.x - hi.radius);
            maxX = Math.max(maxX, hi.x + hi.radius);
            minZ = Math.min(minZ, hi.z - hi.radius);
            maxZ = Math.max(maxZ, hi.z + hi.radius);
        }
        if (p != null) {
            minX = Math.min(minX, p.getX());
            maxX = Math.max(maxX, p.getX());
            minZ = Math.min(minZ, p.getZ());
            maxZ = Math.max(maxZ, p.getZ());
        }
        if (minX > maxX) {
            return;
        }
        cx = (minX + maxX) * 0.5;
        cz = (minZ + maxZ) * 0.5;
        double span = Math.max(Math.max(maxX - minX, maxZ - minZ), 80.0);
        scale = (float) Math.max(0.004, Math.min(2.0, Math.min(w, h) * 0.55 / span));
    }

    private void init() {
        initialised = true;
        HollowInfo t = ClientHollows.nearestInDimension();
        ClientPlayerEntity p = MinecraftClient.getInstance().player;
        if (p != null) {
            cx = p.getX();
            cz = p.getZ();
            planeY = p.getY() - 1.0;
        }
        if (t != null && !ClientHollows.all().isEmpty()) {
            fitAll();
        }
    }

    // ------------------------------------------------------------------ projection

    private void project(double wx, double wy, double wz) {
        double dx = wx - cx;
        double dz = wz - cz;
        double rx;
        double rz;
        switch (rot) {
            case 1 -> {
                rx = -dz;
                rz = dx;
            }
            case 2 -> {
                rx = -dx;
                rz = -dz;
            }
            case 3 -> {
                rx = dz;
                rz = -dx;
            }
            default -> {
                rx = dx;
                rz = dz;
            }
        }
        psx = midX + (rx - rz) * scale * IX;
        psy = midY + (rx + rz) * scale * IY - (wy - planeY) * scale * IZ;
        pdepth = rx + rz;
    }

    /** Screen point -> world x/z on the ground plane. */
    private double[] unproject(double sx, double sy) {
        double u = (sx - midX) / (scale * IX);
        double v = (sy - midY) / (scale * IY);
        double rx = (u + v) * 0.5;
        double rz = (v - u) * 0.5;
        double dx;
        double dz;
        switch (rot) {
            case 1 -> {
                dx = rz;
                dz = -rx;
            }
            case 2 -> {
                dx = -rx;
                dz = -rz;
            }
            case 3 -> {
                dx = -rz;
                dz = rx;
            }
            default -> {
                dx = rx;
                dz = rz;
            }
        }
        return new double[]{cx + dx, cz + dz};
    }

    private List<HollowInfo> visibleHollows() {
        MinecraftClient mc = MinecraftClient.getInstance();
        String dim = mc.world == null ? "" : mc.world.getRegistryKey().getValue().toString();
        List<HollowInfo> list = new ArrayList<>();
        for (HollowInfo hi : ClientHollows.all()) {
            if (dim.equals(hi.dim)) {
                list.add(hi);
            }
        }
        return list;
    }

    // ------------------------------------------------------------------ layout

    public void layout(int x, int y, int w, int h) {
        this.x = x;
        this.y = y;
        this.w = w;
        this.h = h;
        panelOpen = ClientHollows.get(ClientHollows.selected) != null;
        panelW = Math.min(250, (int) (w * 0.48));
        panelX = x + w - panelW;
        int usable = panelOpen ? w - panelW : w;
        midX = x + usable / 2;
        midY = y + h / 2;
        if (!initialised && w > 0) {
            init();
        }
    }

    // ------------------------------------------------------------------ rendering

    public void render(DrawContext c, TextRenderer tr, int mx, int my, float dt) {
        List<HollowInfo> hollows = visibleHollows();
        float time = (System.currentTimeMillis() % 100000L) / 1000.0f;

        c.enableScissor(x, y, x + w, y + h);
        c.fillGradient(x, y, x + w, y + h, 0xFFF8FAFD, 0xFFE4EAF4);

        Ui.beginRaw(c);
        drawGrid(c);
        // parent -> child links
        List<float[]> links = new ArrayList<>();
        for (HollowInfo hi : hollows) {
            HollowInfo parent = ClientHollows.get(hi.parent);
            if (parent != null && parent.dim.equals(hi.dim)) {
                project(parent.x, planeY, parent.z);
                double ax = psx;
                double ay = psy;
                project(hi.x, planeY, hi.z);
                links.add(new float[]{(float) ax, (float) ay, (float) psx, (float) psy});
            }
        }
        Ui.lines(c, links, 1.6f, 0x907A60D0);

        // sort far -> near
        List<float[]> order = new ArrayList<>();
        for (int i = 0; i < hollows.size(); i++) {
            HollowInfo hi = hollows.get(i);
            project(hi.x, hi.y, hi.z);
            order.add(new float[]{i, (float) pdepth});
        }
        order.sort((a, b) -> Float.compare(a[1], b[1]));

        UUID hoverId = hollowAt(mx, my, hollows);
        for (float[] o : order) {
            drawHollow(c, hollows.get((int) o[0]), time, hoverId);
        }
        Ui.endRaw();

        // text and small markers (normal GUI drawing)
        for (float[] o : order) {
            drawLabel(c, tr, hollows.get((int) o[0]));
        }
        drawPlayer(c, tr);
        drawOrigin(c, tr);

        if (pick != Pick.NONE || pickCenterMode) {
            drawPickOverlay(c, tr, mx, my);
        } else if (hoverId != null && Ui.in(mx, my, x, y, w, h) && !(panelOpen && mx >= panelX)) {
            drawTooltip(c, tr, ClientHollows.get(hoverId), mx, my);
        }
        c.disableScissor();

        drawHud(c, tr, mx, my, dt);
        if (panelOpen) {
            drawPanel(c, tr, mx, my, dt);
        }
    }

    private void drawGrid(DrawContext c) {
        double[] a = unproject(x, y);
        double[] b = unproject(x + w, y);
        double[] d = unproject(x, y + h);
        double[] e = unproject(x + w, y + h);
        double minX = Math.min(Math.min(a[0], b[0]), Math.min(d[0], e[0]));
        double maxX = Math.max(Math.max(a[0], b[0]), Math.max(d[0], e[0]));
        double minZ = Math.min(Math.min(a[1], b[1]), Math.min(d[1], e[1]));
        double maxZ = Math.max(Math.max(a[1], b[1]), Math.max(d[1], e[1]));
        double span = Math.max(maxX - minX, maxZ - minZ);
        double step = GRID_STEPS[GRID_STEPS.length - 1];
        for (double s : GRID_STEPS) {
            if (span / s <= 26.0) {
                step = s;
                break;
            }
        }
        List<float[]> minor = new ArrayList<>();
        List<float[]> major = new ArrayList<>();
        int count = 0;
        for (double gx = Math.floor(minX / step) * step; gx <= maxX && count < 90; gx += step, count++) {
            project(gx, planeY, minZ);
            float x1 = (float) psx;
            float y1 = (float) psy;
            project(gx, planeY, maxZ);
            float[] seg = {x1, y1, (float) psx, (float) psy};
            (Math.round(gx / step) % 5 == 0 ? major : minor).add(seg);
        }
        count = 0;
        for (double gz = Math.floor(minZ / step) * step; gz <= maxZ && count < 90; gz += step, count++) {
            project(minX, planeY, gz);
            float x1 = (float) psx;
            float y1 = (float) psy;
            project(maxX, planeY, gz);
            float[] seg = {x1, y1, (float) psx, (float) psy};
            (Math.round(gz / step) % 5 == 0 ? major : minor).add(seg);
        }
        Ui.lines(c, minor, 1.0f, 0x2C5A6C90);
        Ui.lines(c, major, 1.4f, 0x585A6C90);

        // world axes through 0,0 (X in blue, Z in pink)
        List<float[]> ax = new ArrayList<>();
        project(minX, planeY, 0);
        float ax1 = (float) psx;
        float ay1 = (float) psy;
        project(maxX, planeY, 0);
        ax.add(new float[]{ax1, ay1, (float) psx, (float) psy});
        Ui.lines(c, ax, 2.0f, 0x886C8CFF);
        List<float[]> az = new ArrayList<>();
        project(0, planeY, minZ);
        float az1 = (float) psx;
        float az2 = (float) psy;
        project(0, planeY, maxZ);
        az.add(new float[]{az1, az2, (float) psx, (float) psy});
        Ui.lines(c, az, 2.0f, 0x88FF7AC8);
        gridStep = step;
    }

    private double gridStep = 100.0;

    private int hue(HollowInfo hi, float time, float offset) {
        float[] rgb = new float[3];
        VisualMath.hsv(205.0f + hi.generation * 38.0f + time * 12.0f + offset, 0.62f, 1.0f, rgb);
        return 0xFF000000 | (VisualMath.to255(rgb[0]) << 16) | (VisualMath.to255(rgb[1]) << 8) | VisualMath.to255(rgb[2]);
    }

    private void drawHollow(DrawContext c, HollowInfo hi, float time, UUID hoverId) {
        float rad = ClientHollows.smoothRadius(hi);
        float r = Math.max(5.0f, rad * scale);
        float fade = hi.loaded ? 1.0f : 0.42f;

        project(hi.x, planeY, hi.z);
        float shx = (float) psx;
        float shy = (float) psy;
        project(hi.x, hi.y, hi.z);
        float sx = (float) psx;
        float sy = (float) psy;

        // ground shadow and a thin line down to it
        Ui.ellipse(c, shx, shy, r * 1.05f, r * 0.60f, Ui.fade(0x40506088, fade), 0x00506088);
        if (Math.abs(sy - shy) > r * 0.9f) {
            Ui.line(c, sx, sy + r * 0.8f, shx, shy, 1.0f, Ui.fade(0x607080B0, fade));
        }

        // body, rim, glow, highlight
        Ui.ellipse(c, sx, sy, r, r, Ui.fade(0xFF2F2A66, fade), Ui.fade(0xFF100E2A, fade));
        int rim = hue(hi, time, 0.0f);
        Ui.ring(c, sx, sy, r * 0.84f, r * 0.84f, r, r, Ui.fade(rim & 0x00FFFFFF, fade), Ui.fade(rim, fade));
        int glow = hue(hi, time, 70.0f);
        Ui.ring(c, sx, sy, r, r, r * 1.2f, r * 1.2f, Ui.fade((glow & 0x00FFFFFF) | 0x80000000, fade), glow & 0x00FFFFFF);
        Ui.ellipse(c, sx - r * 0.32f, sy - r * 0.38f, r * 0.26f, r * 0.20f, Ui.fade(0x70FFFFFF, fade), 0x00FFFFFF);

        // growth progress ring (radius / max radius)
        if (hi.maxRadius > 0.5f && r > 9.0f) {
            double ratio = Math.max(0.0, Math.min(1.0, rad / hi.maxRadius));
            Ui.arc(c, sx, sy, r * 1.26f, r * 1.32f, -Math.PI / 2, Math.PI * 1.5, 0x35000000);
            Ui.arc(c, sx, sy, r * 1.26f, r * 1.32f, -Math.PI / 2, -Math.PI / 2 + Math.PI * 2 * ratio,
                    Ui.fade(hi.frozen ? 0xFFFFC857 : 0xFF3DD6C0, fade));
        }
        if (hi.collapseTicks >= 0) {
            Ui.ring(c, sx, sy, r * 1.36f, r * 1.36f, r * 1.46f, r * 1.46f, 0xFFFF5C7A, 0x00FF5C7A);
        }

        boolean selected = hi.uuid.equals(ClientHollows.selected);
        if (selected) {
            Ui.ring(c, sx, sy, r * 1.50f, r * 1.50f, r * 1.58f + 2.0f, r * 1.58f + 2.0f, 0xFFFFFFFF, 0xFFFFFFFF);
        } else if (hi.uuid.equals(hoverId)) {
            Ui.ring(c, sx, sy, r * 1.40f, r * 1.40f, r * 1.46f + 1.5f, r * 1.46f + 1.5f, 0xFF7AA2FF, 0xFF7AA2FF);
        }
    }

    private void drawLabel(DrawContext c, TextRenderer tr, HollowInfo hi) {
        float rad = ClientHollows.smoothRadius(hi);
        float r = Math.max(5.0f, rad * scale);
        project(hi.x, hi.y, hi.z);
        int sx = (int) psx;
        int sy = (int) (psy + r * 1.45f + 4);
        String name = "H-" + hi.shortId() + (hi.generation > 0 ? "  gen " + hi.generation : "");
        int tw = tr.getWidth(name) + 8;
        Ui.rrect(c, sx - tw / 2, sy, tw, tr.fontHeight + 4, 3, 0xCC10152A);
        Ui.textCenter(c, tr, name, sx, sy + 3, hi.loaded ? 0xFFE8ECF8 : 0xFF8C95B0);
        // two small meters: activity and gauge
        int bw = 44;
        int by = sy + tr.fontHeight + 7;
        Ui.rrect(c, sx - bw / 2, by, bw, 3, 1, 0xAA1A2038);
        Ui.rrect(c, sx - bw / 2, by, Math.max(1, (int) (bw * hi.activity / 100.0f)), 3, 1, Ui.TEAL);
        Ui.rrect(c, sx - bw / 2, by + 5, bw, 3, 1, 0xAA1A2038);
        Ui.rrect(c, sx - bw / 2, by + 5, Math.max(1, (int) (bw * hi.gauge / 100.0f)), 3, 1, Ui.VIOLET);
        if (!hi.loaded) {
            Ui.textCenter(c, tr, "unloaded", sx, by + 12, 0xFF8C95B0);
        } else if (hi.collapseTicks >= 0) {
            int s = hi.collapseTicks / 20;
            Ui.textCenter(c, tr, "COLLAPSING " + (s / 60) + ":" + String.format("%02d", s % 60), sx, by + 12, 0xFFFF5C7A);
        } else if (hi.frozen) {
            Ui.textCenter(c, tr, "frozen", sx, by + 12, 0xFFFFC857);
        }
    }

    private void drawPlayer(DrawContext c, TextRenderer tr) {
        ClientPlayerEntity p = MinecraftClient.getInstance().player;
        if (p == null) {
            return;
        }
        project(p.getX(), p.getY(), p.getZ());
        float sx = (float) psx;
        float sy = (float) psy;
        // facing direction on the ground, turned by the view rotation
        double yaw = Math.toRadians(p.getYaw());
        double fx = -Math.sin(yaw);
        double fz = Math.cos(yaw);
        project(p.getX() + fx * 6.0 / Math.max(scale, 0.01), p.getY(), p.getZ() + fz * 6.0 / Math.max(scale, 0.01));
        float tx = (float) psx;
        float ty = (float) psy;
        float dx = tx - sx;
        float dy = ty - sy;
        float len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len < 0.01f) {
            dx = 0;
            dy = -1;
            len = 1;
        }
        dx /= len;
        dy /= len;
        Ui.beginRaw(c);
        Ui.ellipse(c, sx, sy + 2, 7, 4, 0x40000000, 0x00000000);
        Ui.triangle(c, sx + dx * 8, sy + dy * 8, sx - dy * 5 - dx * 4, sy + dx * 5 - dy * 4,
                sx + dy * 5 - dx * 4, sy - dx * 5 - dy * 4, 0xFF1FBFA8);
        Ui.endRaw();
        Ui.textCenter(c, tr, "You", (int) sx, (int) sy + 8, 0xFF0F7F70);
    }

    private void drawOrigin(DrawContext c, TextRenderer tr) {
        project(0, planeY, 0);
        if (Ui.in(psx, psy, x, y, w, h)) {
            c.fill((int) psx - 3, (int) psy, (int) psx + 4, (int) psy + 1, 0xFF6C8CFF);
            c.fill((int) psx, (int) psy - 3, (int) psx + 1, (int) psy + 4, 0xFF6C8CFF);
            Ui.text(c, tr, "0,0", (int) psx + 5, (int) psy + 2, 0xFF6C8CFF);
        }
    }

    private void drawPickOverlay(DrawContext c, TextRenderer tr, int mx, int my) {
        String msg = pickCenterMode ? "Click a point to move the centre of the view  -  right click or Esc to cancel"
                : (pick == Pick.OVERFLOW ? "Click where the companion Hollow should appear  -  right click or Esc to cancel"
                : "Click the new position of the Hollow  -  right click or Esc to cancel");
        int tw = tr.getWidth(msg) + 20;
        int bx = x + (w - tw) / 2;
        Ui.panel(c, bx, y + 10, tw, 20, 4, 0xF010152A, Ui.ACCENT);
        Ui.textCenter(c, tr, msg, bx + tw / 2, y + 17, 0xFFFFFFFF);
        if (Ui.in(mx, my, x, y, w, h) && !(panelOpen && mx >= panelX)) {
            double[] wp = unproject(mx, my);
            Ui.beginRaw(c);
            Ui.ring(c, mx, my, 9, 5, 12, 7, 0xFF7AA2FF, 0xFFB48CFF);
            Ui.endRaw();
            String coords = String.format(Locale.ROOT, "%.0f, %.0f", wp[0], wp[1]);
            Ui.textShadow(c, tr, coords, mx + 14, my + 8, 0xFF2A3D8F);
        }
    }

    private void drawTooltip(DrawContext c, TextRenderer tr, HollowInfo hi, int mx, int my) {
        if (hi == null) {
            return;
        }
        String[] lines = {
                "Hollow H-" + hi.shortId() + (hi.loaded ? "" : "  (unloaded)"),
                String.format(Locale.ROOT, "pos  %.0f, %.0f, %.0f", hi.x, hi.y, hi.z),
                String.format(Locale.ROOT, "radius  %.0f / %.0f", hi.radius, hi.maxRadius),
                String.format(Locale.ROOT, "activity %.0f%%   gauge %.0f%%", hi.activity, hi.gauge),
                "generation " + hi.generation + "   children " + hi.children
        };
        int tw = 0;
        for (String l : lines) {
            tw = Math.max(tw, tr.getWidth(l));
        }
        int th = lines.length * (tr.fontHeight + 2) + 8;
        int bx = Math.min(mx + 14, x + w - tw - 14);
        int by = Math.min(my + 14, y + h - th - 4);
        Ui.panel(c, bx, by, tw + 12, th, 4, 0xF2101521, Ui.BORDER);
        for (int i = 0; i < lines.length; i++) {
            Ui.text(c, tr, lines[i], bx + 6, by + 5 + i * (tr.fontHeight + 2), i == 0 ? Ui.TEXT : Ui.MUTED);
        }
    }

    private void drawHud(DrawContext c, TextRenderer tr, int mx, int my, float dt) {
        int bw = 22;
        int bh = 18;
        int bx = x + 8;
        int by = y + h - bh - 8;
        for (int i = 0; i < buttons.size(); i++) {
            Widgets.Button b = buttons.get(i);
            int width = i < 4 ? bw : (i == 7 ? 74 : 42);
            b.bounds(bx, by, width, bh);
            b.render(c, tr, mx, my, dt);
            bx += width + 4;
        }
        String info = "1 px = " + String.format(Locale.ROOT, "%.1f", 1.0 / scale) + " blocks   grid " + (int) gridStep
                + "   Hollows " + visibleHollows().size();
        Ui.text(c, tr, info, x + 10, y + 8, 0xFF5A627C);
        if (Ui.in(mx, my, x, y, w, h) && !(panelOpen && mx >= panelX)) {
            double[] wp = unproject(mx, my);
            Ui.text(c, tr, String.format(Locale.ROOT, "x %.0f   z %.0f", wp[0], wp[1]), x + 10, y + 8 + tr.fontHeight + 3, 0xFF5A627C);
        }
        if (!ClientHollows.allowed) {
            Ui.text(c, tr, "No dev permission: you can look, but actions will be refused.", x + 10, y + h - bh - 8 - 14, Ui.DANGER);
        }
    }

    // ------------------------------------------------------------------ detail panel

    private void drawPanel(DrawContext c, TextRenderer tr, int mx, int my, float dt) {
        HollowInfo hi = ClientHollows.get(ClientHollows.selected);
        if (hi == null) {
            return;
        }
        if (!hi.uuid.equals(panelFor)) {
            panelFor = hi.uuid;
            panelList.setRows(buildPanelRows(hi));
        }
        Ui.panel(c, panelX, y, panelW, h, 0, 0xF40C101C, Ui.BORDER);
        Ui.accentLine(c, panelX, y, panelW, 2, 255);
        Ui.textShadow(c, tr, "Hollow H-" + hi.shortId(), panelX + 10, y + 10, Ui.TEXT);
        Ui.text(c, tr, hi.loaded ? "loaded" : "not loaded", panelX + 10, y + 10 + tr.fontHeight + 2, hi.loaded ? Ui.GOOD : Ui.MUTED);
        boolean overClose = Ui.in(mx, my, panelX + panelW - 24, y + 8, 16, 16);
        Ui.panel(c, panelX + panelW - 24, y + 8, 16, 16, 3, overClose ? 0xFF5A1F30 : Ui.CARD, overClose ? Ui.DANGER : Ui.BORDER_SOFT);
        Ui.textCenter(c, tr, "x", panelX + panelW - 16, y + 12, overClose ? 0xFFFFFFFF : Ui.MUTED);
        panelList.bounds(panelX + 8, y + 36, panelW - 12, h - 42);
        panelList.render(c, tr, mx, my, dt);
    }

    private List<Rows.Row> buildPanelRows(HollowInfo first) {
        UUID id = first.uuid;
        List<Rows.Row> rows = new ArrayList<>();
        java.util.function.Supplier<HollowInfo> cur = () -> ClientHollows.get(id);

        rows.add(new Rows.Info("Family", () -> {
            HollowInfo h = cur.get();
            return h == null ? "-" : "gen " + h.generation + "   parent " + (h.parent.equals(HollowInfo.NONE) ? "none" : "H-" + h.parent.toString().substring(0, 8))
                    + "   kids " + h.children;
        }).compact());
        rows.add(new Rows.Info("Position", () -> {
            HollowInfo h = cur.get();
            return h == null ? "-" : String.format(Locale.ROOT, "%.0f, %.0f, %.0f", h.x, h.y, h.z);
        }).compact());
        rows.add(new Rows.Info("State", () -> {
            HollowInfo h = cur.get();
            if (h == null) {
                return "-";
            }
            String s = h.loaded ? "loaded" : "unloaded";
            if (h.kept) {
                s += ", kept";
            }
            if (h.frozen) {
                s += ", frozen";
            }
            if (h.collapseTicks >= 0) {
                s += ", collapsing " + (h.collapseTicks / 20) + "s";
            }
            return s;
        }).compact());

        rows.add(new Rows.Header("Size"));
        rows.add(new Rows.Slide("Size", 0, 256, 1, () -> valueOf(cur, h -> h.radius), v -> ClientHollows.action(id, "size", v), v -> Math.round(v) + "").compact());
        rows.add(new Rows.Slide("Max radius", 1, 512, 1, () -> valueOf(cur, h -> h.maxRadius), v -> ClientHollows.action(id, "maxradius", v), v -> Math.round(v) + "").compact());
        rows.add(new Rows.Slide("Interval", 1, 200, 1, () -> valueOf(cur, h -> h.growthInterval), v -> ClientHollows.action(id, "speed", v), v -> Math.round(v) + "t").compact());
        rows.add(new Rows.Switch("Freeze growth", () -> cur.get() != null && cur.get().frozen, on -> ClientHollows.action(id, "freeze", on ? 1 : 0)).compact());

        rows.add(new Rows.Header("Ether"));
        rows.add(new Rows.Slide("Activity", 0, 100, 1, () -> valueOf(cur, h -> h.activity), v -> ClientHollows.action(id, "activity", v), v -> Math.round(v) + "%").compact());
        rows.add(new Rows.Slide("Zenless gauge", 0, 100, 1, () -> valueOf(cur, h -> h.gauge), v -> ClientHollows.action(id, "gauge", v), v -> Math.round(v) + "%").compact());

        rows.add(new Rows.Header("Overflow"));
        rows.add(new Rows.Switch("Force (ignore caps)", DevPages::forceOverflow, DevPages::setForceOverflow).compact());
        rows.add(new Rows.Action("Overflow: random spot", "Trigger", Widgets.Button.Style.SECONDARY,
                () -> ClientHollows.action(id, "overflow", 0, 0, 0, DevPages.forceOverflow() ? "force" : "")).compact());
        rows.add(new Rows.Action("Overflow: pick spot", "Pick", Widgets.Button.Style.PRIMARY,
                () -> startPick(Pick.OVERFLOW, id)).compact());

        rows.add(new Rows.Header("Collapse"));
        rows.add(new Rows.Action("Start collapse (3-5 min)", "Start", Widgets.Button.Style.SECONDARY,
                () -> ClientHollows.action(id, "collapse", -1)).compact());
        rows.add(new Rows.Action("Cancel collapse", "Cancel", Widgets.Button.Style.SECONDARY,
                () -> ClientHollows.action(id, "collapse", -2)).compact());
        long[] armedCollapse = {0L};
        rows.add(new Rows.Action("Collapse now", () -> System.currentTimeMillis() < armedCollapse[0] ? "Confirm!" : "Collapse",
                Widgets.Button.Style.DANGER, () -> {
            if (System.currentTimeMillis() < armedCollapse[0]) {
                armedCollapse[0] = 0L;
                ClientHollows.action(id, "collapse", 0);
            } else {
                armedCollapse[0] = System.currentTimeMillis() + 3000L;
            }
        }).compact());

        rows.add(new Rows.Header("Position"));
        rows.add(new Rows.Inputs("Move to X Y Z", "Move", v -> {
            if (!Double.isNaN(v[0]) && !Double.isNaN(v[1]) && !Double.isNaN(v[2])) {
                ClientHollows.action(id, "move", v[0], v[1], v[2], "");
            } else {
                ClientHollows.log(true, "Fill in X, Y and Z to move the Hollow.");
            }
        }, new String[]{"X", "Y", "Z"}, new String[]{
                String.valueOf(Math.round(first.x)), String.valueOf(Math.round(first.y)), String.valueOf(Math.round(first.z))}).compact());
        rows.add(new Rows.Action("Move: pick spot on map", "Pick", Widgets.Button.Style.SECONDARY,
                () -> startPick(Pick.MOVE, id)).compact());
        rows.add(new Rows.Action("Teleport me next to it", "Teleport", Widgets.Button.Style.SECONDARY,
                () -> ClientHollows.action(id, "tp_me", 0)).compact());
        rows.add(new Rows.Action("Enter the Hollow", "Enter", Widgets.Button.Style.SECONDARY,
                () -> ClientHollows.action(id, "tp_enter", 0)).compact());
        rows.add(new Rows.Action("Centre the map on it", "Centre", Widgets.Button.Style.SECONDARY, () -> {
            HollowInfo h = cur.get();
            if (h != null) {
                cx = h.x;
                cz = h.z;
                planeY = h.y;
            }
        }).compact());

        rows.add(new Rows.Header("Creatures and loading"));
        rows.add(new Rows.Action("Swallow creatures now", "Swallow", Widgets.Button.Style.SECONDARY,
                () -> ClientHollows.action(id, "swallow", 0)).compact());
        rows.add(new Rows.Action("Spawn 8 test cows inside", "Spawn", Widgets.Button.Style.SECONDARY,
                () -> ClientHollows.action(id, "spawn_mobs", 8)).compact());
        rows.add(new Rows.Switch("Keep loaded", () -> cur.get() != null && cur.get().kept, on -> ClientHollows.action(id, "keep", on ? 1 : 0)).compact());

        rows.add(new Rows.Header("Danger"));
        long[] armedDelete = {0L};
        rows.add(new Rows.Action("Delete this Hollow", () -> System.currentTimeMillis() < armedDelete[0] ? "Confirm!" : "Delete",
                Widgets.Button.Style.DANGER, () -> {
            if (System.currentTimeMillis() < armedDelete[0]) {
                armedDelete[0] = 0L;
                ClientHollows.action(id, "delete", 0);
                ClientHollows.selected = null;
            } else {
                armedDelete[0] = System.currentTimeMillis() + 3000L;
            }
        }).compact());
        rows.add(new Rows.Action("Forget saved data (unloaded)", "Forget", Widgets.Button.Style.SECONDARY,
                () -> {
                    ClientHollows.action(id, "forget", 0);
                    ClientHollows.selected = null;
                }).compact());
        return rows;
    }

    private static double valueOf(java.util.function.Supplier<HollowInfo> cur, java.util.function.Function<HollowInfo, Number> f) {
        HollowInfo h = cur.get();
        return h == null ? 0.0 : f.apply(h).doubleValue();
    }

    // ------------------------------------------------------------------ input

    private UUID hollowAt(double mx, double my, List<HollowInfo> hollows) {
        UUID best = null;
        double bestDepth = -Double.MAX_VALUE;
        for (HollowInfo hi : hollows) {
            float r = Math.max(8.0f, ClientHollows.smoothRadius(hi) * scale);
            project(hi.x, hi.y, hi.z);
            double dx = mx - psx;
            double dy = my - psy;
            if (dx * dx + dy * dy <= r * r && pdepth > bestDepth) {
                bestDepth = pdepth;
                best = hi.uuid;
            }
        }
        return best;
    }

    public boolean mouseClicked(double mx, double my, int button) {
        if (!Ui.in(mx, my, x, y, w, h)) {
            return false;
        }
        if (panelOpen && mx >= panelX) {
            if (Ui.in(mx, my, panelX + panelW - 24, y + 8, 16, 16)) {
                ClientHollows.selected = null;
                panelFor = null;
                return true;
            }
            panelList.mouseClicked(mx, my, button);
            return true;
        }
        for (Widgets.Button b : buttons) {
            if (b.mouseClicked(mx, my, button)) {
                return true;
            }
        }
        if (button == 2) {
            double[] wp = unproject(mx, my);
            cx = wp[0];
            cz = wp[1];
            return true;
        }
        if (button == 1) {
            if (isPicking() || pickCenterMode) {
                cancelPick();
            } else {
                ClientHollows.selected = null;
            }
            return true;
        }
        if (button == 0) {
            if (pickCenterMode) {
                double[] wp = unproject(mx, my);
                cx = wp[0];
                cz = wp[1];
                pickCenterMode = false;
                return true;
            }
            if (pick != Pick.NONE) {
                completePick(mx, my);
                return true;
            }
            dragging = true;
            dragMoved = 0.0;
            lastMx = mx;
            lastMy = my;
            return true;
        }
        return true;
    }

    private void completePick(double mx, double my) {
        double[] wp = unproject(mx, my);
        HollowInfo hi = ClientHollows.get(pickFor);
        if (hi == null) {
            cancelPick();
            return;
        }
        if (pick == Pick.OVERFLOW) {
            ClientHollows.action(hi.uuid, "overflow", wp[0], wp[1], 1, DevPages.forceOverflow() ? "force" : "");
        } else if (pick == Pick.MOVE) {
            ClientHollows.action(hi.uuid, "move", wp[0], hi.y, wp[1], "");
        }
        pick = Pick.NONE;
        pickFor = null;
    }

    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (panelOpen && panelList.mouseDragged(mx, my, button, dx, dy)) {
            return true;
        }
        if (dragging && button == 0) {
            dragMoved += Math.abs(dx) + Math.abs(dy);
            // moving the picture by (dx,dy) pixels moves the centre by the opposite world amount
            double u = dx / (scale * IX);
            double v = dy / (scale * IY);
            double rx = (u + v) * 0.5;
            double rz = (v - u) * 0.5;
            double wx;
            double wz;
            switch (rot) {
                case 1 -> {
                    wx = rz;
                    wz = -rx;
                }
                case 2 -> {
                    wx = -rx;
                    wz = -rz;
                }
                case 3 -> {
                    wx = -rz;
                    wz = rx;
                }
                default -> {
                    wx = rx;
                    wz = rz;
                }
            }
            cx -= wx;
            cz -= wz;
            return true;
        }
        return false;
    }

    public boolean mouseReleased(double mx, double my, int button) {
        boolean used = panelList.mouseReleased(mx, my, button);
        if (dragging && button == 0) {
            dragging = false;
            if (dragMoved < 5.0) {
                UUID hit = hollowAt(mx, my, visibleHollows());
                ClientHollows.selected = hit;
                if (hit != null) {
                    panelFor = null; // rebuild panel rows for the new selection
                }
            }
            return true;
        }
        return used;
    }

    public boolean mouseScrolled(double mx, double my, double amount) {
        if (panelOpen && mx >= panelX) {
            return panelList.mouseScrolled(mx, my, amount);
        }
        if (Ui.in(mx, my, x, y, w, h)) {
            zoom((float) Math.pow(1.18, amount));
            return true;
        }
        return false;
    }

    /** Escape closes pick mode / selection first. Returns true if it used the key. */
    public boolean escape() {
        if (isPicking() || pickCenterMode) {
            cancelPick();
            return true;
        }
        if (ClientHollows.selected != null) {
            ClientHollows.selected = null;
            return true;
        }
        return false;
    }
}
