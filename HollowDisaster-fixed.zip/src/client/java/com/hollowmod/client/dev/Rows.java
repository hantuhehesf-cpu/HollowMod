package com.hollowmod.client.dev;

import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.DoubleConsumer;
import java.util.function.DoubleFunction;
import java.util.function.DoubleSupplier;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

/**
 * A row is one entry of a page: a card with a title, a short description and a control on the right.
 * Every row knows its words (title, description, tags), which is what the search bar looks through.
 */
public final class Rows {

    public abstract static class Row {
        public String title;
        public String desc = "";
        public String tags = "";
        public String section = "";
        protected int x;
        protected int y;
        protected int w;
        protected float hover = 0.0f;
        public boolean compact = false;

        protected Row(String title) {
            this.title = title;
        }

        public Row desc(String d) {
            this.desc = d;
            return this;
        }

        public Row tags(String t) {
            this.tags = t;
            return this;
        }

        public Row compact() {
            this.compact = true;
            return this;
        }

        public int height() {
            return compact ? 26 : 38;
        }

        public void layout(int x, int y, int w) {
            this.x = x;
            this.y = y;
            this.w = w;
        }

        /** Text the search bar matches against. */
        public String searchText() {
            return (title + " " + desc + " " + tags + " " + section).toLowerCase(Locale.ROOT);
        }

        public abstract void render(DrawContext c, TextRenderer tr, int mx, int my, float dt, boolean showSection);

        public boolean mouseClicked(double mx, double my, int button) {
            return false;
        }

        public boolean mouseReleased(double mx, double my, int button) {
            return false;
        }

        public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
            return false;
        }

        protected int controlWidth() {
            return 120;
        }

        /** Draws the card and the title/description. Returns the x where the control area starts. */
        protected int drawCard(DrawContext c, TextRenderer tr, int mx, int my, float dt, boolean showSection) {
            int h = height();
            boolean over = Ui.in(mx, my, x, y, w, h);
            hover += ((over ? 1.0f : 0.0f) - hover) * Math.min(1.0f, dt * 10.0f);
            Ui.panel(c, x, y, w, h, 3, Ui.lerp(Ui.CARD, Ui.CARD_HOVER, hover), Ui.lerp(Ui.BORDER_SOFT, Ui.BORDER, hover));
            int cx = x + w - controlWidth() - 8;
            int textW = Math.max(40, cx - x - 14);
            if (compact) {
                Ui.text(c, tr, Ui.fit(tr, title, textW), x + 8, y + (h - tr.fontHeight) / 2 + 1, Ui.TEXT);
            } else {
                String shownTitle = title;
                int tx = x + 8;
                if (showSection && !section.isEmpty()) {
                    String chip = section.toUpperCase(Locale.ROOT);
                    int cw = tr.getWidth(chip) + 6;
                    Ui.rrect(c, tx, y + 5, cw, tr.fontHeight + 3, 2, 0xFF222B48);
                    Ui.text(c, tr, chip, tx + 3, y + 7, Ui.ACCENT);
                    tx += cw + 5;
                }
                Ui.text(c, tr, Ui.fit(tr, shownTitle, textW - (tx - x - 8)), tx, y + 6, Ui.TEXT);
                if (!desc.isEmpty()) {
                    Ui.text(c, tr, Ui.fit(tr, desc, textW), x + 8, y + 6 + tr.fontHeight + 3, Ui.MUTED);
                }
            }
            return cx;
        }
    }

    // ================================================================== section header

    public static final class Header extends Row {
        public Header(String title) {
            super(title);
        }

        @Override
        public int height() {
            return 22;
        }

        @Override
        public String searchText() {
            return "";
        }

        @Override
        public void render(DrawContext c, TextRenderer tr, int mx, int my, float dt, boolean showSection) {
            Ui.text(c, tr, title.toUpperCase(Locale.ROOT), x + 4, y + 9, Ui.ACCENT);
            Ui.rect(c, x + 4 + tr.getWidth(title.toUpperCase(Locale.ROOT)) + 8, y + 13, w - 12 - tr.getWidth(title.toUpperCase(Locale.ROOT)), 1, Ui.BORDER_SOFT);
        }
    }

    // ================================================================== button row

    public static final class Action extends Row {
        private final Widgets.Button button;
        private final int bw;

        public Action(String title, String buttonLabel, Widgets.Button.Style style, Runnable action) {
            super(title);
            this.button = new Widgets.Button(buttonLabel, style, action);
            this.bw = 96;
        }

        public Action(String title, Supplier<String> label, Widgets.Button.Style style, Runnable action) {
            super(title);
            this.button = new Widgets.Button(label, style, action);
            this.bw = 96;
        }

        public Action enabledWhen(boolean b) {
            button.enabled = b;
            return this;
        }

        public Widgets.Button button() {
            return button;
        }

        @Override
        protected int controlWidth() {
            return bw;
        }

        @Override
        public void render(DrawContext c, TextRenderer tr, int mx, int my, float dt, boolean showSection) {
            int cx = drawCard(c, tr, mx, my, dt, showSection);
            button.bounds(cx, y + (height() - 20) / 2, bw, 20);
            button.render(c, tr, mx, my, dt);
        }

        @Override
        public boolean mouseClicked(double mx, double my, int b) {
            return button.mouseClicked(mx, my, b);
        }
    }

    // ================================================================== switch row

    public static final class Switch extends Row {
        private final Widgets.Toggle toggle;

        public Switch(String title, BooleanSupplier get, Consumer<Boolean> set) {
            super(title);
            this.toggle = new Widgets.Toggle(get, set);
        }

        @Override
        protected int controlWidth() {
            return 40;
        }

        @Override
        public void render(DrawContext c, TextRenderer tr, int mx, int my, float dt, boolean showSection) {
            int cx = drawCard(c, tr, mx, my, dt, showSection);
            toggle.bounds(cx, y, controlWidth(), height());
            toggle.render(c, tr, mx, my, dt);
        }

        @Override
        public boolean mouseClicked(double mx, double my, int b) {
            return toggle.mouseClicked(mx, my, b);
        }
    }

    // ================================================================== slider row

    public static final class Slide extends Row {
        private final Widgets.Slider slider;
        private final int sw;

        public Slide(String title, double min, double max, double step, DoubleSupplier get, DoubleConsumer commit,
                     DoubleFunction<String> format) {
            super(title);
            this.slider = new Widgets.Slider(min, max, step, get, commit, format);
            this.sw = 190;
        }

        @Override
        protected int controlWidth() {
            return compact ? 150 : sw;
        }

        @Override
        public void render(DrawContext c, TextRenderer tr, int mx, int my, float dt, boolean showSection) {
            int cx = drawCard(c, tr, mx, my, dt, showSection);
            slider.bounds(cx, y + (height() - 18) / 2, controlWidth(), 18);
            slider.render(c, tr, mx, my, dt);
        }

        @Override
        public boolean mouseClicked(double mx, double my, int b) {
            return slider.mouseClicked(mx, my, b);
        }

        @Override
        public boolean mouseDragged(double mx, double my, int b, double dx, double dy) {
            return slider.mouseDragged(mx, my, b, dx, dy);
        }

        @Override
        public boolean mouseReleased(double mx, double my, int b) {
            return slider.mouseReleased(mx, my, b);
        }
    }

    // ================================================================== choice row

    public static final class Pick extends Row {
        private final Widgets.Choice choice;
        private final int cw;

        public Pick(String title, String[] options, IntSupplier get, IntConsumer set) {
            super(title);
            this.choice = new Widgets.Choice(options, get, set);
            this.cw = Math.min(250, 62 * options.length);
        }

        @Override
        protected int controlWidth() {
            return cw;
        }

        @Override
        public void render(DrawContext c, TextRenderer tr, int mx, int my, float dt, boolean showSection) {
            int cx = drawCard(c, tr, mx, my, dt, showSection);
            choice.bounds(cx, y + (height() - 20) / 2, cw, 20);
            choice.render(c, tr, mx, my, dt);
        }

        @Override
        public boolean mouseClicked(double mx, double my, int b) {
            return choice.mouseClicked(mx, my, b);
        }
    }

    // ================================================================== live info row

    public static final class Info extends Row {
        private final Supplier<String> value;
        private final Supplier<Integer> color;

        public Info(String title, Supplier<String> value) {
            this(title, value, () -> Ui.TEXT);
        }

        public Info(String title, Supplier<String> value, Supplier<Integer> color) {
            super(title);
            this.value = value;
            this.color = color;
        }

        @Override
        public int height() {
            return compact ? 22 : 30;
        }

        @Override
        public void render(DrawContext c, TextRenderer tr, int mx, int my, float dt, boolean showSection) {
            int h = height();
            Ui.panel(c, x, y, w, h, 3, Ui.CARD, Ui.BORDER_SOFT);
            Ui.text(c, tr, Ui.fit(tr, title, w / 2 - 10), x + 8, y + (h - tr.fontHeight) / 2 + 1, Ui.MUTED);
            String v = value.get();
            Ui.textRight(c, tr, Ui.fit(tr, v, w / 2 - 6), x + w - 8, y + (h - tr.fontHeight) / 2 + 1, color.get());
        }
    }

    // ================================================================== command row (inputs + run)

    /**
     * A command with {placeholders}. Each placeholder gets a small text box; "Run" sends the finished command.
     * Example template: "hollow setsize {size}".
     */
    public static final class Command extends Row {
        private final String template;
        private final List<String> names = new ArrayList<>();
        private final List<Widgets.TextBox> boxes = new ArrayList<>();
        private final Widgets.Button run;

        public Command(String title, String template, String... defaults) {
            super(title);
            this.template = template;
            int i = 0;
            int pos = 0;
            while ((pos = template.indexOf('{', pos)) >= 0) {
                int end = template.indexOf('}', pos);
                if (end < 0) {
                    break;
                }
                String name = template.substring(pos + 1, end);
                names.add(name);
                Widgets.TextBox box = new Widgets.TextBox(name, i < defaults.length ? defaults[i] : "");
                box.maxLen = 48;
                boxes.add(box);
                i++;
                pos = end + 1;
            }
            this.run = new Widgets.Button("Run", Widgets.Button.Style.PRIMARY, this::execute);
            this.run.w = 44;
            this.tags = template;
            this.desc = "/" + template.replace("{", "<").replace("}", ">");
        }

        public String build() {
            String cmd = template;
            for (int i = 0; i < names.size(); i++) {
                cmd = cmd.replace("{" + names.get(i) + "}", boxes.get(i).text.trim());
            }
            return cmd;
        }

        private void execute() {
            String cmd = build();
            if (cmd.contains("{")) {
                return;
            }
            ClientHollows.command(cmd);
        }

        @Override
        protected int controlWidth() {
            return 52 + boxes.size() * 56;
        }

        @Override
        public void render(DrawContext c, TextRenderer tr, int mx, int my, float dt, boolean showSection) {
            int cx = drawCard(c, tr, mx, my, dt, showSection);
            int bx = cx;
            int by = y + (height() - 20) / 2;
            for (Widgets.TextBox box : boxes) {
                box.bounds(bx, by, 52, 20);
                box.render(c, tr, mx, my, dt);
                bx += 56;
            }
            run.bounds(bx, by, 44, 20);
            run.render(c, tr, mx, my, dt);
        }

        @Override
        public boolean mouseClicked(double mx, double my, int b) {
            for (Widgets.TextBox box : boxes) {
                if (box.mouseClicked(mx, my, b)) {
                    return true;
                }
            }
            return run.mouseClicked(mx, my, b);
        }

        public boolean keyPressed(int key, int scan, int mods) {
            for (Widgets.TextBox box : boxes) {
                if (box.keyPressed(key, scan, mods)) {
                    return true;
                }
            }
            return false;
        }
    }

    // ================================================================== inputs row (several fields + one action)

    public static final class Inputs extends Row {
        private final List<Widgets.TextBox> boxes = new ArrayList<>();
        private final Widgets.Button button;

        public Inputs(String title, String buttonLabel, Consumer<double[]> onRun, String[] hints, String[] defaults) {
            super(title);
            for (int i = 0; i < hints.length; i++) {
                Widgets.TextBox b = new Widgets.TextBox(hints[i], i < defaults.length ? defaults[i] : "");
                b.numeric = true;
                b.maxLen = 12;
                boxes.add(b);
            }
            this.button = new Widgets.Button(buttonLabel, Widgets.Button.Style.PRIMARY, () -> {
                double[] v = new double[boxes.size()];
                for (int i = 0; i < v.length; i++) {
                    v[i] = boxes.get(i).number(Double.NaN);
                }
                onRun.accept(v);
            });
        }

        @Override
        protected int controlWidth() {
            return boxes.size() * 52 + 70;
        }

        @Override
        public void render(DrawContext c, TextRenderer tr, int mx, int my, float dt, boolean showSection) {
            int cx = drawCard(c, tr, mx, my, dt, showSection);
            int by = y + (height() - 20) / 2;
            int bx = cx;
            for (Widgets.TextBox b : boxes) {
                b.bounds(bx, by, 48, 20);
                b.render(c, tr, mx, my, dt);
                bx += 52;
            }
            button.bounds(bx, by, 64, 20);
            button.render(c, tr, mx, my, dt);
        }

        @Override
        public boolean mouseClicked(double mx, double my, int b) {
            for (Widgets.TextBox box : boxes) {
                if (box.mouseClicked(mx, my, b)) {
                    return true;
                }
            }
            return button.mouseClicked(mx, my, b);
        }
    }

    // ================================================================== text input row (free command)

    public static final class FreeText extends Row {
        private final Widgets.TextBox box;
        private final Widgets.Button button;

        public FreeText(String title, String hint, String buttonLabel, Consumer<String> onRun) {
            super(title);
            this.box = new Widgets.TextBox(hint, "");
            this.box.maxLen = 200;
            this.button = new Widgets.Button(buttonLabel, Widgets.Button.Style.PRIMARY, () -> {
                String t = box.text.trim();
                if (!t.isEmpty()) {
                    onRun.accept(t);
                }
            });
            this.box.onEnter = () -> {
                String t = box.text.trim();
                if (!t.isEmpty()) {
                    onRun.accept(t);
                }
            };
        }

        @Override
        protected int controlWidth() {
            return 250;
        }

        @Override
        public void render(DrawContext c, TextRenderer tr, int mx, int my, float dt, boolean showSection) {
            int cx = drawCard(c, tr, mx, my, dt, showSection);
            int by = y + (height() - 20) / 2;
            box.bounds(cx, by, 188, 20);
            box.render(c, tr, mx, my, dt);
            button.bounds(cx + 192, by, 58, 20);
            button.render(c, tr, mx, my, dt);
        }

        @Override
        public boolean mouseClicked(double mx, double my, int b) {
            return box.mouseClicked(mx, my, b) || button.mouseClicked(mx, my, b);
        }

        public boolean keyPressed(int key, int scan, int mods) {
            return box.keyPressed(key, scan, mods);
        }
    }

    // ================================================================== the scrolling list

    public static final class RowList {
        private List<Row> rows = new ArrayList<>();
        private double scroll = 0.0;
        private double scrollTarget = 0.0;
        private int vx;
        private int vy;
        private int vw;
        private int vh;
        private boolean draggingBar = false;
        public boolean showSection = false;
        private static final int GAP = 4;

        public void setRows(List<Row> rows) {
            this.rows = rows;
            this.scroll = 0.0;
            this.scrollTarget = 0.0;
        }

        public List<Row> rows() {
            return rows;
        }

        public void bounds(int x, int y, int w, int h) {
            this.vx = x;
            this.vy = y;
            this.vw = w;
            this.vh = h;
        }

        private int contentHeight() {
            int total = 0;
            for (Row r : rows) {
                total += r.height() + GAP;
            }
            return total;
        }

        private double maxScroll() {
            return Math.max(0, contentHeight() - vh);
        }

        private void layoutRows() {
            int cy = vy - (int) Math.round(scroll);
            int rw = vw - 8;
            for (Row r : rows) {
                r.layout(vx, cy, rw);
                cy += r.height() + GAP;
            }
        }

        public void render(DrawContext c, TextRenderer tr, int mx, int my, float dt) {
            scrollTarget = Math.max(0, Math.min(maxScroll(), scrollTarget));
            scroll += (scrollTarget - scroll) * Math.min(1.0, dt * 16.0);
            layoutRows();
            c.enableScissor(vx, vy, vx + vw, vy + vh);
            boolean inside = Ui.in(mx, my, vx, vy, vw, vh);
            for (Row r : rows) {
                if (r.y + r.height() < vy || r.y > vy + vh) {
                    continue;
                }
                r.render(c, tr, inside ? mx : -1000, inside ? my : -1000, dt, showSection);
            }
            c.disableScissor();

            // scrollbar
            double max = maxScroll();
            if (max > 0) {
                int barX = vx + vw - 5;
                int barH = Math.max(18, (int) (vh * (vh / (double) contentHeight())));
                int barY = vy + (int) ((vh - barH) * (scroll / max));
                Ui.rrect(c, barX, vy, 3, vh, 1, 0x30FFFFFF);
                Ui.rrect(c, barX, barY, 3, barH, 1, draggingBar ? Ui.ACCENT : 0xB0A0B0E0);
            }
        }

        public boolean mouseClicked(double mx, double my, int button) {
            if (!Ui.in(mx, my, vx, vy, vw, vh)) {
                return false;
            }
            double max = maxScroll();
            if (max > 0 && button == 0 && mx >= vx + vw - 9) {
                draggingBar = true;
                dragBar(my);
                return true;
            }
            layoutRows();
            for (Row r : rows) {
                if (Ui.in(mx, my, r.x, r.y, r.w, r.height()) && r.mouseClicked(mx, my, button)) {
                    return true;
                }
            }
            return true;
        }

        private void dragBar(double my) {
            double max = maxScroll();
            if (max <= 0) {
                return;
            }
            double t = (my - vy) / (double) vh;
            scrollTarget = Math.max(0, Math.min(max, t * max));
            scroll = scrollTarget;
        }

        public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
            if (draggingBar) {
                dragBar(my);
                return true;
            }
            for (Row r : rows) {
                if (r.mouseDragged(mx, my, button, dx, dy)) {
                    return true;
                }
            }
            return false;
        }

        public boolean mouseReleased(double mx, double my, int button) {
            boolean used = draggingBar;
            draggingBar = false;
            for (Row r : rows) {
                if (r.mouseReleased(mx, my, button)) {
                    used = true;
                }
            }
            return used;
        }

        public boolean mouseScrolled(double mx, double my, double amount) {
            if (!Ui.in(mx, my, vx, vy, vw, vh)) {
                return false;
            }
            scrollTarget = Math.max(0, Math.min(maxScroll(), scrollTarget - amount * 34.0));
            return true;
        }

        public boolean keyPressed(int key, int scan, int mods) {
            for (Row r : rows) {
                if (r instanceof Command cmd && cmd.keyPressed(key, scan, mods)) {
                    return true;
                }
                if (r instanceof FreeText ft && ft.keyPressed(key, scan, mods)) {
                    return true;
                }
            }
            return false;
        }
    }

    private Rows() {
    }
}
