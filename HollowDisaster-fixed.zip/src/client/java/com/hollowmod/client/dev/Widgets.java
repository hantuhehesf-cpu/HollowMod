package com.hollowmod.client.dev;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import org.lwjgl.glfw.GLFW;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.DoubleConsumer;
import java.util.function.DoubleSupplier;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

/** The interactive pieces of the dev console. Every widget draws itself and handles its own mouse/keyboard input. */
public final class Widgets {

    public abstract static class W {
        public int x;
        public int y;
        public int w;
        public int h;
        public boolean enabled = true;
        public boolean visible = true;

        public W bounds(int x, int y, int w, int h) {
            this.x = x;
            this.y = y;
            this.w = w;
            this.h = h;
            return this;
        }

        public boolean hit(double mx, double my) {
            return visible && Ui.in(mx, my, x, y, w, h);
        }

        public abstract void render(DrawContext c, TextRenderer tr, int mx, int my, float dt);

        public boolean mouseClicked(double mx, double my, int button) {
            return false;
        }

        public boolean mouseReleased(double mx, double my, int button) {
            return false;
        }

        public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
            return false;
        }

        public boolean keyPressed(int key, int scan, int mods) {
            return false;
        }

        public boolean charTyped(char ch) {
            return false;
        }
    }

    // ================================================================== Button

    public static final class Button extends W {
        public enum Style { PRIMARY, SECONDARY, DANGER, GHOST }

        private final Supplier<String> label;
        private final Runnable action;
        public Style style;
        private float hover = 0.0f;
        private float flash = 0.0f;

        public Button(String label, Style style, Runnable action) {
            this(() -> label, style, action);
        }

        public Button(Supplier<String> label, Style style, Runnable action) {
            this.label = label;
            this.style = style;
            this.action = action;
        }

        @Override
        public void render(DrawContext c, TextRenderer tr, int mx, int my, float dt) {
            boolean over = enabled && hit(mx, my);
            hover += ((over ? 1.0f : 0.0f) - hover) * Math.min(1.0f, dt * 14.0f);
            flash = Math.max(0.0f, flash - dt * 4.0f);

            int fill;
            int border;
            int textColor = Ui.TEXT;
            switch (style) {
                case PRIMARY -> {
                    fill = Ui.lerp(Ui.ACCENT_DARK, Ui.ACCENT, hover);
                    border = Ui.lerp(Ui.ACCENT, 0xFFBFD2FF, hover);
                    textColor = 0xFFFFFFFF;
                }
                case DANGER -> {
                    fill = Ui.lerp(0xFF4A1A2A, 0xFFB03050, hover);
                    border = Ui.lerp(0xFF7A2A40, Ui.DANGER, hover);
                    textColor = 0xFFFFE6EB;
                }
                case GHOST -> {
                    fill = Ui.lerp(0x00000000, 0x30FFFFFF, hover);
                    border = Ui.lerp(0x00000000, Ui.BORDER, hover);
                }
                default -> {
                    fill = Ui.lerp(Ui.CARD, Ui.CARD_HOVER, hover);
                    border = Ui.lerp(Ui.BORDER, Ui.ACCENT, hover);
                }
            }
            if (flash > 0.0f) {
                fill = Ui.lerp(fill, 0xFFFFFFFF, flash * 0.35f);
            }
            if (!enabled) {
                fill = Ui.fade(fill, 0.45f);
                border = Ui.fade(border, 0.45f);
                textColor = Ui.FAINT;
            }
            Ui.panel(c, x, y, w, h, 3, fill, border);
            String s = Ui.fit(tr, label.get(), w - 8);
            Ui.text(c, tr, s, x + (w - tr.getWidth(s)) / 2, y + (h - tr.fontHeight) / 2 + 1, textColor);
        }

        @Override
        public boolean mouseClicked(double mx, double my, int button) {
            if (enabled && button == 0 && hit(mx, my)) {
                flash = 1.0f;
                action.run();
                return true;
            }
            return false;
        }
    }

    // ================================================================== Toggle (switch)

    public static final class Toggle extends W {
        private final BooleanSupplier get;
        private final Consumer<Boolean> set;
        private float anim = -1.0f;

        public Toggle(BooleanSupplier get, Consumer<Boolean> set) {
            this.get = get;
            this.set = set;
        }

        @Override
        public void render(DrawContext c, TextRenderer tr, int mx, int my, float dt) {
            boolean on = get.getAsBoolean();
            if (anim < 0.0f) {
                anim = on ? 1.0f : 0.0f;
            }
            anim += ((on ? 1.0f : 0.0f) - anim) * Math.min(1.0f, dt * 16.0f);
            int tw = 30;
            int th = 14;
            int tx = x + w - tw;
            int ty = y + (h - th) / 2;
            boolean over = enabled && Ui.in(mx, my, tx, ty, tw, th);
            int track = Ui.lerp(0xFF262E48, Ui.ACCENT_DARK, anim);
            int border = Ui.lerp(Ui.BORDER, Ui.ACCENT, Math.max(anim, over ? 0.6f : 0.0f));
            Ui.panel(c, tx, ty, tw, th, 6, enabled ? track : Ui.fade(track, 0.5f), border);
            int knob = th - 6;
            int kx = tx + 3 + (int) ((tw - 6 - knob) * anim);
            Ui.rrect(c, kx, ty + 3, knob, knob, 3, Ui.lerp(0xFF9AA3BF, 0xFFFFFFFF, anim));
        }

        @Override
        public boolean hit(double mx, double my) {
            return visible && Ui.in(mx, my, x + w - 34, y, 34, h);
        }

        @Override
        public boolean mouseClicked(double mx, double my, int button) {
            if (enabled && button == 0 && hit(mx, my)) {
                set.accept(!get.getAsBoolean());
                return true;
            }
            return false;
        }
    }

    // ================================================================== Slider

    public static final class Slider extends W {
        private final double min;
        private final double max;
        private final double step;
        private final DoubleSupplier get;
        private final DoubleConsumer commit;
        private final java.util.function.DoubleFunction<String> format;
        private boolean dragging = false;
        private double dragValue = 0.0;
        private static final int VALUE_W = 40;
        private static final int BTN = 11;

        public Slider(double min, double max, double step, DoubleSupplier get, DoubleConsumer commit,
                      java.util.function.DoubleFunction<String> format) {
            this.min = min;
            this.max = max;
            this.step = step;
            this.get = get;
            this.commit = commit;
            this.format = format;
        }

        private double value() {
            return dragging ? dragValue : get.getAsDouble();
        }

        private int trackX() {
            return x + BTN + 3;
        }

        private int trackW() {
            return Math.max(10, w - VALUE_W - BTN * 2 - 8);
        }

        private double fromMouse(double mx) {
            double t = (mx - trackX()) / trackW();
            t = Math.max(0.0, Math.min(1.0, t));
            double v = min + (max - min) * t;
            if (step > 0.0) {
                v = Math.round(v / step) * step;
            }
            return Math.max(min, Math.min(max, v));
        }

        @Override
        public void render(DrawContext c, TextRenderer tr, int mx, int my, float dt) {
            double v = value();
            double t = max > min ? (v - min) / (max - min) : 0.0;
            t = Math.max(0.0, Math.min(1.0, t));
            int ty = y + h / 2 - 2;
            int tx = trackX();
            int tw = trackW();

            drawMini(c, tr, x, y + (h - BTN) / 2, "-", Ui.in(mx, my, x, y, BTN + 2, h));
            drawMini(c, tr, x + w - VALUE_W - BTN - 3, y + (h - BTN) / 2, "+", Ui.in(mx, my, x + w - VALUE_W - BTN - 3, y, BTN + 2, h));

            Ui.rrect(c, tx, ty, tw, 4, 2, 0xFF262E48);
            int fillW = (int) (tw * t);
            if (fillW > 0) {
                Ui.rrect(c, tx, ty, Math.max(2, fillW), 4, 2, Ui.lerp(Ui.ACCENT_DARK, Ui.VIOLET, (float) t));
            }
            int kx = tx + fillW - 4;
            boolean over = enabled && (dragging || Ui.in(mx, my, tx - 4, y, tw + 8, h));
            Ui.panel(c, kx, ty - 3, 9, 10, 3, over ? 0xFFFFFFFF : 0xFFC9D4F5, over ? Ui.ACCENT : Ui.BORDER);
            Ui.textRight(c, tr, format.apply(v), x + w, y + (h - tr.fontHeight) / 2 + 1, dragging ? Ui.ACCENT : Ui.TEXT);
        }

        private void drawMini(DrawContext c, TextRenderer tr, int bx, int by, String s, boolean over) {
            Ui.panel(c, bx, by, BTN, BTN, 2, over ? Ui.CARD_HOVER : Ui.FIELD, over ? Ui.ACCENT : Ui.BORDER_SOFT);
            Ui.text(c, tr, s, bx + (BTN - tr.getWidth(s)) / 2 + 0, by + (BTN - tr.fontHeight) / 2 + 1, Ui.MUTED);
        }

        @Override
        public boolean mouseClicked(double mx, double my, int button) {
            if (!enabled || button != 0 || !hit(mx, my)) {
                return false;
            }
            double s = step > 0.0 ? step : (max - min) / 100.0;
            if (Ui.in(mx, my, x, y, BTN + 2, h)) {
                commit.accept(Math.max(min, get.getAsDouble() - s));
                return true;
            }
            if (Ui.in(mx, my, x + w - VALUE_W - BTN - 3, y, BTN + 2, h)) {
                commit.accept(Math.min(max, get.getAsDouble() + s));
                return true;
            }
            if (mx >= trackX() - 4 && mx <= trackX() + trackW() + 4) {
                dragging = true;
                dragValue = fromMouse(mx);
                return true;
            }
            return false;
        }

        @Override
        public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
            if (dragging) {
                dragValue = fromMouse(mx);
                return true;
            }
            return false;
        }

        @Override
        public boolean mouseReleased(double mx, double my, int button) {
            if (dragging) {
                dragging = false;
                commit.accept(dragValue);
                return true;
            }
            return false;
        }
    }

    // ================================================================== TextBox

    public static final class TextBox extends W {
        private static TextBox focusedBox = null;

        public String text = "";
        public String hint = "";
        public boolean numeric = false;
        public int maxLen = 40;
        public Runnable onEnter = null;
        public Consumer<String> onChange = null;
        private int cursor = 0;
        private float blink = 0.0f;

        public TextBox(String hint, String initial) {
            this.hint = hint;
            this.text = initial == null ? "" : initial;
            this.cursor = this.text.length();
        }

        public static void blurAll() {
            focusedBox = null;
        }

        public static boolean hasFocus() {
            return focusedBox != null;
        }

        /** Sends a key to whichever text box has the focus. */
        public static boolean dispatchKey(int key, int scan, int mods) {
            return focusedBox != null && focusedBox.keyPressed(key, scan, mods);
        }

        /** Sends a typed character to whichever text box has the focus. */
        public static boolean dispatchChar(char ch) {
            return focusedBox != null && focusedBox.charTyped(ch);
        }

        public boolean focused() {
            return focusedBox == this;
        }

        public void focus() {
            focusedBox = this;
            cursor = text.length();
            blink = 0.0f;
        }

        public void setText(String t) {
            this.text = t;
            this.cursor = Math.min(cursor, t.length());
        }

        public double number(double fallback) {
            try {
                return Double.parseDouble(text.trim());
            } catch (NumberFormatException e) {
                return fallback;
            }
        }

        @Override
        public void render(DrawContext c, TextRenderer tr, int mx, int my, float dt) {
            boolean f = focused();
            blink += dt;
            boolean over = enabled && hit(mx, my);
            Ui.panel(c, x, y, w, h, 3, Ui.FIELD, f ? Ui.ACCENT : (over ? Ui.MUTED : Ui.BORDER_SOFT));
            int ty = y + (h - tr.fontHeight) / 2 + 1;
            if (text.isEmpty() && !f) {
                Ui.text(c, tr, Ui.fit(tr, hint, w - 8), x + 5, ty, Ui.FAINT);
            } else {
                int maxW = w - 10;
                String shown = text;
                int start = 0;
                while (tr.getWidth(shown.substring(start, Math.min(cursor, shown.length()))) > maxW && start < cursor) {
                    start++;
                }
                String vis = shown.substring(start);
                vis = tr.trimToWidth(vis, maxW);
                Ui.text(c, tr, vis, x + 5, ty, enabled ? Ui.TEXT : Ui.FAINT);
                if (f && ((int) (blink * 2.0f)) % 2 == 0) {
                    int cx = x + 5 + tr.getWidth(shown.substring(start, Math.min(cursor, shown.length())));
                    c.fill(cx, ty - 1, cx + 1, ty + tr.fontHeight, Ui.ACCENT);
                }
            }
        }

        @Override
        public boolean mouseClicked(double mx, double my, int button) {
            if (enabled && button == 0 && hit(mx, my)) {
                focus();
                return true;
            }
            return false;
        }

        @Override
        public boolean keyPressed(int key, int scan, int mods) {
            if (!focused()) {
                return false;
            }
            boolean ctrl = (mods & GLFW.GLFW_MOD_CONTROL) != 0;
            switch (key) {
                case GLFW.GLFW_KEY_ESCAPE -> {
                    focusedBox = null;
                    return true;
                }
                case GLFW.GLFW_KEY_ENTER, GLFW.GLFW_KEY_KP_ENTER -> {
                    if (onEnter != null) {
                        onEnter.run();
                    }
                    return true;
                }
                case GLFW.GLFW_KEY_BACKSPACE -> {
                    if (cursor > 0) {
                        text = text.substring(0, cursor - 1) + text.substring(cursor);
                        cursor--;
                        changed();
                    }
                    return true;
                }
                case GLFW.GLFW_KEY_DELETE -> {
                    if (cursor < text.length()) {
                        text = text.substring(0, cursor) + text.substring(cursor + 1);
                        changed();
                    }
                    return true;
                }
                case GLFW.GLFW_KEY_LEFT -> {
                    cursor = Math.max(0, cursor - 1);
                    return true;
                }
                case GLFW.GLFW_KEY_RIGHT -> {
                    cursor = Math.min(text.length(), cursor + 1);
                    return true;
                }
                case GLFW.GLFW_KEY_HOME -> {
                    cursor = 0;
                    return true;
                }
                case GLFW.GLFW_KEY_END -> {
                    cursor = text.length();
                    return true;
                }
                case GLFW.GLFW_KEY_V -> {
                    if (ctrl) {
                        String clip = MinecraftClient.getInstance().keyboard.getClipboard();
                        if (clip != null) {
                            for (char ch : clip.toCharArray()) {
                                insert(ch);
                            }
                        }
                        return true;
                    }
                    return false;
                }
                case GLFW.GLFW_KEY_A -> {
                    if (ctrl) {
                        cursor = text.length();
                        return true;
                    }
                    return false;
                }
                default -> {
                    return false;
                }
            }
        }

        @Override
        public boolean charTyped(char ch) {
            if (!focused()) {
                return false;
            }
            insert(ch);
            return true;
        }

        private void insert(char ch) {
            if (ch < 32 || ch == 127 || text.length() >= maxLen) {
                return;
            }
            if (numeric && !(Character.isDigit(ch) || ch == '-' || ch == '.')) {
                return;
            }
            text = text.substring(0, cursor) + ch + text.substring(cursor);
            cursor++;
            changed();
        }

        private void changed() {
            if (onChange != null) {
                onChange.accept(text);
            }
        }
    }

    // ================================================================== Choice (segmented control)

    public static final class Choice extends W {
        private final String[] options;
        private final IntSupplier get;
        private final IntConsumer set;

        public Choice(String[] options, IntSupplier get, IntConsumer set) {
            this.options = options;
            this.get = get;
            this.set = set;
        }

        @Override
        public void render(DrawContext c, TextRenderer tr, int mx, int my, float dt) {
            int n = options.length;
            Ui.panel(c, x, y, w, h, 3, Ui.FIELD, Ui.BORDER_SOFT);
            int segW = (w - 2) / n;
            int sel = get.getAsInt();
            for (int i = 0; i < n; i++) {
                int sx = x + 1 + i * segW;
                boolean over = enabled && Ui.in(mx, my, sx, y, segW, h);
                if (i == sel) {
                    Ui.rrect(c, sx + 1, y + 2, segW - 2, h - 4, 2, Ui.ACCENT_DARK);
                } else if (over) {
                    Ui.rrect(c, sx + 1, y + 2, segW - 2, h - 4, 2, Ui.CARD_HOVER);
                }
                String s = Ui.fit(tr, options[i], segW - 4);
                Ui.text(c, tr, s, sx + (segW - tr.getWidth(s)) / 2, y + (h - tr.fontHeight) / 2 + 1,
                        i == sel ? 0xFFFFFFFF : Ui.MUTED);
            }
        }

        @Override
        public boolean mouseClicked(double mx, double my, int button) {
            if (!enabled || button != 0 || !hit(mx, my)) {
                return false;
            }
            int segW = (w - 2) / options.length;
            int i = (int) ((mx - x - 1) / segW);
            if (i >= 0 && i < options.length) {
                set.accept(i);
            }
            return true;
        }
    }

    private Widgets() {
    }
}
