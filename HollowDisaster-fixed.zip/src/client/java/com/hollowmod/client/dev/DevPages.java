package com.hollowmod.client.dev;

import com.hollowmod.client.visual.HollowVisualConfig;
import com.hollowmod.dev.HollowInfo;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * The content of the dev console. Every feature is a row (see Rows), grouped into pages. The search bar looks through
 * the title, description and tags of ALL rows, so give each row good words.
 */
public final class DevPages {

    /** One page (tab) of the console. The Map tab has no rows: it has its own view. */
    public static final class Tab {
        public final String id;
        public final String name;
        public final int color;
        public final boolean isMap;
        public final List<Rows.Row> rows = new ArrayList<>();

        public Tab(String id, String name, int color, boolean isMap) {
            this.id = id;
            this.name = name;
            this.color = color;
            this.isMap = isMap;
        }

        public Tab add(Rows.Row r) {
            r.section = name;
            rows.add(r);
            return this;
        }
    }

    // state used by several rows
    private static boolean forceOverflow = false;
    private static int prefabRotation = 0;
    private static int prefabMirror = 0;

    public static boolean forceOverflow() {
        return forceOverflow;
    }

    public static void setForceOverflow(boolean on) {
        forceOverflow = on;
    }

    private static final String[] ROT = {"0", "90", "180", "270"};
    private static final String[] MIRROR = {"none", "left_right", "front_back"};

    public static List<Tab> build(DevMenuScreen screen) {
        List<Tab> tabs = new ArrayList<>();
        tabs.add(overview(screen));
        tabs.add(new Tab("map", "Hollow Map", Ui.TEAL, true));
        tabs.add(mechanics(screen));
        tabs.add(visuals(screen));
        tabs.add(city());
        tabs.add(commands());
        tabs.add(debug(screen));
        return tabs;
    }

    // ------------------------------------------------------------------ helpers

    /** Sends an action to the Hollow the console is aimed at (map selection, else nearest). */
    private static void act(String action, double a) {
        HollowInfo t = ClientHollows.target();
        if (t == null) {
            ClientHollows.log(true, "No Hollow to act on. Select one on the map or spawn one first.");
            return;
        }
        ClientHollows.action(t.uuid, action, a);
    }

    private static void global(String action, double a, double b, double c, String s) {
        ClientHollows.action(HollowInfo.NONE, action, a, b, c, s);
    }

    private static String targetText() {
        HollowInfo t = ClientHollows.target();
        if (t == null) {
            return "none (spawn one)";
        }
        return "H-" + t.shortId() + (t.loaded ? "" : " (not loaded)") + "  r=" + Math.round(t.radius)
                + "  act " + Math.round(t.activity) + "%  gauge " + Math.round(t.gauge) + "%";
    }

    private static double targetValue(java.util.function.Function<HollowInfo, Double> f, double fallback) {
        HollowInfo t = ClientHollows.target();
        return t == null ? fallback : f.apply(t);
    }

    private static Rows.Action button(String title, String label, Runnable r) {
        return new Rows.Action(title, label, Widgets.Button.Style.SECONDARY, r);
    }

    private static Rows.Action primary(String title, String label, Runnable r) {
        return new Rows.Action(title, label, Widgets.Button.Style.PRIMARY, r);
    }

    private static Rows.Action danger(String title, String label, Runnable r) {
        return new Rows.Action(title, label, Widgets.Button.Style.DANGER, r);
    }

    // ------------------------------------------------------------------ Overview

    private static Tab overview(DevMenuScreen screen) {
        Tab t = new Tab("overview", "Overview", Ui.ACCENT, false);
        MinecraftClient mc = MinecraftClient.getInstance();

        t.add(new Rows.Header("Status"));
        t.add(new Rows.Info("Dimension", () -> mc.world == null ? "-" : mc.world.getRegistryKey().getValue().toString()).tags("world where am i"));
        t.add(new Rows.Info("Your position", () -> mc.player == null ? "-" : String.format(Locale.ROOT, "%.0f, %.0f, %.0f",
                mc.player.getX(), mc.player.getY(), mc.player.getZ())).tags("coordinates xyz"));
        t.add(new Rows.Info("Framerate", () -> screen.fps() + " FPS", () -> screen.fps() >= 45 ? Ui.GOOD : (screen.fps() >= 25 ? Ui.WARN : Ui.DANGER)).tags("fps performance lag"));
        t.add(new Rows.Info("Hollows", () -> ClientHollows.loadedCount() + " loaded / " + ClientHollows.all().size() + " known").tags("count population"));
        t.add(new Rows.Info("Dev permission", () -> ClientHollows.allowed ? "granted" : "NO (needs operator or single-player)",
                () -> ClientHollows.allowed ? Ui.GOOD : Ui.DANGER).tags("op cheats allowed"));
        t.add(new Rows.Info("Server sync", () -> ClientHollows.lastSyncMillis == 0 ? "waiting..." : (System.currentTimeMillis() - ClientHollows.lastSyncMillis) + " ms ago").tags("network latency"));
        t.add(new Rows.Info("Target Hollow", DevPages::targetText).tags("selected nearest current"));

        t.add(new Rows.Header("Quick actions"));
        t.add(primary("Open the Hollow Map", "Open", () -> screen.gotoTab("map")).desc("3D isometric overview of every Hollow").tags("map isometric view"));
        t.add(button("Spawn a Hollow at my feet", "Spawn", () -> global("spawn_hollow", Double.NaN, Double.NaN, Double.NaN, "")).desc("Creates a new Hollow core where you stand").tags("create new hollow"));
        t.add(button("Enter the nearest Hollow", "Enter", () -> global("enter_nearest", 0, 0, 0, "")).desc("Teleports you into its sub-region in the Hollow dimension").tags("teleport dimension inside"));
        t.add(button("Refresh Hollow data", "Refresh", ClientHollows::requestSync).tags("sync update"));
        t.add(button("Hide the console (peek)", "Hide", screen::hide).desc("Look at the world, click the small pill to come back").tags("peek visuals screenshot"));
        t.add(button("Copy a debug report", "Copy", screen::copyReport).desc("Puts everything needed to describe a bug on your clipboard").tags("bug report clipboard"));
        return t;
    }

    // ------------------------------------------------------------------ Mechanics

    private static Tab mechanics(DevMenuScreen screen) {
        Tab t = new Tab("mechanics", "Mechanics", Ui.VIOLET, false);

        t.add(new Rows.Info("Aimed at", DevPages::targetText).tags("target selected nearest"));

        t.add(new Rows.Header("Ether Activity and Zenless gauge"));
        t.add(new Rows.Slide("Ether Activity", 0, 100, 1, () -> targetValue(h -> (double) h.activity, 0), v -> act("activity", v), v -> Math.round(v) + "%")
                .desc("0-100%. Rises when it eats, falls when starving").tags("activity ether level"));
        t.add(new Rows.Slide("Zenless Limit Gauge", 0, 100, 1, () -> targetValue(h -> (double) h.gauge, 0), v -> act("gauge", v), v -> Math.round(v) + "%")
                .desc("0-100%. Only time makes it rise").tags("gauge zenless limit"));
        t.add(button("Make Overflow-ready (both to 100%)", "Fill", () -> {
            act("activity", 100);
            act("gauge", 100);
        }).desc("Activity 5 + full gauge: the Hollow will reproduce on its own").tags("overflow max critical"));
        t.add(button("Reset both to 0", "Reset", () -> {
            act("activity", 0);
            act("gauge", 0);
        }).tags("zero clear"));

        t.add(new Rows.Header("Growth"));
        t.add(new Rows.Slide("Size (radius)", 0, 256, 1, () -> targetValue(h -> (double) h.radius, 0), v -> act("size", v), v -> Math.round(v) + "")
                .desc("Jumps the dome to this radius now. Big jumps queue lots of terrain").tags("radius setsize dome"));
        t.add(new Rows.Slide("Max radius", 1, 512, 1, () -> targetValue(h -> (double) h.maxRadius, 128), v -> act("maxradius", v), v -> Math.round(v) + "")
                .desc("The size it grows toward. Can be lowered").tags("limit ceiling target radius"));
        t.add(new Rows.Slide("Growth interval", 1, 200, 1, () -> targetValue(h -> (double) h.growthInterval, 20), v -> act("speed", v), v -> Math.round(v) + "t")
                .desc("Ticks between +1 radius (20 ticks = 1 second)").tags("speed rate"));
        t.add(new Rows.Switch("Freeze growth", () -> {
            HollowInfo h = ClientHollows.target();
            return h != null && h.frozen;
        }, on -> act("freeze", on ? 1 : 0)).desc("Stops the radius from growing").tags("pause stop"));

        t.add(new Rows.Header("Overflow and reproduction"));
        t.add(new Rows.Switch("Force (ignore caps)", () -> forceOverflow, on -> forceOverflow = on)
                .desc("Ignore generation limit, child allowance and the 10-Hollow cap").tags("override rules cap"));
        t.add(button("Trigger Overflow: random spot", "Trigger", () -> {
            HollowInfo h = ClientHollows.target();
            if (h != null) {
                ClientHollows.action(h.uuid, "overflow", 0, 0, 0, forceOverflow ? "force" : "");
            }
        }).desc("Gives birth to a companion Hollow in a random direction").tags("companion child birth reproduce"));
        t.add(primary("Trigger Overflow: pick the spot", "Pick on map", () -> screen.startPick(HollowMapView.Pick.OVERFLOW))
                .desc("Opens the map; click where the companion should appear").tags("companion child birth position"));

        t.add(new Rows.Header("Collapse"));
        t.add(button("Start collapse (random 3-5 minutes)", "Start", () -> act("collapse", -1)).desc("Players inside must find the exit before time runs out").tags("destroy singularity"));
        t.add(button("Collapse in 30 seconds", "30 s", () -> act("collapse", 600)).tags("quick"));
        t.add(danger("Collapse instantly", "Now", () -> act("collapse", 0)).desc("Kills players still inside, removes the Hollow").tags("destroy kill"));
        t.add(button("Cancel a running collapse", "Cancel", () -> act("collapse", -2)).tags("stop abort"));

        t.add(new Rows.Header("Swallowing creatures"));
        t.add(new Rows.Switch("Swallow creatures inside the dome", () -> ClientHollows.swallowEnabled,
                on -> global("setting", on ? 1 : 0, 0, 0, "swallow")).desc("Creatures are carried into the Hollow dimension unharmed").tags("eat absorb mobs transport"));
        t.add(new Rows.Slide("Mass per health point", 0, 1, 0.01, () -> ClientHollows.mobMassPerHealth,
                v -> global("setting", v, 0, 0, "mobmass"), v -> String.format(Locale.ROOT, "%.2f", v))
                .desc("What a death adds to the Hollow (1.0 mass = 0.5% Activity)").tags("death mass feed"));
        t.add(button("Swallow creatures now", "Swallow", () -> act("swallow", 0)).desc("Does one big swallow pass immediately").tags("eat mobs"));
        t.add(button("Spawn 8 test cows inside the dome", "Spawn", () -> act("spawn_mobs", 8)).tags("test mobs animals"));

        t.add(new Rows.Header("Keep loaded"));
        t.add(new Rows.Switch("Keep this Hollow loaded", () -> {
            HollowInfo h = ClientHollows.target();
            return h != null && h.kept;
        }, on -> act("keep", on ? 1 : 0)).desc("Force-loads its chunk so it keeps growing when you are far away").tags("chunk loader forceload"));
        t.add(new Rows.Switch("Keep ALL Hollows loaded", () -> ClientHollows.keepAllLoaded,
                on -> global("setting", on ? 1 : 0, 0, 0, "keepall")).tags("chunk loader forceload everything"));

        t.add(new Rows.Header("Spawning and travel"));
        t.add(button("Spawn a Hollow at my feet", "Spawn", () -> global("spawn_hollow", Double.NaN, Double.NaN, Double.NaN, "")).tags("create new hollow"));
        t.add(new Rows.Inputs("Spawn a Hollow at X Y Z", "Spawn", v -> global("spawn_hollow", v[0], v[1], v[2], ""),
                new String[]{"X", "Y", "Z"}, new String[]{"", "", ""}).desc("Leave a box empty to use your own coordinate").tags("create new hollow coordinates"));
        t.add(button("Spawn an Ethereal next to me", "Spawn", () -> global("spawn_ethereal", 0, 0, 0, "")).tags("monster mob enemy"));
        t.add(button("Teleport me next to the Hollow", "Teleport", () -> act("tp_me", 0)).tags("tp go"));
        t.add(button("Enter the Hollow", "Enter", () -> act("tp_enter", 0)).desc("Goes into its sub-region in the Hollow dimension").tags("dimension inside"));

        t.add(new Rows.Header("Danger zone"));
        t.add(danger("Delete the aimed Hollow", "Delete", () -> act("delete", 0)).tags("remove destroy"));
        t.add(danger("Delete ALL Hollows in this dimension", "Delete all", () -> ClientHollows.command("hollow remove all")).tags("remove destroy reset clear"));
        return t;
    }

    // ------------------------------------------------------------------ Visuals

    private static Tab visuals(DevMenuScreen screen) {
        Tab t = new Tab("visuals", "Visuals", Ui.PINK, false);
        t.add(new Rows.Header("Hollow interior"));
        t.add(new Rows.Pick("Sky mood", new String[]{"Clear", "Aurora rain"},
                () -> HollowVisualConfig.mood.ordinal(), i -> {
            HollowVisualConfig.mood = HollowVisualConfig.Mood.values()[i];
            HollowVisualConfig.save();
        }).desc("Blue cloudy sky or dark rainy aurora sky").tags("weather sky aurora rain clear"));
        t.add(new Rows.Switch("Sky detail", () -> HollowVisualConfig.skyDetail, on -> {
            HollowVisualConfig.skyDetail = on;
            HollowVisualConfig.save();
        }).desc("Clouds, glow and aurora on top of the plain gradient").tags("clouds"));
        t.add(percent("Aurora strength", 0, 100, () -> HollowVisualConfig.auroraPercent, v -> HollowVisualConfig.auroraPercent = v).tags("sky"));
        t.add(percent("Rain amount", 0, 100, () -> HollowVisualConfig.rainPercent, v -> HollowVisualConfig.rainPercent = v).desc("Only in the Aurora rain mood").tags("weather streaks"));
        t.add(percent("Floating particles", 0, 100, () -> HollowVisualConfig.particlePercent, v -> HollowVisualConfig.particlePercent = v).desc("Ash flakes and ether motes").tags("dust ash"));

        t.add(new Rows.Header("Hollow dome (outside)"));
        t.add(new Rows.Pick("Dome quality", new String[]{"Low", "Medium", "High", "Ultra"},
                () -> HollowVisualConfig.quality.ordinal(), i -> {
            HollowVisualConfig.quality = HollowVisualConfig.Quality.values()[i];
            HollowVisualConfig.save();
        }).desc("How smooth the sphere is. Lower = more FPS").tags("lod polygons smooth sphere fps"));
        t.add(new Rows.Slide("Dome brightness", 20, 200, 1, () -> HollowVisualConfig.domeBrightnessPercent, v -> {
            HollowVisualConfig.domeBrightnessPercent = (int) Math.round(v);
            HollowVisualConfig.save();
        }, v -> Math.round(v) + "%").desc("Rim glow and swirl strength").tags("glow rim light"));
        t.add(new Rows.Switch("Distant Hollows", () -> HollowVisualConfig.distantHollows, on -> {
            HollowVisualConfig.distantHollows = on;
            HollowVisualConfig.save();
        }).desc("Draw Hollows beyond the render distance (scaled, with mist)").tags("far render distance horizon"));
        t.add(percent("Distant mist", 0, 100, () -> HollowVisualConfig.distantMistPercent, v -> HollowVisualConfig.distantMistPercent = v).desc("How much far domes fade into haze").tags("fog far"));

        t.add(new Rows.Header("Screen"));
        t.add(percent("Screen effect (VHS / glitch)", 0, 100, () -> HollowVisualConfig.screenFxPercent, v -> HollowVisualConfig.screenFxPercent = v)
                .desc("Scanlines, vignette and glitches inside and near a Hollow").tags("vhs scanlines overlay"));
        t.add(button("Hide the console (peek)", "Hide", screen::hide).desc("See your changes live, click the pill to come back").tags("preview screenshot"));
        t.add(danger("Reset all visuals to defaults", "Reset", () -> {
            HollowVisualConfig.mood = HollowVisualConfig.Mood.CLEAR;
            HollowVisualConfig.quality = HollowVisualConfig.Quality.HIGH;
            HollowVisualConfig.screenFxPercent = 60;
            HollowVisualConfig.rainPercent = 70;
            HollowVisualConfig.particlePercent = 60;
            HollowVisualConfig.auroraPercent = 100;
            HollowVisualConfig.domeBrightnessPercent = 100;
            HollowVisualConfig.skyDetail = true;
            HollowVisualConfig.distantHollows = true;
            HollowVisualConfig.distantMistPercent = 55;
            HollowVisualConfig.save();
        }).tags("default restore"));
        return t;
    }

    private static Rows.Slide percent(String title, int min, int max, java.util.function.IntSupplier get, java.util.function.IntConsumer set) {
        return new Rows.Slide(title, min, max, 1, () -> get.getAsInt(), v -> {
            set.accept((int) Math.round(v));
            HollowVisualConfig.save();
        }, v -> Math.round(v) + "%");
    }

    // ------------------------------------------------------------------ City & prefabs

    private static final String[] PRESETS = {
            "preset_crossroad", "preset_office_tower", "preset_shop_row", "preset_overpass",
            "preset_rubble", "preset_subway_entrance", "preset_billboard_gantry", "preset_leaning_tower"
    };

    private static Tab city() {
        Tab t = new Tab("city", "City & Prefabs", Ui.WARN, false);
        t.add(new Rows.Header("Placement options"));
        t.add(new Rows.Pick("Rotation", ROT, () -> prefabRotation, i -> prefabRotation = i).desc("Used by every Place button below").tags("turn prefab"));
        t.add(new Rows.Pick("Mirror", MIRROR, () -> prefabMirror, i -> prefabMirror = i).tags("flip prefab"));
        t.add(new Rows.FreeText("Place any prefab by id", "e.g. my_piece", "Place",
                id -> ClientHollows.command("hollow prefab place " + id + " " + ROT[prefabRotation] + " " + MIRROR[prefabMirror]))
                .desc("Your own .schem files from config/hollowmod/prefabs").tags("worldedit schematic custom"));

        t.add(new Rows.Header("Built-in city pieces"));
        for (String id : PRESETS) {
            t.add(button(id.replace("preset_", "").replace('_', ' '), "Place", () -> ClientHollows.command("hollow prefab place " + id + " "
                    + ROT[prefabRotation] + " " + MIRROR[prefabMirror])).desc("/hollow prefab place " + id).tags("prefab preset district " + id));
        }
        t.add(new Rows.Header("Your buildings"));
        for (int i = 1; i <= 6; i++) {
            String id = "building_" + i;
            t.add(button("Building " + i, "Place", () -> ClientHollows.command("hollow prefab place " + id + " "
                    + ROT[prefabRotation] + " " + MIRROR[prefabMirror])).tags("prefab structure " + id));
        }

        t.add(new Rows.Header("Space distortion demo"));
        t.add(primary("Build the 3x3 demo city", "Build", () -> ClientHollows.command("hollow prefab demo")).desc("About 15 seconds, in front of you").tags("shift distortion"));
        t.add(primary("Run a space shift", "Shift", () -> ClientHollows.command("hollow prefab shiftdemo")).desc("Warning, swap of two districts, rotation of the one you stand on").tags("distortion maze move"));
        t.add(button("Cancel placing / shifting", "Cancel", () -> ClientHollows.command("hollow prefab cancel")).tags("stop"));
        t.add(button("Reload prefab files", "Reload", () -> ClientHollows.command("hollow prefab reload")).tags("schem refresh"));
        t.add(button("List all prefabs (in chat)", "List", () -> ClientHollows.command("hollow prefab list")).tags("show"));

        t.add(new Rows.Header("Current maze (System 6)"));
        t.add(button("Maze map", "Show", () -> ClientHollows.command("hollow maze map")).desc("Text map of the maze you are in").tags("labyrinth"));
        t.add(button("Maze truth map", "Show", () -> ClientHollows.command("hollow maze truth")).desc("The real layout, ignoring what is hidden").tags("labyrinth debug"));
        t.add(button("Force a maze shift", "Shift", () -> ClientHollows.command("hollow maze shift")).tags("labyrinth change"));
        return t;
    }

    // ------------------------------------------------------------------ Commands

    private static Tab commands() {
        Tab t = new Tab("commands", "Commands", Ui.GOOD, false);
        t.add(new Rows.Header("Run anything"));
        t.add(new Rows.FreeText("Run a command", "hollow status", "Run", ClientHollows::command).desc("Type a command and press Enter").tags("console chat"));

        t.add(new Rows.Header("/hollow"));
        t.add(new Rows.Command("Growth speed", "hollow speed {tick}", "20").tags("interval"));
        t.add(new Rows.Command("Target radius", "hollow radius {target}", "128").tags("max"));
        t.add(new Rows.Command("Set size now", "hollow setsize {size}", "20").tags("radius"));
        t.add(new Rows.Command("Ether Activity", "hollow activity {value}", "50"));
        t.add(new Rows.Command("Zenless gauge", "hollow gauge {value}", "50"));
        t.add(new Rows.Command("Status", "hollow status").tags("info"));
        t.add(new Rows.Command("Remove nearest", "hollow remove").tags("delete"));
        t.add(new Rows.Command("Remove all", "hollow remove all").tags("delete reset"));

        t.add(new Rows.Header("/hollow maze and prefab"));
        t.add(new Rows.Command("Maze map", "hollow maze map"));
        t.add(new Rows.Command("Maze truth", "hollow maze truth"));
        t.add(new Rows.Command("Maze shift", "hollow maze shift"));
        t.add(new Rows.Command("Prefab list", "hollow prefab list"));
        t.add(new Rows.Command("Prefab place", "hollow prefab place {id} {rotation} {mirror}", "preset_crossroad", "0", "none"));
        t.add(new Rows.Command("Prefab reload", "hollow prefab reload"));
        t.add(new Rows.Command("Prefab demo", "hollow prefab demo"));
        t.add(new Rows.Command("Prefab shift demo", "hollow prefab shiftdemo"));
        t.add(new Rows.Command("Prefab cancel", "hollow prefab cancel"));

        t.add(new Rows.Header("Items"));
        t.add(new Rows.Command("Give Carrot", "give @s hollowmod:carrot").tags("item map"));
        t.add(new Rows.Command("Give Hollow Core spawner", "give @s hollowmod:hollow_core_spawner").tags("item spawn"));
        t.add(new Rows.Command("Give Exit portal", "give @s hollowmod:hollow_exit_portal").tags("item block"));
        t.add(new Rows.Command("Give Observation pillar", "give @s hollowmod:observation_pillar").tags("item block sonar"));

        t.add(new Rows.Header("Handy vanilla commands"));
        t.add(new Rows.Command("Game mode", "gamemode {mode}", "creative"));
        t.add(new Rows.Command("Teleport", "tp @s {x} {y} {z}", "0", "100", "0"));
        t.add(new Rows.Command("Set time", "time set {time}", "day"));
        t.add(new Rows.Command("Clear weather", "weather clear"));
        t.add(new Rows.Command("Kill all test cows", "kill @e[type=cow]").tags("remove mobs"));

        t.add(new Rows.Header("Client commands (type in chat)"));
        t.add(new Rows.Info("/hollowdev", () -> "opens this console").compact());
        t.add(new Rows.Info("/hollowvisual ...", () -> "mood, quality, fx, rain, particles...").compact());
        return t;
    }

    // ------------------------------------------------------------------ Debug

    private static Tab debug(DevMenuScreen screen) {
        Tab t = new Tab("debug", "Debug", 0xFFFF9F5A, false);
        t.add(new Rows.Header("Hollows right now"));
        for (int i = 0; i < 10; i++) {
            final int index = i;
            t.add(new Rows.Info("Hollow #" + (i + 1), () -> hollowLine(index)).tags("list table"));
        }
        t.add(new Rows.Header("Tools"));
        t.add(primary("Copy a debug report", "Copy", screen::copyReport).tags("bug clipboard"));
        t.add(button("Force a data refresh", "Refresh", ClientHollows::requestSync).tags("sync"));
        t.add(button("Clear the event log", "Clear", ClientHollows::clearLog).tags("log"));
        t.add(button("Reload visual settings from file", "Reload", HollowVisualConfig::load).tags("config"));
        t.add(new Rows.Header("Event log"));
        t.add(new LogBox());
        return t;
    }

    private static String hollowLine(int index) {
        List<HollowInfo> list = new ArrayList<>(ClientHollows.all());
        if (index >= list.size()) {
            return "-";
        }
        HollowInfo h = list.get(index);
        return "H-" + h.shortId() + " gen" + h.generation + " r" + Math.round(h.radius) + "/" + Math.round(h.maxRadius)
                + " A" + Math.round(h.activity) + " G" + Math.round(h.gauge) + (h.frozen ? " FROZEN" : "")
                + (h.collapseTicks >= 0 ? " COLLAPSING" : "") + (h.loaded ? "" : " unloaded");
    }

    /** The scrolling event log (what the server answered to your actions, commands you ran). */
    private static final class LogBox extends Rows.Row {
        LogBox() {
            super("Event log");
        }

        @Override
        public int height() {
            return 170;
        }

        @Override
        public String searchText() {
            return "";
        }

        @Override
        public void render(DrawContext c, TextRenderer tr, int mx, int my, float dt, boolean showSection) {
            Ui.panel(c, x, y, w, height(), 3, Ui.FIELD, Ui.BORDER_SOFT);
            List<ClientHollows.LogLine> lines = ClientHollows.logLines();
            int maxLines = (height() - 8) / (tr.fontHeight + 2);
            int start = Math.max(0, lines.size() - maxLines);
            int ly = y + 5;
            for (int i = start; i < lines.size(); i++) {
                ClientHollows.LogLine l = lines.get(i);
                long sec = (System.currentTimeMillis() - l.time) / 1000;
                String stamp = sec < 60 ? sec + "s" : (sec / 60) + "m";
                Ui.text(c, tr, stamp, x + 6, ly, Ui.FAINT);
                Ui.text(c, tr, Ui.fit(tr, l.text, w - 44), x + 34, ly, l.error ? Ui.DANGER : Ui.TEXT);
                ly += tr.fontHeight + 2;
            }
            if (lines.isEmpty()) {
                Ui.text(c, tr, "Nothing yet. Run an action and the answer shows up here.", x + 6, y + 6, Ui.FAINT);
            }
        }
    }

    private DevPages() {
    }
}
