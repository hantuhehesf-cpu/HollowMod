package com.hollowmod.client.dev;

import com.hollowmod.client.render.DistantHollowRenderer;
import com.hollowmod.dev.DevNetworking;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

/**
 * Starts the Hollow dev console on the client:
 *  - the key bind (default F8, rebind it in Controls)
 *  - the /hollowdev client command (handy on a phone without a keyboard)
 *  - the receivers for the server's Hollow list and feedback
 *  - the renderer for distant Hollows
 */
public final class DevClient {

    private static KeyBinding openKey;

    public static void register() {
        openKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.hollowmod.dev_menu", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_F8, "key.categories.hollowmod"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            ClientHollows.tick(client);
            while (openKey.wasPressed()) {
                if (client.currentScreen instanceof DevMenuScreen) {
                    client.setScreen(null);
                } else if (client.world != null) {
                    client.setScreen(new DevMenuScreen());
                }
            }
        });

        ClientPlayNetworking.registerGlobalReceiver(DevNetworking.SYNC, (client, handler, buf, sender) -> ClientHollows.readSync(buf));
        ClientPlayNetworking.registerGlobalReceiver(DevNetworking.FEEDBACK, (client, handler, buf, sender) -> ClientHollows.readFeedback(buf));

        WorldRenderEvents.AFTER_TRANSLUCENT.register(DistantHollowRenderer::render);

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("hollowdev").executes(ctx -> {
                    MinecraftClient mc = MinecraftClient.getInstance();
                    // queued for the next tick, because the chat screen closes itself right after a command
                    mc.send(() -> mc.setScreen(new DevMenuScreen()));
                    return 1;
                })));
    }

    /** True if this key press is the "open the console" key (used so the same key also closes it). */
    public static boolean isToggleKey(int key, int scan) {
        return openKey != null && openKey.matchesKey(key, scan);
    }

    private DevClient() {
    }
}
