package com.hollowmod.client.dev;

import com.hollowmod.dev.DevNetworking;
import com.hollowmod.dev.HollowInfo;
import com.hollowmod.entity.HollowCoreEntity;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.network.PacketByteBuf;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Everything the client knows about Hollows. Filled by the server sync (every half second), so it also contains Hollows
 * that are far outside the render distance. The dev map reads it, and so does the DistantHollowRenderer.
 */
public final class ClientHollows {

    public static final class LogLine {
        public final long time = System.currentTimeMillis();
        public final boolean error;
        public final String text;

        LogLine(boolean error, String text) {
            this.error = error;
            this.text = text;
        }
    }

    private static final Map<UUID, HollowInfo> MAP = new LinkedHashMap<>();
    private static final Map<UUID, Float> SMOOTH_RADIUS = new HashMap<>();
    private static final Set<UUID> ENTITY_PRESENT = new HashSet<>();
    private static final Deque<LogLine> LOG = new ArrayDeque<>();

    /** Hollow selected on the map (or null). */
    public static UUID selected = null;
    public static long lastSyncMillis = 0L;
    public static int syncCount = 0;

    // server settings echoed in every sync
    public static boolean allowed = false;
    public static boolean swallowEnabled = true;
    public static boolean keepAllLoaded = false;
    public static double mobMassPerHealth = 0.03;

    // ------------------------------------------------------------------ receiving

    public static void readSync(PacketByteBuf buf) {
        boolean ok = buf.readBoolean();
        boolean swallow = buf.readBoolean();
        boolean keepAll = buf.readBoolean();
        double mass = buf.readDouble();
        int n = buf.readVarInt();
        List<HollowInfo> list = new ArrayList<>(n);
        for (int i = 0; i < n; i++) {
            list.add(HollowInfo.read(buf));
        }
        MinecraftClient.getInstance().execute(() -> apply(ok, swallow, keepAll, mass, list));
    }

    private static void apply(boolean ok, boolean swallow, boolean keepAll, double mass, List<HollowInfo> list) {
        allowed = ok;
        swallowEnabled = swallow;
        keepAllLoaded = keepAll;
        mobMassPerHealth = mass;
        Set<UUID> seen = new HashSet<>();
        for (HollowInfo h : list) {
            MAP.put(h.uuid, h);
            seen.add(h.uuid);
            SMOOTH_RADIUS.putIfAbsent(h.uuid, h.radius);
        }
        MAP.keySet().removeIf(id -> !seen.contains(id));
        SMOOTH_RADIUS.keySet().removeIf(id -> !seen.contains(id));
        if (selected != null && !MAP.containsKey(selected)) {
            selected = null;
        }
        lastSyncMillis = System.currentTimeMillis();
        syncCount++;
    }

    public static void readFeedback(PacketByteBuf buf) {
        boolean error = buf.readBoolean();
        String text = buf.readString(400);
        MinecraftClient.getInstance().execute(() -> log(error, text));
    }

    // ------------------------------------------------------------------ log

    public static void log(boolean error, String text) {
        LOG.addLast(new LogLine(error, text));
        while (LOG.size() > 250) {
            LOG.removeFirst();
        }
    }

    public static List<LogLine> logLines() {
        return new ArrayList<>(LOG);
    }

    public static LogLine lastLog() {
        return LOG.peekLast();
    }

    public static void clearLog() {
        LOG.clear();
    }

    // ------------------------------------------------------------------ queries

    public static Collection<HollowInfo> all() {
        return MAP.values();
    }

    public static HollowInfo get(UUID id) {
        return id == null ? null : MAP.get(id);
    }

    public static float smoothRadius(HollowInfo h) {
        Float r = SMOOTH_RADIUS.get(h.uuid);
        return r == null ? h.radius : r;
    }

    public static boolean isEntityPresent(UUID id) {
        return ENTITY_PRESENT.contains(id);
    }

    public static int loadedCount() {
        int n = 0;
        for (HollowInfo h : MAP.values()) {
            if (h.loaded) {
                n++;
            }
        }
        return n;
    }

    /** Distance (blocks) beyond which a Hollow is drawn by the scaled "distant" renderer instead of the entity renderer. */
    public static float entityDrawLimit() {
        int rd = MinecraftClient.getInstance().options.getClampedViewDistance();
        return Math.max(160.0f, rd * 16.0f * 2.4f);
    }

    /** The Hollow the dev menu should act on: the map selection if there is one, else the nearest one in this dimension. */
    public static HollowInfo target() {
        HollowInfo sel = get(selected);
        if (sel != null) {
            return sel;
        }
        return nearestInDimension();
    }

    public static HollowInfo nearestInDimension() {
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null || c.world == null) {
            return null;
        }
        String dim = c.world.getRegistryKey().getValue().toString();
        HollowInfo best = null;
        double bestD = Double.MAX_VALUE;
        for (HollowInfo h : MAP.values()) {
            if (!dim.equals(h.dim)) {
                continue;
            }
            double dx = h.x - c.player.getX();
            double dz = h.z - c.player.getZ();
            double d = dx * dx + dz * dz;
            if (d < bestD) {
                bestD = d;
                best = h;
            }
        }
        return best;
    }

    // ------------------------------------------------------------------ per tick

    public static void tick(MinecraftClient client) {
        // smooth the radius a bit between syncs so the distant dome grows smoothly
        for (HollowInfo h : MAP.values()) {
            float cur = SMOOTH_RADIUS.getOrDefault(h.uuid, h.radius);
            SMOOTH_RADIUS.put(h.uuid, cur + (h.radius - cur) * 0.25f);
        }
        ENTITY_PRESENT.clear();
        if (client.world != null) {
            for (Entity e : client.world.getEntities()) {
                if (e instanceof HollowCoreEntity) {
                    ENTITY_PRESENT.add(e.getUuid());
                }
            }
        }
    }

    // ------------------------------------------------------------------ sending

    /** Asks the server for a fresh sync right now (it also sends one twice a second by itself). */
    public static void requestSync() {
        if (ClientPlayNetworking.canSend(DevNetworking.REQUEST_SYNC)) {
            ClientPlayNetworking.send(DevNetworking.REQUEST_SYNC, PacketByteBufs.create());
        }
    }

    /** Sends a dev action. Use HollowInfo.NONE as the id for global actions. */
    public static void action(UUID id, String action, double a, double b, double c, String s) {
        if (!ClientPlayNetworking.canSend(DevNetworking.ACTION)) {
            log(true, "Cannot send: the server does not have the Hollow mod dev tools (join a world first).");
            return;
        }
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeUuid(id == null ? HollowInfo.NONE : id);
        buf.writeString(action, 32);
        buf.writeDouble(a);
        buf.writeDouble(b);
        buf.writeDouble(c);
        buf.writeString(s == null ? "" : s, 64);
        ClientPlayNetworking.send(DevNetworking.ACTION, buf);
    }

    public static void action(UUID id, String action, double a) {
        action(id, action, a, 0.0, 0.0, "");
    }

    /** Runs a normal chat command (without the leading slash is also fine). */
    public static void command(String cmd) {
        MinecraftClient c = MinecraftClient.getInstance();
        if (c.player == null) {
            return;
        }
        String clean = cmd.startsWith("/") ? cmd.substring(1) : cmd;
        c.player.networkHandler.sendChatCommand(clean);
        log(false, "/" + clean);
    }

    private ClientHollows() {
    }
}
