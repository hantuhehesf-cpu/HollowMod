package com.hollowmod.client.dev;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import org.joml.Matrix4f;

/** Look and drawing helpers of the Hollow dev console: dark glass panels, thin borders, an iridescent accent. */
public final class Ui {

    // ---- palette (ARGB) ----
    public static final int WINDOW = 0xF2101521;
    public static final int SIDEBAR = 0xF20B0F1A;
    public static final int CARD = 0xFF161C2E;
    public static final int CARD_HOVER = 0xFF1C2439;
    public static final int FIELD = 0xFF0D1220;
    public static final int BORDER = 0xFF2A3352;
    public static final int BORDER_SOFT = 0xFF202842;
    public static final int ACCENT = 0xFF7AA2FF;
    public static final int ACCENT_DARK = 0xFF3F5FC4;
    public static final int VIOLET = 0xFFB48CFF;
    public static final int PINK = 0xFFFF7AC8;
    public static final int TEAL = 0xFF5BE3D0;
    public static final int GOOD = 0xFF5BD6A0;
    public static final int WARN = 0xFFFFC857;
    public static final int DANGER = 0xFFFF5C7A;
    public static final int TEXT = 0xFFE8ECF8;
    public static final int MUTED = 0xFF8C95B0;
    public static final int FAINT = 0xFF5A627C;

    // ---- basic shapes ----

    public static boolean in(double mx, double my, int x, int y, int w, int h) {
        return mx >= x && mx < x + w && my >= y && my < y + h;
    }

    public static void rect(DrawContext c, int x, int y, int w, int h, int color) {
        c.fill(x, y, x + w, y + h, color);
    }

    /** Filled rectangle with small rounded corners (radius up to about 4). */
    public static void rrect(DrawContext c, int x, int y, int w, int h, int r, int color) {
        if (r <= 0 || w < 2 * r || h < 2 * r) {
            c.fill(x, y, x + w, y + h, color);
            return;
        }
        c.fill(x + r, y, x + w - r, y + h, color);
        c.fill(x, y + r, x + r, y + h - r, color);
        c.fill(x + w - r, y + r, x + w, y + h - r, color);
        for (int i = 0; i < r; i++) {
            double dy = r - i - 0.5;
            int inset = (int) Math.round(r - Math.sqrt(Math.max(0.0, r * r - dy * dy)));
            c.fill(x + inset, y + i, x + r, y + i + 1, color);
            c.fill(x + w - r, y + i, x + w - inset, y + i + 1, color);
            c.fill(x + inset, y + h - i - 1, x + r, y + h - i, color);
            c.fill(x + w - r, y + h - i - 1, x + w - inset, y + h - i, color);
        }
    }

    /** Rounded panel with a 1px border: border color first, then the fill inset by 1. */
    public static void panel(DrawContext c, int x, int y, int w, int h, int r, int fill, int border) {
        rrect(c, x, y, w, h, r, border);
        rrect(c, x + 1, y + 1, w - 2, h - 2, Math.max(0, r - 1), fill);
    }

    /** Thin iridescent line (blue - violet - pink - teal), the signature accent of the console. */
    public static void accentLine(DrawContext c, int x, int y, int w, int h, int alpha) {
        int a = (alpha & 0xFF) << 24;
        // horizontal sweep made of many flat segments (fillGradient can only go top-to-bottom)
        int steps = Math.max(8, w / 6);
        for (int i = 0; i < steps; i++) {
            float t = i / (float) (steps - 1);
            int col = t < 0.33f ? lerp(ACCENT, VIOLET, t / 0.33f)
                    : (t < 0.66f ? lerp(VIOLET, PINK, (t - 0.33f) / 0.33f) : lerp(PINK, TEAL, (t - 0.66f) / 0.34f));
            int x1 = x + (int) (w * i / (float) steps);
            int x2 = x + (int) (w * (i + 1) / (float) steps);
            c.fill(x1, y, x2, y + h, a | (col & 0xFFFFFF));
        }
    }

    // ---- colors ----

    public static int lerp(int a, int b, float t) {
        t = t < 0 ? 0 : (t > 1 ? 1 : t);
        int aa = (int) (((a >>> 24) & 255) + (((b >>> 24) & 255) - ((a >>> 24) & 255)) * t);
        int ar = (int) (((a >> 16) & 255) + (((b >> 16) & 255) - ((a >> 16) & 255)) * t);
        int ag = (int) (((a >> 8) & 255) + (((b >> 8) & 255) - ((a >> 8) & 255)) * t);
        int ab = (int) ((a & 255) + ((b & 255) - (a & 255)) * t);
        return (aa << 24) | (ar << 16) | (ag << 8) | ab;
    }

    /** Same color with the alpha multiplied (0..1). */
    public static int fade(int color, float alpha) {
        int a = (int) (((color >>> 24) & 255) * Math.max(0.0f, Math.min(1.0f, alpha)));
        return (a << 24) | (color & 0xFFFFFF);
    }

    public static int rgb(int color) {
        return color & 0xFFFFFF;
    }

    // ---- text ----

    public static void text(DrawContext c, TextRenderer tr, String s, int x, int y, int color) {
        c.drawText(tr, s, x, y, color, false);
    }

    public static void textShadow(DrawContext c, TextRenderer tr, String s, int x, int y, int color) {
        c.drawText(tr, s, x, y, color, true);
    }

    public static void textRight(DrawContext c, TextRenderer tr, String s, int right, int y, int color) {
        c.drawText(tr, s, right - tr.getWidth(s), y, color, false);
    }

    public static void textCenter(DrawContext c, TextRenderer tr, String s, int cx, int y, int color) {
        c.drawText(tr, s, cx - tr.getWidth(s) / 2, y, color, false);
    }

    /** Shortens a string with ".." so it fits in maxWidth pixels. */
    public static String fit(TextRenderer tr, String s, int maxWidth) {
        if (maxWidth <= 0) {
            return "";
        }
        if (tr.getWidth(s) <= maxWidth) {
            return s;
        }
        String ell = "..";
        int ew = tr.getWidth(ell);
        int end = s.length();
        while (end > 0 && tr.getWidth(s.substring(0, end)) + ew > maxWidth) {
            end--;
        }
        return s.substring(0, end) + ell;
    }

    // ---- raw shapes (for the map): they use the GPU directly, so flush pending GUI quads first ----

    public static void beginRaw(DrawContext c) {
        c.draw();
        RenderSystem.setShader(GameRenderer::getPositionColorProgram);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.disableCull();
    }

    public static void endRaw() {
        RenderSystem.enableCull();
        RenderSystem.disableBlend();
    }

    private static BufferBuilder begin(VertexFormat.DrawMode mode) {
        BufferBuilder b = Tessellator.getInstance().getBuffer();
        b.begin(mode, VertexFormats.POSITION_COLOR);
        return b;
    }

    private static void v(BufferBuilder b, Matrix4f m, float x, float y, int argb) {
        b.vertex(m, x, y, 0.0f).color((argb >> 16) & 255, (argb >> 8) & 255, argb & 255, (argb >>> 24) & 255).next();
    }

    /** A line with thickness (pixels). Call between beginRaw/endRaw. */
    public static void line(DrawContext c, float x1, float y1, float x2, float y2, float thickness, int argb) {
        float dx = x2 - x1;
        float dy = y2 - y1;
        float len = (float) Math.sqrt(dx * dx + dy * dy);
        if (len < 0.01f) {
            return;
        }
        float nx = -dy / len * thickness * 0.5f;
        float ny = dx / len * thickness * 0.5f;
        Matrix4f m = c.getMatrices().peek().getPositionMatrix();
        BufferBuilder b = begin(VertexFormat.DrawMode.QUADS);
        v(b, m, x1 - nx, y1 - ny, argb);
        v(b, m, x1 + nx, y1 + ny, argb);
        v(b, m, x2 + nx, y2 + ny, argb);
        v(b, m, x2 - nx, y2 - ny, argb);
        BufferRenderer.drawWithGlobalProgram(b.end());
    }

    /** Many lines in one draw call: array of {x1,y1,x2,y2}. */
    public static void lines(DrawContext c, java.util.List<float[]> segs, float thickness, int argb) {
        if (segs.isEmpty()) {
            return;
        }
        Matrix4f m = c.getMatrices().peek().getPositionMatrix();
        BufferBuilder b = begin(VertexFormat.DrawMode.QUADS);
        for (float[] s : segs) {
            float dx = s[2] - s[0];
            float dy = s[3] - s[1];
            float len = (float) Math.sqrt(dx * dx + dy * dy);
            if (len < 0.01f) {
                continue;
            }
            float nx = -dy / len * thickness * 0.5f;
            float ny = dx / len * thickness * 0.5f;
            v(b, m, s[0] - nx, s[1] - ny, argb);
            v(b, m, s[0] + nx, s[1] + ny, argb);
            v(b, m, s[2] + nx, s[3] + ny, argb);
            v(b, m, s[2] - nx, s[3] - ny, argb);
        }
        BufferRenderer.drawWithGlobalProgram(b.end());
    }

    /** Filled ellipse with a color at the center and another at the edge (smooth gradient). */
    public static void ellipse(DrawContext c, float cx, float cy, float rx, float ry, int centerArgb, int edgeArgb) {
        int n = (int) Math.max(24, Math.min(96, Math.max(rx, ry) * 0.8f));
        Matrix4f m = c.getMatrices().peek().getPositionMatrix();
        BufferBuilder b = begin(VertexFormat.DrawMode.TRIANGLE_FAN);
        v(b, m, cx, cy, centerArgb);
        for (int i = 0; i <= n; i++) {
            double a = Math.PI * 2.0 * i / n;
            v(b, m, cx + (float) Math.cos(a) * rx, cy + (float) Math.sin(a) * ry, edgeArgb);
        }
        BufferRenderer.drawWithGlobalProgram(b.end());
    }

    /** Ring (band between two ellipses) with separate inner/outer colors. */
    public static void ring(DrawContext c, float cx, float cy, float rxIn, float ryIn, float rxOut, float ryOut,
                            int innerArgb, int outerArgb) {
        int n = (int) Math.max(32, Math.min(120, Math.max(rxOut, ryOut) * 0.9f));
        Matrix4f m = c.getMatrices().peek().getPositionMatrix();
        BufferBuilder b = begin(VertexFormat.DrawMode.TRIANGLE_STRIP);
        for (int i = 0; i <= n; i++) {
            double a = Math.PI * 2.0 * i / n;
            float ca = (float) Math.cos(a);
            float sa = (float) Math.sin(a);
            v(b, m, cx + ca * rxIn, cy + sa * ryIn, innerArgb);
            v(b, m, cx + ca * rxOut, cy + sa * ryOut, outerArgb);
        }
        BufferRenderer.drawWithGlobalProgram(b.end());
    }

    /** Arc band from angle a0 to a1 (radians), for progress rings. */
    public static void arc(DrawContext c, float cx, float cy, float rIn, float rOut, double a0, double a1, int argb) {
        int n = Math.max(6, (int) (Math.abs(a1 - a0) * rOut * 0.5));
        Matrix4f m = c.getMatrices().peek().getPositionMatrix();
        BufferBuilder b = begin(VertexFormat.DrawMode.TRIANGLE_STRIP);
        for (int i = 0; i <= n; i++) {
            double a = a0 + (a1 - a0) * i / n;
            float ca = (float) Math.cos(a);
            float sa = (float) Math.sin(a);
            v(b, m, cx + ca * rIn, cy + sa * rIn, argb);
            v(b, m, cx + ca * rOut, cy + sa * rOut, argb);
        }
        BufferRenderer.drawWithGlobalProgram(b.end());
    }

    public static void triangle(DrawContext c, float x1, float y1, float x2, float y2, float x3, float y3, int argb) {
        Matrix4f m = c.getMatrices().peek().getPositionMatrix();
        BufferBuilder b = begin(VertexFormat.DrawMode.TRIANGLES);
        v(b, m, x1, y1, argb);
        v(b, m, x2, y2, argb);
        v(b, m, x3, y3, argb);
        BufferRenderer.drawWithGlobalProgram(b.end());
    }

    private Ui() {
    }
}
