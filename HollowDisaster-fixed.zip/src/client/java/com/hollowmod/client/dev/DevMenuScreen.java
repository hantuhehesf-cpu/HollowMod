package com.hollowmod.client.dev;

import com.hollowmod.client.visual.HollowVisualConfig;
import com.hollowmod.client.visual.VisualMath;
import com.hollowmod.dev.HollowInfo;
import net.minecraft.SharedConstants;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * The Hollow Dev Console. Open it with the key (default F8, change it in Controls -> "Hollow Disaster") or by typing
 * /hollowdev in chat. It does not pause the game, so you can watch the world change while you test.
 *
 * Layout: sidebar with the pages on the left, a search bar on top, the page (or the Hollow map) in the middle,
 * a status bar at the bottom that shows the latest answer of the server.
 */
public final class DevMenuScreen extends Screen {

    private final List<DevPages.Tab> tabs;
    private int tabIndex = 0;
    private final Rows.RowList list = new Rows.RowList();
    private final HollowMapView map;
    private final Widgets.TextBox search;
    private final Widgets.Button hideButton;
    private final Widgets.Button closeButton;
    private boolean hidden = false;
    private boolean searching = false;

    private long lastNanos = System.nanoTime();
    private float fps = 60.0f;
    private float openAnim = 0.0f;
    private int winX;
    private int winY;
    private int winW;
    private int winH;
    private int sideW;

    public DevMenuScreen() {
        super(Text.literal("Hollow Dev Console"));
        this.map = new HollowMapView(this);
        this.tabs = DevPages.build(this);
        this.search = new Widgets.TextBox("Search tools, commands, settings...   (Ctrl+F)", "");
        this.search.maxLen = 60;
        this.search.onChange = t -> rebuildResults();
        this.hideButton = new Widgets.Button("Hide", Widgets.Button.Style.SECONDARY, this::hide);
        this.closeButton = new Widgets.Button("X", Widgets.Button.Style.DANGER, this::close);
        list.setRows(tabs.get(0).rows);
    }

    // ------------------------------------------------------------------ used by the pages

    public int fps() {
        return Math.round(fps);
    }

    public void hide() {
        hidden = true;
        Widgets.TextBox.blurAll();
    }

    public void gotoTab(String id) {
        for (int i = 0; i < tabs.size(); i++) {
            if (tabs.get(i).id.equals(id)) {
                tabIndex = i;
                search.setText("");
                searching = false;
                list.showSection = false;
                list.setRows(tabs.get(i).rows);
                Widgets.TextBox.blurAll();
                return;
            }
        }
    }

    /** Starts a "click a spot on the map" action for the Hollow the console is aimed at. */
    public void startPick(HollowMapView.Pick mode) {
        HollowInfo t = ClientHollows.target();
        if (t == null) {
            ClientHollows.log(true, "No Hollow to aim at. Spawn one first.");
            return;
        }
        ClientHollows.selected = t.uuid;
        gotoTab("map");
        map.startPick(mode, t.uuid);
    }

    public void copyReport() {
        MinecraftClient mc = MinecraftClient.getInstance();
        StringBuilder sb = new StringBuilder();
        sb.append("=== Hollow Disaster debug report ===\n");
        sb.append("Minecraft ").append(SharedConstants.getGameVersion().getName()).append("\n");
        sb.append("FPS ").append(fps()).append("\n");
        if (mc.world != null && mc.player != null) {
            sb.append("Dimension ").append(mc.world.getRegistryKey().getValue()).append("\n");
            sb.append(String.format(Locale.ROOT, "Player %.1f %.1f %.1f%n", mc.player.getX(), mc.player.getY(), mc.player.getZ()));
        }
        sb.append("Dev permission ").append(ClientHollows.allowed).append("\n");
        sb.append("Swallow ").append(ClientHollows.swallowEnabled).append("  keepAllLoaded ").append(ClientHollows.keepAllLoaded)
                .append("  mobMass ").append(ClientHollows.mobMassPerHealth).append("\n");
        sb.append("Visuals: mood=").append(HollowVisualConfig.mood).append(" quality=").append(HollowVisualConfig.quality)
                .append(" fx=").append(HollowVisualConfig.screenFxPercent).append(" distant=").append(HollowVisualConfig.distantHollows).append("\n");
        sb.append("Hollows (").append(ClientHollows.all().size()).append("):\n");
        for (HollowInfo h : ClientHollows.all()) {
            sb.append(String.format(Locale.ROOT, " H-%s dim=%s pos=%.0f,%.0f,%.0f r=%.1f/%.1f act=%.1f gauge=%.1f gen=%d kids=%d%s%s%s%s%n",
                    h.shortId(), h.dim, h.x, h.y, h.z, h.radius, h.maxRadius, h.activity, h.gauge, h.generation, h.children,
                    h.loaded ? "" : " UNLOADED", h.frozen ? " FROZEN" : "", h.kept ? " KEPT" : "",
                    h.collapseTicks >= 0 ? " COLLAPSING" : ""));
        }
        sb.append("Log:\n");
        List<ClientHollows.LogLine> lines = ClientHollows.logLines();
        for (int i = Math.max(0, lines.size() - 40); i < lines.size(); i++) {
            sb.append(lines.get(i).error ? " ! " : "   ").append(lines.get(i).text).append("\n");
        }
        mc.keyboard.setClipboard(sb.toString());
        ClientHollows.log(false, "Debug report copied to the clipboard (" + sb.length() + " characters).");
    }

    // ------------------------------------------------------------------ search

    private void rebuildResults() {
        String q = search.text.trim().toLowerCase(Locale.ROOT);
        if (q.isEmpty()) {
            searching = false;
            list.showSection = false;
            list.setRows(tabs.get(tabIndex).rows);
            return;
        }
        searching = true;
        list.showSection = true;
        String[] tokens = q.split("\\s+");
        List<Rows.Row> out = new ArrayList<>();
        for (DevPages.Tab t : tabs) {
            String name = t.name.toLowerCase(Locale.ROOT);
            boolean all = true;
            for (String tok : tokens) {
                if (!name.contains(tok) && !("go to open " + t.id).contains(tok)) {
                    all = false;
                    break;
                }
            }
            if (all) {
                Rows.Action nav = new Rows.Action("Go to " + t.name, "Open", Widgets.Button.Style.PRIMARY, () -> gotoTab(t.id));
                nav.section = "Navigate";
                out.add(nav);
            }
        }
        for (DevPages.Tab t : tabs) {
            for (Rows.Row r : t.rows) {
                String text = r.searchText();
                if (text.isEmpty()) {
                    continue;
                }
                boolean all = true;
                for (String tok : tokens) {
                    if (!text.contains(tok)) {
                        all = false;
                        break;
                    }
                }
                if (all) {
                    out.add(r);
                }
            }
        }
        if (out.isEmpty()) {
            Rows.Info none = new Rows.Info("Nothing found for \"" + search.text.trim() + "\"", () -> "try another word");
            out.add(none);
        }
        list.setRows(out);
    }

    // ------------------------------------------------------------------ screen basics

    @Override
    protected void init() {
        ClientHollows.requestSync();
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public boolean shouldCloseOnEsc() {
        return false;
    }

    @Override
    public void removed() {
        Widgets.TextBox.blurAll();
        map.cancelPick();
    }

    // ------------------------------------------------------------------ rendering

    @Override
    public void render(DrawContext ctx, int mx, int my, float tickDelta) {
        long now = System.nanoTime();
        float dt = Math.min(0.1f, (now - lastNanos) / 1.0e9f);
        lastNanos = now;
        if (dt > 0.0f) {
            fps += ((1.0f / dt) - fps) * 0.05f;
        }
        openAnim = Math.min(1.0f, openAnim + dt * 6.0f);

        if (hidden) {
            int pw = 150;
            int px = (width - pw) / 2;
            boolean over = Ui.in(mx, my, px, 6, pw, 18);
            Ui.panel(ctx, px, 6, pw, 18, 4, over ? 0xF0202A48 : 0xE0101521, over ? Ui.ACCENT : Ui.BORDER);
            Ui.textCenter(ctx, textRenderer, "Hollow Console  -  click", width / 2, 11, over ? 0xFFFFFFFF : Ui.MUTED);
            return;
        }

        ctx.fill(0, 0, width, height, (int) (0x66 * openAnim) << 24);

        int margin = width < 520 ? 4 : 10;
        winW = Math.min(width - margin * 2, 880);
        winH = Math.min(height - margin * 2, 540);
        winX = (width - winW) / 2;
        winY = (height - winH) / 2 + (int) ((1.0f - openAnim) * 10);
        sideW = winW < 500 ? 84 : 126;

        // window
        Ui.rrect(ctx, winX - 2, winY - 2, winW + 4, winH + 4, 6, 0x40000000);
        Ui.panel(ctx, winX, winY, winW, winH, 5, Ui.WINDOW, Ui.BORDER);
        Ui.accentLine(ctx, winX + 4, winY, winW - 8, 2, 255);

        drawSidebar(ctx, mx, my);

        int mainX = winX + sideW + 8;
        int mainW = winW - sideW - 16;
        int topY = winY + 8;

        // top bar: search + hide + close
        int closeX = mainX + mainW - 22;
        int hideX = closeX - 4 - 46;
        search.bounds(mainX, topY, hideX - 4 - mainX, 22);
        search.render(ctx, textRenderer, mx, my, dt);
        hideButton.bounds(hideX, topY, 46, 22);
        closeButton.bounds(closeX, topY, 22, 22);
        hideButton.render(ctx, textRenderer, mx, my, dt);
        closeButton.render(ctx, textRenderer, mx, my, dt);

        int contentY = topY + 22 + 8;
        int statusH = 18;
        int contentH = winY + winH - statusH - 6 - contentY;
        DevPages.Tab tab = tabs.get(tabIndex);

        // content
        if (tab.isMap && !searching) {
            map.layout(mainX, contentY, mainW, contentH);
            Ui.panel(ctx, mainX - 1, contentY - 1, mainW + 2, contentH + 2, 3, 0xFFF8FAFD, Ui.BORDER);
            map.render(ctx, textRenderer, mx, my, dt);
        } else {
            drawPageTitle(ctx, tab, mainX, contentY);
            list.bounds(mainX, contentY + 18, mainW, contentH - 18);
            list.render(ctx, textRenderer, mx, my, dt);
        }

        drawStatusBar(ctx, mainX, winY + winH - statusH - 4, mainW, statusH);
    }

    private void drawPageTitle(DrawContext ctx, DevPages.Tab tab, int x, int y) {
        String title = searching ? "Search results" : tab.name;
        Ui.textShadow(ctx, textRenderer, title, x + 2, y + 2, Ui.TEXT);
        if (searching) {
            Ui.text(ctx, textRenderer, "everything you type is matched against all titles, descriptions and tags",
                    x + 2 + textRenderer.getWidth(title) + 8, y + 2, Ui.FAINT);
        }
    }

    private void drawSidebar(DrawContext ctx, int mx, int my) {
        int sx = winX + 1;
        int sy = winY + 3;
        int sh = winH - 4;
        Ui.rrect(ctx, sx, sy, sideW, sh, 4, Ui.SIDEBAR);
        Ui.rect(ctx, sx + sideW - 1, sy + 4, 1, sh - 8, Ui.BORDER_SOFT);

        // logo: HOLLOW in slowly shifting rainbow letters
        String logo = "HOLLOW";
        float t = (System.currentTimeMillis() % 20000L) / 20000.0f * 360.0f;
        float[] rgb = new float[3];
        int lx = sx + 12;
        for (int i = 0; i < logo.length(); i++) {
            VisualMath.hsv(t + i * 32.0f, 0.55f, 1.0f, rgb);
            int col = 0xFF000000 | (VisualMath.to255(rgb[0]) << 16) | (VisualMath.to255(rgb[1]) << 8) | VisualMath.to255(rgb[2]);
            String ch = String.valueOf(logo.charAt(i));
            Ui.textShadow(ctx, textRenderer, ch, lx, sy + 10, col);
            lx += textRenderer.getWidth(ch) + 1;
        }
        Ui.text(ctx, textRenderer, "DEV CONSOLE", sx + 12, sy + 22, Ui.FAINT);

        int ty = sy + 44;
        for (int i = 0; i < tabs.size(); i++) {
            DevPages.Tab tab = tabs.get(i);
            boolean active = i == tabIndex && !searching;
            boolean over = Ui.in(mx, my, sx + 4, ty, sideW - 8, 22);
            if (active) {
                Ui.rrect(ctx, sx + 4, ty, sideW - 8, 22, 3, 0xFF1B2440);
                Ui.rrect(ctx, sx + 4, ty + 4, 2, 14, 1, tab.color);
            } else if (over) {
                Ui.rrect(ctx, sx + 4, ty, sideW - 8, 22, 3, 0xFF141A2D);
            }
            Ui.rrect(ctx, sx + 12, ty + 7, 8, 8, 2, active || over ? tab.color : Ui.fade(tab.color, 0.55f));
            if (sideW >= 100) {
                Ui.text(ctx, textRenderer, Ui.fit(textRenderer, tab.name, sideW - 40), sx + 26, ty + 7, active ? Ui.TEXT : Ui.MUTED);
            }
            ty += 24;
        }

        // bottom of the sidebar: live numbers
        int by = sy + sh - 46;
        Ui.text(ctx, textRenderer, fps() + " FPS", sx + 12, by, fps() >= 45 ? Ui.GOOD : (fps() >= 25 ? Ui.WARN : Ui.DANGER));
        Ui.text(ctx, textRenderer, ClientHollows.loadedCount() + " Hollows", sx + 12, by + 11, Ui.MUTED);
        Ui.text(ctx, textRenderer, ClientHollows.allowed ? "dev access" : "NO ACCESS", sx + 12, by + 22, ClientHollows.allowed ? Ui.FAINT : Ui.DANGER);
    }

    private void drawStatusBar(DrawContext ctx, int x, int y, int w, int h) {
        Ui.panel(ctx, x, y, w, h, 3, 0xFF0D1220, Ui.BORDER_SOFT);
        ClientHollows.LogLine last = ClientHollows.lastLog();
        if (last != null && System.currentTimeMillis() - last.time < 12000L) {
            float a = Math.min(1.0f, (12000L - (System.currentTimeMillis() - last.time)) / 3000.0f);
            int col = Ui.fade(last.error ? Ui.DANGER : Ui.GOOD, 0.5f + 0.5f * a);
            Ui.rrect(ctx, x + 5, y + 5, 3, h - 10, 1, col);
            Ui.text(ctx, textRenderer, Ui.fit(textRenderer, last.text, w - 20), x + 13, y + (h - textRenderer.fontHeight) / 2 + 1, Ui.TEXT);
        } else {
            Ui.text(ctx, textRenderer, "Ctrl+F search   H hide   Esc close   (the game keeps running behind this window)",
                    x + 8, y + (h - textRenderer.fontHeight) / 2 + 1, Ui.FAINT);
        }
    }

    // ------------------------------------------------------------------ input

    @Override
    public boolean mouseClicked(double mx, double my, int button) {
        if (hidden) {
            if (Ui.in(mx, my, (width - 150) / 2, 6, 150, 18)) {
                hidden = false;
                openAnim = 0.6f;
            }
            return true;
        }
        Widgets.TextBox.blurAll();

        if (hideButton.mouseClicked(mx, my, button) || closeButton.mouseClicked(mx, my, button)) {
            return true;
        }
        if (search.mouseClicked(mx, my, button)) {
            return true;
        }
        // sidebar tabs
        int ty = winY + 3 + 44;
        for (int i = 0; i < tabs.size(); i++) {
            if (button == 0 && Ui.in(mx, my, winX + 5, ty, sideW - 8, 22)) {
                gotoTab(tabs.get(i).id);
                return true;
            }
            ty += 24;
        }
        DevPages.Tab tab = tabs.get(tabIndex);
        if (tab.isMap && !searching) {
            return map.mouseClicked(mx, my, button);
        }
        return list.mouseClicked(mx, my, button);
    }

    @Override
    public boolean mouseDragged(double mx, double my, int button, double dx, double dy) {
        if (hidden) {
            return false;
        }
        if (tabs.get(tabIndex).isMap && !searching) {
            return map.mouseDragged(mx, my, button, dx, dy);
        }
        return list.mouseDragged(mx, my, button, dx, dy);
    }

    @Override
    public boolean mouseReleased(double mx, double my, int button) {
        if (hidden) {
            return false;
        }
        if (tabs.get(tabIndex).isMap && !searching) {
            return map.mouseReleased(mx, my, button);
        }
        return list.mouseReleased(mx, my, button);
    }

    @Override
    public boolean mouseScrolled(double mx, double my, double amount) {
        if (hidden) {
            return false;
        }
        if (tabs.get(tabIndex).isMap && !searching) {
            return map.mouseScrolled(mx, my, amount);
        }
        return list.mouseScrolled(mx, my, amount);
    }

    @Override
    public boolean keyPressed(int key, int scan, int mods) {
        if (Widgets.TextBox.hasFocus()) {
            Widgets.TextBox.dispatchKey(key, scan, mods);
            return true;
        }
        if (hidden) {
            if (key == GLFW.GLFW_KEY_H || key == GLFW.GLFW_KEY_ESCAPE || DevClient.isToggleKey(key, scan)) {
                hidden = false;
            }
            return true;
        }
        if (key == GLFW.GLFW_KEY_ESCAPE) {
            if (searching) {
                search.setText("");
                rebuildResults();
                return true;
            }
            if (tabs.get(tabIndex).isMap && map.escape()) {
                return true;
            }
            close();
            return true;
        }
        if (DevClient.isToggleKey(key, scan)) {
            close();
            return true;
        }
        if (key == GLFW.GLFW_KEY_F && Screen.hasControlDown()) {
            search.focus();
            return true;
        }
        if (key == GLFW.GLFW_KEY_H) {
            hide();
            return true;
        }
        return false;
    }

    @Override
    public boolean charTyped(char ch, int modifiers) {
        return Widgets.TextBox.dispatchChar(ch);
    }

    @Override
    public void close() {
        MinecraftClient.getInstance().setScreen(null);
    }
}
