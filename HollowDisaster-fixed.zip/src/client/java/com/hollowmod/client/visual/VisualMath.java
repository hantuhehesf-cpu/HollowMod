package com.hollowmod.client.visual;

/** Tiny math helpers shared by all the Hollow visual code. */
public final class VisualMath {

    public static float clamp01(float v) {
        return v < 0.0f ? 0.0f : (v > 1.0f ? 1.0f : v);
    }

    public static float lerp(float a, float b, float t) {
        return a + (b - a) * t;
    }

    /** Smooth 0..1 ease (no hard edges). */
    public static float smooth(float t) {
        t = clamp01(t);
        return t * t * (3.0f - 2.0f * t);
    }

    /** Converts 0..1 float to a 0..255 int (clamped). */
    public static int to255(float v) {
        int i = (int) (v * 255.0f + 0.5f);
        return i < 0 ? 0 : (i > 255 ? 255 : i);
    }

    /** Clamps an already 0..255 style float to an int. */
    public static int clamp255(float v) {
        int i = (int) (v + 0.5f);
        return i < 0 ? 0 : (i > 255 ? 255 : i);
    }

    /** Hue in degrees (any number), saturation and value 0..1. Writes red, green, blue (0..1) into out[0..2]. */
    public static void hsv(float hueDeg, float s, float v, float[] out) {
        float h = hueDeg % 360.0f;
        if (h < 0.0f) {
            h += 360.0f;
        }
        h /= 60.0f;
        int sector = (int) h;
        float f = h - sector;
        float p = v * (1.0f - s);
        float q = v * (1.0f - s * f);
        float t = v * (1.0f - s * (1.0f - f));
        switch (sector) {
            case 0 -> set(out, v, t, p);
            case 1 -> set(out, q, v, p);
            case 2 -> set(out, p, v, t);
            case 3 -> set(out, p, q, v);
            case 4 -> set(out, t, p, v);
            default -> set(out, v, p, q);
        }
    }

    private static void set(float[] out, float r, float g, float b) {
        out[0] = r;
        out[1] = g;
        out[2] = b;
    }

    /** Cheap deterministic pseudo random number 0..1 from an int. */
    public static float hash(int n) {
        int x = n * 0x27d4eb2d;
        x ^= x >>> 15;
        x *= 0x85ebca6b;
        x ^= x >>> 13;
        return (x & 0xFFFFFF) / 16777216.0f;
    }

    private VisualMath() {
    }
}
