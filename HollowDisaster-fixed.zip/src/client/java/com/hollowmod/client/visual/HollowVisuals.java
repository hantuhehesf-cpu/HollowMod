package com.hollowmod.client.visual;

import com.hollowmod.registry.ModDimensions;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.FabricClientCommandSource;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.DimensionRenderingRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.text.Text;

import java.util.Locale;

/**
 * Hooks every Hollow visual into the game (called once from HollowModClient).
 *  - sky of the Hollow dimension     (HollowSkyRenderer)
 *  - screen effect                   (HollowScreenFx)
 *  - rain + floating particles       (HollowAtmosphere)
 *  - the /hollowvisual command to change settings while playing (works in any world, client side only)
 */
public final class HollowVisuals {

    public static void register() {
        HollowVisualConfig.load();

        DimensionRenderingRegistry.registerSkyRenderer(ModDimensions.HOLLOW_DIMENSION_KEY, new HollowSkyRenderer());
        HudRenderCallback.EVENT.register(HollowScreenFx::render);
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            HollowScreenFx.tick(client);
            HollowAtmosphere.tick(client);
        });
        WorldRenderEvents.AFTER_TRANSLUCENT.register(HollowAtmosphere::renderRain);
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> registerCommands(dispatcher));
    }

    // ------------------------------------------------------------------ /hollowvisual

    private static int say(CommandContext<FabricClientCommandSource> ctx, String message) {
        ctx.getSource().sendFeedback(Text.literal(message));
        return 1;
    }

    private static LiteralArgumentBuilder<FabricClientCommandSource> percentSetting(String name, int min, int max,
                                                                                    java.util.function.IntConsumer setter) {
        return ClientCommandManager.literal(name)
                .then(ClientCommandManager.argument("percent", IntegerArgumentType.integer(min, max))
                        .executes(ctx -> {
                            int v = IntegerArgumentType.getInteger(ctx, "percent");
                            setter.accept(v);
                            HollowVisualConfig.save();
                            return say(ctx, name + " = " + v);
                        }));
    }

    private static void registerCommands(CommandDispatcher<FabricClientCommandSource> dispatcher) {
        LiteralArgumentBuilder<FabricClientCommandSource> root = ClientCommandManager.literal("hollowvisual");

        // mood
        LiteralArgumentBuilder<FabricClientCommandSource> mood = ClientCommandManager.literal("mood");
        for (HollowVisualConfig.Mood m : HollowVisualConfig.Mood.values()) {
            mood.then(ClientCommandManager.literal(m.name().toLowerCase(Locale.ROOT)).executes(ctx -> {
                HollowVisualConfig.mood = m;
                HollowVisualConfig.save();
                return say(ctx, "Hollow sky mood: " + m.name().toLowerCase(Locale.ROOT));
            }));
        }
        root.then(mood);

        // quality
        LiteralArgumentBuilder<FabricClientCommandSource> quality = ClientCommandManager.literal("quality");
        for (HollowVisualConfig.Quality q : HollowVisualConfig.Quality.values()) {
            quality.then(ClientCommandManager.literal(q.name().toLowerCase(Locale.ROOT)).executes(ctx -> {
                HollowVisualConfig.quality = q;
                HollowVisualConfig.save();
                return say(ctx, "Hollow dome quality: " + q.name().toLowerCase(Locale.ROOT)
                        + " (" + q.lat + " x " + q.lon + " bands)");
            }));
        }
        root.then(quality);

        // sky detail on/off
        root.then(ClientCommandManager.literal("skydetail")
                .then(ClientCommandManager.literal("on").executes(ctx -> {
                    HollowVisualConfig.skyDetail = true;
                    HollowVisualConfig.save();
                    return say(ctx, "Sky detail: on (clouds, glow, aurora)");
                }))
                .then(ClientCommandManager.literal("off").executes(ctx -> {
                    HollowVisualConfig.skyDetail = false;
                    HollowVisualConfig.save();
                    return say(ctx, "Sky detail: off (plain gradient)");
                })));

        // strengths (0-100)
        root.then(percentSetting("fx", 0, 100, v -> HollowVisualConfig.screenFxPercent = v));
        root.then(percentSetting("rain", 0, 100, v -> HollowVisualConfig.rainPercent = v));
        root.then(percentSetting("particles", 0, 100, v -> HollowVisualConfig.particlePercent = v));
        root.then(percentSetting("aurora", 0, 100, v -> HollowVisualConfig.auroraPercent = v));
        root.then(percentSetting("brightness", 20, 200, v -> HollowVisualConfig.domeBrightnessPercent = v));

        // status
        root.then(ClientCommandManager.literal("status").executes(ctx -> say(ctx,
                "mood=" + HollowVisualConfig.mood.name().toLowerCase(Locale.ROOT)
                        + " quality=" + HollowVisualConfig.quality.name().toLowerCase(Locale.ROOT)
                        + " fx=" + HollowVisualConfig.screenFxPercent
                        + " rain=" + HollowVisualConfig.rainPercent
                        + " particles=" + HollowVisualConfig.particlePercent
                        + " aurora=" + HollowVisualConfig.auroraPercent
                        + " brightness=" + HollowVisualConfig.domeBrightnessPercent
                        + " skydetail=" + HollowVisualConfig.skyDetail)));

        dispatcher.register(root);
    }

    private HollowVisuals() {
    }
}
