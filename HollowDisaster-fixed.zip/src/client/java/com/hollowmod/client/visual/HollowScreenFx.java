package com.hollowmod.client.visual;

import com.hollowmod.entity.HollowCoreEntity;
import com.hollowmod.registry.ModDimensions;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.entity.Entity;

import java.util.Random;

/**
 * The "Hollow" screen look (reference image 3): faint scanlines, a slow tracking bar, an iridescent vignette,
 * red/cyan color fringes at the screen edges and sometimes a short glitch.
 * It is drawn over the HUD with plain filled rectangles, so it works on any renderer.
 * Strength: inside the Hollow dimension a constant calm level, and outside it grows when you get close to a dome
 * (full strength inside the dome). Scale everything with /hollowvisual fx <0-100>.
 */
public final class HollowScreenFx {

    private static final Random RNG = new Random();
    private static final float[] RGB = new float[3];

    private static float intensity = 0.0f;
    private static float nearDome = 0.0f;
    private static float tickCount = 0.0f;
    private static int glitchTicks = 0;
    private static int glitchSeed = 0;

    public static void tick(MinecraftClient client) {
        if (client.world == null || client.player == null) {
            intensity = 0.0f;
            return;
        }
        tickCount += 1.0f;

        float base = client.world.getRegistryKey() == ModDimensions.HOLLOW_DIMENSION_KEY ? 0.35f : 0.0f;

        // Looking through every entity each tick is wasteful, so check the domes twice a second.
        if (client.world.getTime() % 10L == 0L) {
            nearDome = computeNearDome(client);
        }

        float target = Math.max(base, nearDome) * (HollowVisualConfig.screenFxPercent / 100.0f) * 1.4f;
        intensity += (target - intensity) * 0.08f;
        if (intensity < 0.003f) {
            intensity = 0.0f;
        }

        if (glitchTicks > 0) {
            glitchTicks--;
        } else if (intensity > 0.02f && RNG.nextFloat() < 0.025f + intensity * 0.06f) {
            glitchTicks = 2 + RNG.nextInt(4);
            glitchSeed = RNG.nextInt();
        }
    }

    /** 0 = far from any dome, 1 = touching or inside one. Fades in over the last 48 blocks. */
    private static float computeNearDome(MinecraftClient client) {
        float best = 0.0f;
        for (Entity e : client.world.getEntities()) {
            if (e instanceof HollowCoreEntity core) {
                float radius = core.getCurrentRadius();
                double d = core.getPos().distanceTo(client.player.getPos()) - radius;
                float f = VisualMath.clamp01(1.0f - (float) (d / 48.0));
                best = Math.max(best, f);
            }
        }
        return best;
    }

    public static void render(DrawContext ctx, float tickDelta) {
        if (intensity <= 0.0f) {
            return;
        }
        int w = ctx.getScaledWindowWidth();
        int h = ctx.getScaledWindowHeight();
        float time = tickCount + tickDelta;
        float k = VisualMath.clamp01(intensity);

        // ---- scanlines
        int lineAlpha = (int) (14.0f + 46.0f * k);
        int lineColor = lineAlpha << 24;
        for (int y = 0; y < h; y += 2) {
            ctx.fill(0, y, w, y + 1, lineColor);
        }

        // ---- slow tracking bar moving down the screen
        int barY = (int) (((time * 0.9f) % (h + 60)) - 30);
        int barAlpha = (int) (10.0f + 30.0f * k);
        ctx.fillGradient(0, barY, w, barY + 14, 0x00FFFFFF, (barAlpha << 24) | 0xFFFFFF);
        ctx.fillGradient(0, barY + 14, w, barY + 28, (barAlpha << 24) | 0xFFFFFF, 0x00FFFFFF);

        // ---- iridescent vignette
        VisualMath.hsv(time * 1.6f, 0.55f, 1.0f, RGB);
        int vr = VisualMath.to255(RGB[0]);
        int vg = VisualMath.to255(RGB[1]);
        int vb = VisualMath.to255(RGB[2]);
        int rgb = (vr << 16) | (vg << 8) | vb;
        int steps = 11;
        for (int i = 0; i < steps; i++) {
            float f = 1.0f - i / (float) steps;
            int a = (int) (k * 90.0f * f * f);
            if (a <= 0) {
                continue;
            }
            int col = (a << 24) | rgb;
            int o = i * 3;
            ctx.fill(o, 0, o + 3, h, col);
            ctx.fill(w - o - 3, 0, w - o, h, col);
            ctx.fill(0, o, w, o + 3, col);
            ctx.fill(0, h - o - 3, w, h - o, col);
        }

        // ---- red / cyan color fringes at the left and right edge
        int fringeAlpha = (int) (70.0f * k);
        ctx.fill(0, 0, 2, h, (fringeAlpha << 24) | 0xFF2850);
        ctx.fill(w - 2, 0, w, h, (fringeAlpha << 24) | 0x28E6FF);

        // ---- short glitch bursts
        if (glitchTicks > 0) {
            Random r = new Random(glitchSeed + glitchTicks);
            int bands = 1 + r.nextInt(3);
            for (int i = 0; i < bands; i++) {
                int by = r.nextInt(Math.max(1, h - 12));
                int bh = 2 + r.nextInt(9);
                int shift = r.nextInt(24) - 12;
                boolean magenta = r.nextBoolean();
                int tint = magenta ? 0xFF3CC8 : 0x3CFFF0;
                int ga = (int) (36.0f + 60.0f * k);
                ctx.fill(Math.max(0, shift), by, w, by + bh, (ga << 24) | tint);
                ctx.fill(0, by + bh, w, by + bh + 1, ((ga / 2) << 24) | 0xFFFFFF);
            }
            int specks = 10;
            for (int i = 0; i < specks; i++) {
                int sx = r.nextInt(Math.max(1, w - 4));
                int sy = r.nextInt(Math.max(1, h - 2));
                ctx.fill(sx, sy, sx + 2 + r.nextInt(4), sy + 1, 0x50FFFFFF);
            }
        }
    }

    private HollowScreenFx() {
    }
}
