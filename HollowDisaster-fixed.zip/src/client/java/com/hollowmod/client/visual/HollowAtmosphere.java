package com.hollowmod.client.visual;

import com.hollowmod.registry.ModDimensions;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.Heightmap;
import org.joml.Matrix4f;

import java.util.Random;

/**
 * Things that fill the air inside the Hollow (reference image 4):
 *  - rain streaks (only in the AURORA_RAIN mood). They are drawn by us, not by vanilla weather, so they work in any
 *    weather and they do not fall under roofs (we check the height of the highest block above each streak).
 *  - floating ash flakes and a few glowing ether motes around the player.
 */
public final class HollowAtmosphere {

    private static final Random RNG = new Random();

    private static final float HALF = 18.0f;      // rain area: 36 x 36 blocks around the camera
    private static final float HEIGHT = 26.0f;    // rain area height
    private static final float STREAK_LEN = 1.3f;
    private static final int MAX_STREAKS = 420;

    private static boolean inHollow(ClientWorld world) {
        return world != null && world.getRegistryKey() == ModDimensions.HOLLOW_DIMENSION_KEY;
    }

    // ------------------------------------------------------------------ particles (every client tick)

    public static void tick(MinecraftClient client) {
        ClientWorld world = client.world;
        if (!inHollow(world) || client.player == null || client.isPaused()) {
            return;
        }
        float amount = HollowVisualConfig.particlePercent / 100.0f;
        if (amount <= 0.0f) {
            return;
        }
        double px = client.player.getX();
        double py = client.player.getY();
        double pz = client.player.getZ();

        // drifting ash flakes (debris dust)
        int ash = (int) Math.ceil(4.0f * amount);
        for (int i = 0; i < ash; i++) {
            double x = px + (RNG.nextDouble() * 2.0 - 1.0) * 24.0;
            double y = py + 1.0 + RNG.nextDouble() * 16.0;
            double z = pz + (RNG.nextDouble() * 2.0 - 1.0) * 24.0;
            world.addParticle(ParticleTypes.ASH, x, y, z, 0.0, 0.0, 0.0);
        }
        // faint purple ether motes rising slowly
        if (RNG.nextFloat() < 0.5f * amount) {
            double x = px + (RNG.nextDouble() * 2.0 - 1.0) * 20.0;
            double y = py + RNG.nextDouble() * 6.0;
            double z = pz + (RNG.nextDouble() * 2.0 - 1.0) * 20.0;
            world.addParticle(ParticleTypes.REVERSE_PORTAL, x, y, z, 0.0, 0.02, 0.0);
        }
        // rare bright sparkles
        if (RNG.nextFloat() < 0.15f * amount) {
            double x = px + (RNG.nextDouble() * 2.0 - 1.0) * 16.0;
            double y = py + 1.0 + RNG.nextDouble() * 8.0;
            double z = pz + (RNG.nextDouble() * 2.0 - 1.0) * 16.0;
            world.addParticle(ParticleTypes.END_ROD, x, y, z, 0.0, -0.01, 0.0);
        }
    }

    // ------------------------------------------------------------------ rain (every frame)

    private static double wrap(double v, double m) {
        v %= m;
        return v < 0.0 ? v + m : v;
    }

    public static void renderRain(WorldRenderContext ctx) {
        ClientWorld world = ctx.world();
        if (!inHollow(world) || HollowVisualConfig.mood != HollowVisualConfig.Mood.AURORA_RAIN) {
            return;
        }
        int count = (int) (MAX_STREAKS * HollowVisualConfig.rainPercent / 100.0f);
        if (count <= 0) {
            return;
        }

        Vec3d cam = ctx.camera().getPos();
        float time = (world.getTime() + ctx.tickDelta()) / 20.0f;
        float yawRad = ctx.camera().getYaw() * MathHelper.RADIANS_PER_DEGREE;
        // sideways direction of the screen, so each streak is a thin ribbon facing us
        float rightX = -MathHelper.cos(yawRad) * 0.022f;
        float rightZ = -MathHelper.sin(yawRad) * 0.022f;
        Matrix4f m = ctx.matrixStack().peek().getPositionMatrix();

        double baseY = cam.y - HEIGHT * 0.35;
        double span = HALF * 2.0;

        RenderSystem.disableCull();
        RenderSystem.depthMask(false);
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.setShader(GameRenderer::getPositionColorProgram);

        BufferBuilder b = Tessellator.getInstance().getBuffer();
        b.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        for (int i = 0; i < count; i++) {
            // a fixed pattern of points that repeats around the camera, so rain stays still in the world
            double fx = VisualMath.hash(i * 3 + 1) * span;
            double fz = VisualMath.hash(i * 3 + 2) * span;
            double wx = cam.x + wrap(fx - cam.x, span) - HALF;
            double wz = cam.z + wrap(fz - cam.z, span) - HALF;

            float speed = 15.0f + 9.0f * VisualMath.hash(i * 3 + 3);
            double fy = VisualMath.hash(i * 7 + 5) * HEIGHT;
            double wy = baseY + wrap(fy - time * speed - baseY, HEIGHT);

            // no rain under a roof
            int top = world.getTopY(Heightmap.Type.MOTION_BLOCKING, MathHelper.floor(wx), MathHelper.floor(wz));
            if (wy < top) {
                continue;
            }

            float x = (float) (wx - cam.x);
            float z = (float) (wz - cam.z);
            float y0 = (float) (wy - cam.y);
            float y1 = y0 + STREAK_LEN;
            int aBottom = 96;
            int aTop = 18;
            b.vertex(m, x - rightX, y0, z - rightZ).color(190, 215, 255, aBottom).next();
            b.vertex(m, x + rightX, y0, z + rightZ).color(190, 215, 255, aBottom).next();
            b.vertex(m, x + rightX, y1, z + rightZ).color(190, 215, 255, aTop).next();
            b.vertex(m, x - rightX, y1, z - rightZ).color(190, 215, 255, aTop).next();
        }
        BufferRenderer.drawWithGlobalProgram(b.end());

        RenderSystem.depthMask(true);
        RenderSystem.disableBlend();
        RenderSystem.enableCull();
    }

    private HollowAtmosphere() {
    }
}
