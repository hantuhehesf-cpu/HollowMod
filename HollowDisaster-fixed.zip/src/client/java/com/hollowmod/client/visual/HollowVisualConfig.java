package com.hollowmod.client.visual;

import com.hollowmod.HollowMod;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Locale;
import java.util.Properties;

/**
 * All the tunable numbers for the Hollow visuals. They are saved in
 *   <game folder>/config/hollowmod-visuals.properties
 * and can be changed in game with the /hollowvisual command.
 */
public final class HollowVisualConfig {

    /** Which sky the Hollow interior has. */
    public enum Mood {
        /** Blue cloudy sky (reference images 2 and 5). */
        CLEAR,
        /** Dark overcast sky with aurora curtains and rain (reference image 4). */
        AURORA_RAIN
    }

    /** How detailed the Hollow dome (the sphere seen from outside) is: latitude x longitude bands. */
    public enum Quality {
        LOW(14, 28),
        MEDIUM(24, 48),
        HIGH(36, 72),
        ULTRA(48, 96);

        public final int lat;
        public final int lon;

        Quality(int lat, int lon) {
            this.lat = lat;
            this.lon = lon;
        }
    }

    public static Mood mood = Mood.CLEAR;
    public static Quality quality = Quality.HIGH;
    /** Strength of the VHS / glitch screen effect (0 = off). */
    public static int screenFxPercent = 60;
    /** Amount of rain streaks in the AURORA_RAIN mood (0 = none). */
    public static int rainPercent = 70;
    /** Amount of floating ash / ether motes inside the Hollow (0 = none). */
    public static int particlePercent = 60;
    /** Strength of the aurora curtains (0 = none). */
    public static int auroraPercent = 100;
    /** Brightness of the glowing dome rim and swirl (100 = normal). */
    public static int domeBrightnessPercent = 100;
    /** false = the sky is only a plain gradient (no clouds, no aurora, no glow). */
    public static boolean skyDetail = true;

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("hollowmod-visuals.properties");
    }

    public static void load() {
        Path f = file();
        if (!Files.exists(f)) {
            save();
            return;
        }
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(f)) {
            p.load(in);
        } catch (IOException e) {
            HollowMod.LOGGER.warn("[HollowMod] Could not read visual config: {}", e.toString());
            return;
        }
        try {
            mood = Mood.valueOf(p.getProperty("mood", mood.name()).toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException ignored) {
            // keep default
        }
        try {
            quality = Quality.valueOf(p.getProperty("quality", quality.name()).toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException ignored) {
            // keep default
        }
        screenFxPercent = readInt(p, "screenFxPercent", screenFxPercent, 0, 100);
        rainPercent = readInt(p, "rainPercent", rainPercent, 0, 100);
        particlePercent = readInt(p, "particlePercent", particlePercent, 0, 100);
        auroraPercent = readInt(p, "auroraPercent", auroraPercent, 0, 100);
        domeBrightnessPercent = readInt(p, "domeBrightnessPercent", domeBrightnessPercent, 20, 200);
        skyDetail = Boolean.parseBoolean(p.getProperty("skyDetail", Boolean.toString(skyDetail)));
    }

    public static void save() {
        Properties p = new Properties();
        p.setProperty("mood", mood.name());
        p.setProperty("quality", quality.name());
        p.setProperty("screenFxPercent", Integer.toString(screenFxPercent));
        p.setProperty("rainPercent", Integer.toString(rainPercent));
        p.setProperty("particlePercent", Integer.toString(particlePercent));
        p.setProperty("auroraPercent", Integer.toString(auroraPercent));
        p.setProperty("domeBrightnessPercent", Integer.toString(domeBrightnessPercent));
        p.setProperty("skyDetail", Boolean.toString(skyDetail));
        try (OutputStream out = Files.newOutputStream(file())) {
            p.store(out, "Hollow Disaster visual settings. Change in game with /hollowvisual");
        } catch (IOException e) {
            HollowMod.LOGGER.warn("[HollowMod] Could not save visual config: {}", e.toString());
        }
    }

    private static int readInt(Properties p, String key, int fallback, int min, int max) {
        try {
            int v = Integer.parseInt(p.getProperty(key, Integer.toString(fallback)).trim());
            return Math.max(min, Math.min(max, v));
        } catch (NumberFormatException e) {
            return fallback;
        }
    }

    private HollowVisualConfig() {
    }
}
