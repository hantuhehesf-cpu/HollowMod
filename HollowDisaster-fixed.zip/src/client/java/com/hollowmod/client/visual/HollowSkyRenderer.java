package com.hollowmod.client.visual;

import com.mojang.blaze3d.platform.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.DimensionRenderingRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.MathHelper;
import org.joml.Matrix4f;

/**
 * The sky inside the Hollow dimension. It replaces the vanilla sky (no sun, moon or stars) with:
 *  1. a smooth gradient from the horizon haze up to the zenith
 *  2. drifting cloud bands near the horizon
 *  3. a soft glow of light high in the sky (CLEAR mood)
 *  4. aurora curtains hanging down from the zenith (AURORA_RAIN mood)
 * The horizon color is the same as the biome fog color, so far terrain melts into the sky without a seam.
 * Everything is simple colored quads on a big dome, drawn before the world, same way vanilla draws its sky.
 */
public final class HollowSkyRenderer implements DimensionRenderingRegistry.SkyRenderer {

    private static final float R = 120.0f;
    private static final float TAU = (float) (Math.PI * 2.0);
    private static final int SEGS = 40;

    // Rings of the gradient dome, in radians above the horizon (more rings near the horizon).
    private static final float[] RING = {
            -0.45f, -0.12f, 0.0f, 0.03f, 0.07f, 0.12f, 0.19f, 0.28f,
            0.40f, 0.55f, 0.72f, 0.90f, 1.10f, 1.30f, 1.5707f
    };

    // Colors are 0..255. HORIZON must equal the biome fog color (196, 216, 236).
    private static final float[] HORIZON = {196.0f, 216.0f, 236.0f};
    private static final float[] CLEAR_MID = {118.0f, 170.0f, 232.0f};
    private static final float[] CLEAR_TOP = {52.0f, 104.0f, 208.0f};
    private static final float[] RAIN_MID = {98.0f, 126.0f, 162.0f};
    private static final float[] RAIN_TOP = {28.0f, 36.0f, 84.0f};

    private final float[] c0 = new float[3];
    private final float[] c1 = new float[3];

    @Override
    public void render(WorldRenderContext ctx) {
        ClientWorld world = ctx.world();
        if (world == null) {
            return;
        }
        float t = (world.getTime() + ctx.tickDelta()) / 20.0f;
        Matrix4f m = ctx.matrixStack().peek().getPositionMatrix();
        HollowVisualConfig.Mood mood = HollowVisualConfig.mood;
        boolean detail = HollowVisualConfig.skyDetail;

        RenderSystem.disableCull();
        RenderSystem.depthMask(false);
        RenderSystem.setShader(GameRenderer::getPositionColorProgram);

        RenderSystem.disableBlend();
        drawGradient(m, mood);

        if (detail) {
            RenderSystem.enableBlend();
            RenderSystem.defaultBlendFunc();
            drawCloudBands(m, mood, t);

            // additive light effects
            RenderSystem.blendFunc(GlStateManager.SrcFactor.SRC_ALPHA, GlStateManager.DstFactor.ONE);
            if (mood == HollowVisualConfig.Mood.CLEAR) {
                drawSunGlow(m);
            } else {
                drawAurora(m, t);
            }
        }

        RenderSystem.defaultBlendFunc();
        RenderSystem.disableBlend();
        RenderSystem.depthMask(true);
        RenderSystem.enableCull();
    }

    // ------------------------------------------------------------------ 1. gradient

    private void skyColor(HollowVisualConfig.Mood mood, float elev, float[] out) {
        float[] mid = mood == HollowVisualConfig.Mood.CLEAR ? CLEAR_MID : RAIN_MID;
        float[] top = mood == HollowVisualConfig.Mood.CLEAR ? CLEAR_TOP : RAIN_TOP;
        float t = VisualMath.clamp01(elev / 1.5707f);
        for (int i = 0; i < 3; i++) {
            if (t < 0.35f) {
                out[i] = VisualMath.lerp(HORIZON[i], mid[i], VisualMath.smooth(t / 0.35f));
            } else {
                out[i] = VisualMath.lerp(mid[i], top[i], VisualMath.smooth((t - 0.35f) / 0.65f));
            }
        }
    }

    private void drawGradient(Matrix4f m, HollowVisualConfig.Mood mood) {
        BufferBuilder b = Tessellator.getInstance().getBuffer();
        b.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        for (int i = 0; i < RING.length - 1; i++) {
            float e0 = RING[i];
            float e1 = RING[i + 1];
            skyColor(mood, e0, c0);
            skyColor(mood, e1, c1);
            for (int s = 0; s < SEGS; s++) {
                float a0 = TAU * s / SEGS;
                float a1 = TAU * (s + 1) / SEGS;
                vert(b, m, e0, a0, c0, 255);
                vert(b, m, e0, a1, c0, 255);
                vert(b, m, e1, a1, c1, 255);
                vert(b, m, e1, a0, c1, 255);
            }
        }
        BufferRenderer.drawWithGlobalProgram(b.end());
    }

    // ------------------------------------------------------------------ 2. cloud bands

    private static float cloud(float a, int band, float t) {
        float v = MathHelper.sin(a * 2.0f + band * 1.9f + t * 0.03f) * 0.55f
                + MathHelper.sin(a * 5.0f - band * 0.7f - t * 0.045f) * 0.30f
                + MathHelper.sin(a * 11.0f + band + t * 0.02f) * 0.15f;
        v = 0.5f + 0.5f * v;
        return v * v;
    }

    private void drawCloudBands(Matrix4f m, HollowVisualConfig.Mood mood, float t) {
        boolean clear = mood == HollowVisualConfig.Mood.CLEAR;
        float maxA = clear ? 0.62f : 0.50f;
        c0[0] = clear ? 255.0f : 176.0f;
        c0[1] = clear ? 255.0f : 190.0f;
        c0[2] = clear ? 255.0f : 210.0f;
        int segs = 96;
        BufferBuilder b = Tessellator.getInstance().getBuffer();
        b.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        for (int band = 0; band < 3; band++) {
            float e0 = 0.04f + band * 0.15f;
            float e1 = e0 + 0.10f;
            float e2 = e1 + 0.10f;
            for (int s = 0; s < segs; s++) {
                float a0 = TAU * s / segs;
                float a1 = TAU * (s + 1) / segs;
                int al0 = VisualMath.to255(cloud(a0, band, t) * maxA);
                int al1 = VisualMath.to255(cloud(a1, band, t) * maxA);
                vert(b, m, e0, a0, c0, 0);
                vert(b, m, e0, a1, c0, 0);
                vert(b, m, e1, a1, c0, al1);
                vert(b, m, e1, a0, c0, al0);

                vert(b, m, e1, a0, c0, al0);
                vert(b, m, e1, a1, c0, al1);
                vert(b, m, e2, a1, c0, 0);
                vert(b, m, e2, a0, c0, 0);
            }
        }
        BufferRenderer.drawWithGlobalProgram(b.end());
    }

    // ------------------------------------------------------------------ 3. sun glow (CLEAR)

    private void drawSunGlow(Matrix4f m) {
        float centerE = 1.05f;
        float centerA = 0.9f;
        float radius = 0.38f;
        int n = 28;
        c0[0] = 255.0f;
        c0[1] = 244.0f;
        c0[2] = 220.0f;
        BufferBuilder b = Tessellator.getInstance().getBuffer();
        b.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        for (int k = 0; k < n; k++) {
            float ang0 = TAU * k / n;
            float ang1 = TAU * (k + 1) / n;
            float e0 = centerE + radius * MathHelper.sin(ang0);
            float a0 = centerA + radius * MathHelper.cos(ang0) / MathHelper.cos(centerE);
            float e1 = centerE + radius * MathHelper.sin(ang1);
            float a1 = centerA + radius * MathHelper.cos(ang1) / MathHelper.cos(centerE);
            vert(b, m, centerE, centerA, c0, 150);
            vert(b, m, e0, a0, c0, 0);
            vert(b, m, e1, a1, c0, 0);
            vert(b, m, centerE, centerA, c0, 150);
        }
        BufferRenderer.drawWithGlobalProgram(b.end());
    }

    // ------------------------------------------------------------------ 4. aurora (AURORA_RAIN)

    private void drawAurora(Matrix4f m, float t) {
        float strength = HollowVisualConfig.auroraPercent / 100.0f;
        if (strength <= 0.0f) {
            return;
        }
        int n = 144;
        BufferBuilder b = Tessellator.getInstance().getBuffer();
        b.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        for (int curtain = 0; curtain < 2; curtain++) {
            float baseElev = curtain == 0 ? 0.95f : 1.12f;
            for (int i = 0; i < n; i++) {
                float a0 = TAU * i / n;
                float a1 = TAU * (i + 1) / n;
                float low0 = curtainLow(curtain, baseElev, a0, t);
                float low1 = curtainLow(curtain, baseElev, a1, t);
                float top = 1.5f;

                // each strip has its own brightness, so the curtain looks streaky and alive
                float streak = 0.35f + 0.65f * Math.abs(MathHelper.sin(i * 0.77f + t * 0.5f + curtain))
                        * (0.6f + 0.4f * MathHelper.sin(i * 0.21f - t * 0.3f));
                int alpha = VisualMath.to255(0.62f * streak * strength);

                // blue -> purple -> pink along the sky
                float mix = 0.5f + 0.5f * MathHelper.sin(a0 * 2.0f + t * 0.15f + curtain * 1.7f);
                if (mix < 0.5f) {
                    float k = mix * 2.0f;
                    c0[0] = VisualMath.lerp(70.0f, 150.0f, k);
                    c0[1] = VisualMath.lerp(170.0f, 90.0f, k);
                    c0[2] = VisualMath.lerp(255.0f, 255.0f, k);
                } else {
                    float k = (mix - 0.5f) * 2.0f;
                    c0[0] = VisualMath.lerp(150.0f, 255.0f, k);
                    c0[1] = VisualMath.lerp(90.0f, 110.0f, k);
                    c0[2] = VisualMath.lerp(255.0f, 190.0f, k);
                }
                vert(b, m, low0, a0, c0, alpha);
                vert(b, m, low1, a1, c0, alpha);
                vert(b, m, top, a1, c0, 0);
                vert(b, m, top, a0, c0, 0);
            }
        }
        BufferRenderer.drawWithGlobalProgram(b.end());
    }

    private static float curtainLow(int curtain, float base, float a, float t) {
        float e = base + 0.28f * MathHelper.sin(a * 3.0f + t * 0.25f + curtain * 2.0f)
                + 0.14f * MathHelper.sin(a * 7.0f - t * 0.4f);
        return MathHelper.clamp(e, 0.5f, 1.35f);
    }

    // ------------------------------------------------------------------ one vertex on the dome

    private static void vert(BufferBuilder b, Matrix4f m, float elev, float azim, float[] c, int alpha) {
        float ce = MathHelper.cos(elev);
        float x = R * ce * MathHelper.sin(azim);
        float y = R * MathHelper.sin(elev);
        float z = R * ce * MathHelper.cos(azim);
        b.vertex(m, x, y, z)
                .color(VisualMath.clamp255(c[0]), VisualMath.clamp255(c[1]), VisualMath.clamp255(c[2]), alpha)
                .next();
    }
}
