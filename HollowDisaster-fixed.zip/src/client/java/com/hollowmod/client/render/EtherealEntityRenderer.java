package com.hollowmod.client.render;

import com.hollowmod.HollowMod;
import com.hollowmod.entity.EtherealEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.render.entity.model.BipedEntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayers;
import net.minecraft.util.Identifier;

/**
 * TEMPORARY placeholder: reuses the vanilla player body shape (EntityModelLayers.PLAYER) and a
 * flat white texture (see the 2x2 PNG already included in this project) so EtherealEntity renders
 * as *something* instead of a missing-texture error while you're still iterating on the mod.
 * Swap in a real EntityModelLayer + texture before shipping.
 */
public class EtherealEntityRenderer extends MobEntityRenderer<EtherealEntity, BipedEntityModel<EtherealEntity>> {

    private static final Identifier PLACEHOLDER_TEXTURE =
            new Identifier(HollowMod.MOD_ID, "textures/entity/tint_white.png");

    public EtherealEntityRenderer(EntityRendererFactory.Context context) {
        super(context, new BipedEntityModel<>(context.getPart(EntityModelLayers.PLAYER)), 0.5F);
    }

    @Override
    public Identifier getTexture(EtherealEntity entity) {
        return PLACEHOLDER_TEXTURE;
    }
}
