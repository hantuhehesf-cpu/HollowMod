package com.hollowmod.client.render;

import com.hollowmod.client.dev.ClientHollows;
import com.hollowmod.client.visual.HollowVisualConfig;
import com.hollowmod.client.visual.VisualMath;
import com.hollowmod.dev.HollowInfo;
import com.mojang.blaze3d.systems.RenderSystem;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderContext;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.BufferRenderer;
import net.minecraft.client.render.Camera;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix4f;

/**
 * Draws Hollows that the normal entity renderer cannot: ones beyond the render distance (the server tells us about
 * every Hollow, see ClientHollows) and ones too far to survive the camera's far clipping plane.
 * Trick: a dome that is too far away is drawn CLOSER and proportionally SMALLER along the same line of sight, so it
 * looks exactly as big on screen as the real one would. Far domes also fade into a pale mist, like in the reference art.
 */
public final class DistantHollowRenderer {

    private static final float[] HAZE = {196.0f / 255.0f, 216.0f / 255.0f, 236.0f / 255.0f};

    public static void render(WorldRenderContext ctx) {
        if (!HollowVisualConfig.distantHollows) {
            return;
        }
        ClientWorld world = ctx.world();
        if (world == null || ClientHollows.all().isEmpty()) {
            return;
        }
        String dim = world.getRegistryKey().getValue().toString();
        Camera camera = ctx.camera();
        Vec3d cam = camera.getPos();
        float limit = ClientHollows.entityDrawLimit();
        float time = (world.getTime() + ctx.tickDelta()) / 20.0f;
        float mistMax = HollowVisualConfig.distantMistPercent / 100.0f;

        // where the camera looks (to skip domes that are clearly out of view)
        float yawRad = camera.getYaw() * MathHelper.RADIANS_PER_DEGREE;
        float pitchRad = camera.getPitch() * MathHelper.RADIANS_PER_DEGREE;
        float lookX = -MathHelper.sin(yawRad) * MathHelper.cos(pitchRad);
        float lookY = -MathHelper.sin(pitchRad);
        float lookZ = MathHelper.cos(yawRad) * MathHelper.cos(pitchRad);

        Matrix4f m = ctx.matrixStack().peek().getPositionMatrix();
        boolean prepared = false;
        BufferBuilder body = null;

        // pass 1: opaque bodies (collected into one buffer), pass 2: halos
        java.util.List<float[]> draws = new java.util.ArrayList<>();
        for (HollowInfo h : ClientHollows.all()) {
            if (!dim.equals(h.dim)) {
                continue;
            }
            float radius = ClientHollows.smoothRadius(h);
            if (radius < 0.5f) {
                continue;
            }
            double rx = h.x - cam.x;
            double ry = h.y - cam.y;
            double rz = h.z - cam.z;
            double d = Math.sqrt(rx * rx + ry * ry + rz * rz);
            if (ClientHollows.isEntityPresent(h.uuid) && d <= limit) {
                continue; // the normal entity renderer already draws this one
            }
            // view cone test (generous: the dome is big)
            double dot = (rx * lookX + ry * lookY + rz * lookZ) / Math.max(d, 1.0e-3);
            double angRadius = Math.asin(Math.min(1.0, radius / Math.max(d, radius + 0.001)));
            double angle = Math.acos(MathHelper.clamp(dot, -1.0, 1.0));
            if (angle - angRadius > 1.25) {
                continue; // outside even a very wide field of view
            }
            double f = d > limit ? limit / d : 1.0;
            draws.add(new float[]{(float) (rx * f), (float) (ry * f), (float) (rz * f), (float) (radius * f), (float) d});
        }
        if (draws.isEmpty()) {
            return;
        }

        RenderSystem.setShader(GameRenderer::getPositionColorProgram);
        RenderSystem.enableDepthTest();
        RenderSystem.disableCull();

        // ---- bodies
        RenderSystem.disableBlend();
        RenderSystem.depthMask(true);
        body = Tessellator.getInstance().getBuffer();
        body.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        for (float[] dr : draws) {
            float mist = VisualMath.clamp01((dr[4] - limit * 0.6f) / (limit * 3.0f)) * mistMax;
            DomeMesh.Mesh mesh = DomeMesh.prepare(dr[3], -dr[0], -dr[1], -dr[2], time);
            int[] quads = mesh.quads;
            for (int q = 0; q < quads.length; q += 4) {
                for (int k = 0; k < 4; k++) {
                    int v = quads[q + k];
                    float r = VisualMath.lerp(mesh.cr[v], HAZE[0], mist);
                    float g = VisualMath.lerp(mesh.cg[v], HAZE[1], mist);
                    float b = VisualMath.lerp(mesh.cb[v], HAZE[2], mist);
                    body.vertex(m, dr[0] + mesh.ux[v] * dr[3], dr[1] + mesh.uy[v] * dr[3], dr[2] + mesh.uz[v] * dr[3])
                            .color(VisualMath.to255(r), VisualMath.to255(g), VisualMath.to255(b), 255).next();
                }
            }
        }
        BufferRenderer.drawWithGlobalProgram(body.end());

        // ---- halos
        RenderSystem.enableBlend();
        RenderSystem.defaultBlendFunc();
        RenderSystem.depthMask(false);
        BufferBuilder halo = Tessellator.getInstance().getBuffer();
        halo.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        for (float[] dr : draws) {
            float mist = VisualMath.clamp01((dr[4] - limit * 0.6f) / (limit * 3.0f)) * mistMax;
            DomeMesh.Mesh mesh = DomeMesh.prepare(dr[3], -dr[0], -dr[1], -dr[2], time);
            float hr = dr[3] * 1.02f + 0.25f;
            int[] quads = mesh.quads;
            for (int q = 0; q < quads.length; q += 4) {
                int a0 = quads[q];
                int a1 = quads[q + 1];
                int a2 = quads[q + 2];
                int a3 = quads[q + 3];
                if (Math.max(Math.max(mesh.ha[a0], mesh.ha[a1]), Math.max(mesh.ha[a2], mesh.ha[a3])) < 0.03f) {
                    continue;
                }
                for (int k = 0; k < 4; k++) {
                    int v = quads[q + k];
                    float r = VisualMath.lerp(mesh.hr[v], HAZE[0], mist);
                    float g = VisualMath.lerp(mesh.hg[v], HAZE[1], mist);
                    float b = VisualMath.lerp(mesh.hb[v], HAZE[2], mist);
                    halo.vertex(m, dr[0] + mesh.ux[v] * hr, dr[1] + mesh.uy[v] * hr, dr[2] + mesh.uz[v] * hr)
                            .color(VisualMath.to255(r), VisualMath.to255(g), VisualMath.to255(b),
                                    VisualMath.to255(mesh.ha[v] * (1.0f - mist * 0.5f))).next();
                }
            }
        }
        BufferRenderer.drawWithGlobalProgram(halo.end());

        RenderSystem.depthMask(true);
        RenderSystem.disableBlend();
        RenderSystem.enableCull();
    }

    private DistantHollowRenderer() {
    }
}
