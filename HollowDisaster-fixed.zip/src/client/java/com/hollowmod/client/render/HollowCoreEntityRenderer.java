package com.hollowmod.client.render;

import com.hollowmod.HollowMod;
import com.hollowmod.entity.HollowCoreEntity;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Vector3f;

/**
 * v1.1.1 perf pass. Renders the anomaly as a faceted, rim-lit sphere (same visual design as
 * before: rim-light traces the camera-relative silhouette, flat-shaded per quad for the low-poly
 * facet look). What changed is HOW it's computed:
 *
 * Previously, every quad's corner positions (sin/cos), normal, facet jitter hash, and hue angle
 * were recomputed from scratch every single frame, for every Hollow on screen. None of that
 * actually depends on the current radius or the camera -- it's the same ~390 quads' worth of
 * geometry every time, just scaled. So it's now built ONCE (lazily, on first use) as a shared
 * "unit sphere" (radius 1) and cached in static arrays: UNIT_CORNERS / QUAD_NORMALS (normals are
 * scale-invariant, so the unit-sphere normal is still correct at any radius) / QUAD_BASE_COLOR /
 * QUAD_HUE. It's the same geometry for every Hollow (same LAT_BANDS/LON_BANDS, same jitter
 * function), so ONE shared cache serves every instance -- no per-entity map needed.
 *
 * Per frame, per Hollow, the only real work left is: scale the cached unit corners by the current
 * (smoothly interpolated) radius, and recompute the rim factor -- which genuinely must be
 * per-frame since it depends on camera position. Everything expensive (trig, hashing, atan2) now
 * happens once for the whole game session instead of every frame for every Hollow.
 */
public class HollowCoreEntityRenderer extends EntityRenderer<HollowCoreEntity> {

    private static final Identifier NEUTRAL_TEXTURE = new Identifier(HollowMod.MOD_ID, "textures/entity/tint_white.png");

    // LightmapTextureManager.MAX_LIGHT_COORDINATE (0xF000F0): forces full-bright, unlit rendering.
    private static final int FULLBRIGHT = 0xF000F0;

    private static final int LAT_BANDS = 14;
    private static final int LON_BANDS = 28;
    private static final int QUAD_COUNT = LAT_BANDS * LON_BANDS;

    private static final double RIM_EXPONENT = 3.2;

    // ------------------------------------------------------------------
    // Shared static cache -- built once, lazily, on first render call. Same geometry for every
    // Hollow instance, so this is NOT per-entity state.
    // ------------------------------------------------------------------
    private static Vector3f[] unitCorners;   // length QUAD_COUNT * 4, unit-sphere (radius 1) positions
    private static Vector3f[] quadNormals;   // length QUAD_COUNT, scale-invariant
    private static int[][] quadBaseColor;    // length QUAD_COUNT, [r,g,b] dark faceted base
    private static float[] quadHue;          // length QUAD_COUNT, base hue angle (before time drift)

    private static void ensureStaticGeometryBuilt() {
        if (unitCorners != null) {
            return;
        }
        unitCorners = new Vector3f[QUAD_COUNT * 4];
        quadNormals = new Vector3f[QUAD_COUNT];
        quadBaseColor = new int[QUAD_COUNT][3];
        quadHue = new float[QUAD_COUNT];

        int i = 0;
        for (int lat = 0; lat < LAT_BANDS; lat++) {
            float theta1 = (float) (Math.PI * lat / LAT_BANDS);
            float theta2 = (float) (Math.PI * (lat + 1) / LAT_BANDS);

            for (int lon = 0; lon < LON_BANDS; lon++) {
                float phi1 = (float) (2.0 * Math.PI * lon / LON_BANDS);
                float phi2 = (float) (2.0 * Math.PI * (lon + 1) / LON_BANDS);

                Vector3f p1 = spherePoint(theta1, phi1, 1.0F);
                Vector3f p2 = spherePoint(theta2, phi1, 1.0F);
                Vector3f p3 = spherePoint(theta2, phi2, 1.0F);
                Vector3f p4 = spherePoint(theta1, phi2, 1.0F);

                unitCorners[i * 4] = p1;
                unitCorners[i * 4 + 1] = p2;
                unitCorners[i * 4 + 2] = p3;
                unitCorners[i * 4 + 3] = p4;

                Vector3f center = new Vector3f(p1).add(p2).add(p3).add(p4).mul(0.25F);
                Vector3f normal = new Vector3f(center).normalize();
                quadNormals[i] = normal;

                float jitter = facetJitter(lat, lon);
                quadBaseColor[i][0] = 6 + (int) (jitter * 10);
                quadBaseColor[i][1] = 4 + (int) (jitter * 8);
                quadBaseColor[i][2] = 12 + (int) (jitter * 14);

                float hue = (float) Math.toDegrees(Math.atan2(center.z(), center.x()));
                if (hue < 0) hue += 360.0F;
                quadHue[i] = hue;

                i++;
            }
        }
    }

    public HollowCoreEntityRenderer(EntityRendererFactory.Context context) {
        super(context);
        this.shadowRadius = 0.0F; // skip the vanilla blob shadow; meaningless under a giant sphere
    }

    @Override
    public Identifier getTexture(HollowCoreEntity entity) {
        return NEUTRAL_TEXTURE;
    }

    @Override
    public boolean shouldRender(HollowCoreEntity entity, net.minecraft.client.render.Frustum frustum, double x, double y, double z) {
        // The sphere can be far larger than the entity's own (1x1) hitbox, so the default
        // frustum/distance culling (based on hitbox size) would cull it too early.
        return true;
    }

    @Override
    public void render(HollowCoreEntity entity, float yaw, float tickDelta, MatrixStack matrices,
                        VertexConsumerProvider vertexConsumers, int light) {
        float radius = MathHelper.lerp(tickDelta, entity.getPrevRadius(), entity.getCurrentRadius());

        if (radius >= 0.5F) {
            renderSphere(entity, radius, matrices, vertexConsumers);
        }
        super.render(entity, yaw, tickDelta, matrices, vertexConsumers, light);
    }

    private void renderSphere(HollowCoreEntity entity, float radius, MatrixStack matrices,
                               VertexConsumerProvider vertexConsumers) {
        ensureStaticGeometryBuilt();

        matrices.push();
        VertexConsumer buffer = vertexConsumers.getBuffer(RenderLayer.getEntityCutoutNoCull(NEUTRAL_TEXTURE));
        MatrixStack.Entry entry = matrices.peek();

        Vec3d cameraWorldPos = this.dispatcher.camera.getPos();
        Vec3d entityWorldPos = entity.getPos();
        Vector3f camRelPos = new Vector3f(
                (float) (cameraWorldPos.x - entityWorldPos.x),
                (float) (cameraWorldPos.y - entityWorldPos.y),
                (float) (cameraWorldPos.z - entityWorldPos.z));

        float animOffset = (entity.age % 3600) * 0.2F;

        // Scratch vectors reused across the loop instead of allocating 4 new Vector3f per quad
        // per frame -- with up to 10 Hollows on screen at once (v1.2 cap), this avoids a lot of
        // per-frame garbage.
        Vector3f p1 = new Vector3f();
        Vector3f p2 = new Vector3f();
        Vector3f p3 = new Vector3f();
        Vector3f p4 = new Vector3f();
        Vector3f scaledCenter = new Vector3f();
        Vector3f viewDir = new Vector3f();

        for (int i = 0; i < QUAD_COUNT; i++) {
            p1.set(unitCorners[i * 4]).mul(radius);
            p2.set(unitCorners[i * 4 + 1]).mul(radius);
            p3.set(unitCorners[i * 4 + 2]).mul(radius);
            p4.set(unitCorners[i * 4 + 3]).mul(radius);

            Vector3f normal = quadNormals[i]; // scale-invariant, safe to reuse the cached instance directly
            scaledCenter.set(p1).add(p2).add(p3).add(p4).mul(0.25F);

            viewDir.set(scaledCenter).sub(camRelPos);
            if (viewDir.lengthSquared() > 1.0e-6F) {
                viewDir.normalize();
            } else {
                viewDir.set(normal);
            }

            float ndotv = Math.abs(normal.dot(viewDir));
            float rim = MathHelper.clamp(1.0F - ndotv, 0.0F, 1.0F);
            rim = (float) Math.pow(rim, RIM_EXPONENT);

            int[] base = quadBaseColor[i];
            float hue = (quadHue[i] + animOffset) % 360.0F;
            int[] rimRgb = hsvToRgb(hue);
            int softR = (int) MathHelper.lerp(0.18F, rimRgb[0], 255);
            int softG = (int) MathHelper.lerp(0.18F, rimRgb[1], 255);
            int softB = (int) MathHelper.lerp(0.18F, rimRgb[2], 255);

            int r = (int) MathHelper.lerp(rim, base[0], softR);
            int g = (int) MathHelper.lerp(rim, base[1], softG);
            int b = (int) MathHelper.lerp(rim, base[2], softB);

            quad(buffer, entry, p1, p2, p3, p4, normal, r, g, b, 255);
        }

        matrices.pop();
    }

    private static Vector3f spherePoint(float theta, float phi, float radius) {
        float y = MathHelper.cos(theta) * radius;
        float ringRadius = MathHelper.sin(theta) * radius;
        float x = ringRadius * MathHelper.cos(phi);
        float z = ringRadius * MathHelper.sin(phi);
        return new Vector3f(x, y, z);
    }

    private static float facetJitter(int lat, int lon) {
        int h = lat * 92821 + lon * 68917;
        h ^= (h >>> 13);
        h *= 0x2545F491;
        return ((h >>> 8) & 0xFFFF) / 65535.0F;
    }

    private static int[] hsvToRgb(float hueDegrees) {
        float h = hueDegrees / 60.0F;
        int sector = (int) h % 6;
        float f = h - (int) h;
        int v = 255, p = 0;
        int q = (int) (255 * (1 - f));
        int t = (int) (255 * f);
        return switch (sector) {
            case 0 -> new int[]{v, t, p};
            case 1 -> new int[]{q, v, p};
            case 2 -> new int[]{p, v, t};
            case 3 -> new int[]{p, q, v};
            case 4 -> new int[]{t, p, v};
            default -> new int[]{v, p, q};
        };
    }

    private static void quad(VertexConsumer buffer, MatrixStack.Entry entry,
                              Vector3f a, Vector3f b, Vector3f c, Vector3f d, Vector3f normal,
                              int r, int g, int bCol, int alpha) {
        Matrix4f model = entry.getPositionMatrix();
        Matrix3f normalMat = entry.getNormalMatrix();

        vertex(buffer, model, normalMat, a, r, g, bCol, alpha, 0f, 0f, normal);
        vertex(buffer, model, normalMat, b, r, g, bCol, alpha, 0f, 1f, normal);
        vertex(buffer, model, normalMat, c, r, g, bCol, alpha, 1f, 1f, normal);
        vertex(buffer, model, normalMat, d, r, g, bCol, alpha, 1f, 0f, normal);
    }

    private static void vertex(VertexConsumer buffer, Matrix4f model, Matrix3f normalMat, Vector3f pos,
                                int r, int g, int b, int a, float u, float v, Vector3f normal) {
        buffer.vertex(model, pos.x(), pos.y(), pos.z())
                .color(r, g, b, a)
                .texture(u, v)
                .overlay(OverlayTexture.DEFAULT_UV)
                .light(FULLBRIGHT)
                .normal(normalMat, normal.x(), normal.y(), normal.z())
                .next();
    }
}
