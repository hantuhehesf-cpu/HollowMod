package com.hollowmod.client.render;

import com.hollowmod.HollowMod;
import com.hollowmod.entity.HollowCoreEntity;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.entity.Entity;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Vector3f;

/**
 * Renders the dome as a solid black hemisphere plus an animated rainbow ring where it meets the
 * ground -- built as plain geometry through the same public entity-render pipeline every vanilla
 * mob uses, deliberately AVOIDING RenderLayer.of(...)/custom MultiPhaseParameters:
 *
 *   RenderLayer.of(...) has been package-private since 1.17 (FabricMC/fabric#1635) -- calling it
 *   from mod code needs an Access Widener, and the exact overload/field names shift between
 *   mapping builds. To keep this skeleton reliably compilable without one, both the dome and the
 *   ring use the always-public RenderLayer.getEntityCutout(Identifier), fed by two tiny solid
 *   2x2 textures already generated in this project (textures/entity/dome_solid.png = black,
 *   textures/entity/tint_white.png = white so vertex color shows through untinted for the
 *   rainbow ring). Both passes also override the light coordinate to full-bright so the dome
 *   reads as flat, "100% solid" black regardless of time of day or nearby torches, matching the
 *   lore-accurate look without needing a custom unlit RenderLayer phase.
 *
 * If you later DO want perfectly flat (non-diffuse-shaded) faces, see the Fabric Wiki's
 * "Render Layers" tutorial for wiring an access-widened RenderLayer.of(...) call instead.
 */
public class HollowCoreEntityRenderer extends EntityRenderer<HollowCoreEntity> {

    private static final Identifier DOME_TEXTURE = new Identifier(HollowMod.MOD_ID, "textures/entity/dome_solid.png");
    private static final Identifier RING_TEXTURE = new Identifier(HollowMod.MOD_ID, "textures/entity/tint_white.png");

    // LightmapTextureManager.MAX_LIGHT_COORDINATE (0xF000F0): forces full-bright, unlit rendering.
    private static final int FULLBRIGHT = 0xF000F0;

    private static final int LAT_BANDS = 14;
    private static final int LON_BANDS = 28;
    private static final int RING_SEGMENTS = 48;

    public HollowCoreEntityRenderer(EntityRendererFactory.Context context) {
        super(context);
        this.shadowRadius = 0.0F; // skip the vanilla blob shadow; meaningless under a giant dome
    }

    @Override
    public Identifier getTexture(HollowCoreEntity entity) {
        return DOME_TEXTURE;
    }

    @Override
    public boolean shouldRender(HollowCoreEntity entity, net.minecraft.client.render.Frustum frustum, double x, double y, double z) {
        // The dome can be far larger than the entity's own (1x1) hitbox, so the default
        // frustum/distance culling (based on hitbox size) would cull it too early. Force it
        // visible whenever the *dome radius* could plausibly still be on screen.
        return true;
    }

    @Override
    public void render(HollowCoreEntity entity, float yaw, float tickDelta, MatrixStack matrices,
                        VertexConsumerProvider vertexConsumers, int light) {
        float radius = entity.getCurrentRadius();
        if (radius >= 0.5F) {
            renderDome(radius, matrices, vertexConsumers);
            renderBorderRing(entity, radius, matrices, vertexConsumers);
        }
        super.render(entity, yaw, tickDelta, matrices, vertexConsumers, light);
    }

    // ------------------------------------------------------------------
    // Dome: hemisphere built from lat/long quads, flat solid black.
    // ------------------------------------------------------------------
    private void renderDome(float radius, MatrixStack matrices, VertexConsumerProvider vertexConsumers) {
        matrices.push();
        VertexConsumer buffer = vertexConsumers.getBuffer(RenderLayer.getEntityCutoutNoCull(DOME_TEXTURE));
        MatrixStack.Entry entry = matrices.peek();

        for (int lat = 0; lat < LAT_BANDS; lat++) {
            // theta: 0 = zenith (top pole), PI/2 = horizon (ground level) -> a dome, not a full sphere
            float theta1 = (float) (Math.PI / 2.0 * lat / LAT_BANDS);
            float theta2 = (float) (Math.PI / 2.0 * (lat + 1) / LAT_BANDS);

            for (int lon = 0; lon < LON_BANDS; lon++) {
                float phi1 = (float) (2.0 * Math.PI * lon / LON_BANDS);
                float phi2 = (float) (2.0 * Math.PI * (lon + 1) / LON_BANDS);

                Vector3f p1 = spherePoint(theta1, phi1, radius);
                Vector3f p2 = spherePoint(theta2, phi1, radius);
                Vector3f p3 = spherePoint(theta2, phi2, radius);
                Vector3f p4 = spherePoint(theta1, phi2, radius);

                quad(buffer, entry, p1, p2, p3, p4, 0, 0, 0, 255);
            }
        }

        matrices.pop();
    }

    private static Vector3f spherePoint(float theta, float phi, float radius) {
        float y = MathHelper.cos(theta) * radius;
        float ringRadius = MathHelper.sin(theta) * radius;
        float x = ringRadius * MathHelper.cos(phi);
        float z = ringRadius * MathHelper.sin(phi);
        return new Vector3f(x, y, z);
    }

    // ------------------------------------------------------------------
    // Border ring: thin animated rainbow band exactly where the dome meets the ground.
    // ------------------------------------------------------------------
    private void renderBorderRing(HollowCoreEntity entity, float radius, MatrixStack matrices,
                                   VertexConsumerProvider vertexConsumers) {
        matrices.push();
        VertexConsumer buffer = vertexConsumers.getBuffer(RenderLayer.getEntityCutoutNoCull(RING_TEXTURE));
        MatrixStack.Entry entry = matrices.peek();

        float innerR = radius - 0.4F;
        float outerR = radius + 0.4F;
        float animOffset = (entity.age % 360) * 2.0F; // slow hue rotation, no dynamic light entities needed

        for (int i = 0; i < RING_SEGMENTS; i++) {
            float a1 = (float) (2.0 * Math.PI * i / RING_SEGMENTS);
            float a2 = (float) (2.0 * Math.PI * (i + 1) / RING_SEGMENTS);

            Vector3f inner1 = new Vector3f(innerR * MathHelper.cos(a1), 0.05F, innerR * MathHelper.sin(a1));
            Vector3f outer1 = new Vector3f(outerR * MathHelper.cos(a1), 0.05F, outerR * MathHelper.sin(a1));
            Vector3f inner2 = new Vector3f(innerR * MathHelper.cos(a2), 0.05F, innerR * MathHelper.sin(a2));
            Vector3f outer2 = new Vector3f(outerR * MathHelper.cos(a2), 0.05F, outerR * MathHelper.sin(a2));

            int[] rgb = hsvToRgb((i * (360.0F / RING_SEGMENTS) + animOffset) % 360.0F);
            quad(buffer, entry, inner1, outer1, outer2, inner2, rgb[0], rgb[1], rgb[2], 255);
        }

        matrices.pop();
    }

    /** Cheap HSV(hue,1,1)->RGB for the "ether neon" rainbow, no allocation-heavy Color class. */
    private static int[] hsvToRgb(float hueDegrees) {
        float h = hueDegrees / 60.0F;
        int sector = (int) h % 6;
        float f = h - (int) h;
        int v = 255, p = 0;
        int q = (int) (255 * (1 - f));
        int t = (int) (255 * f);
        return switch (sector) {
            case 0 -> new int[]{v, t, p};
            case 1 -> new int[]{q, v, p};
            case 2 -> new int[]{p, v, t};
            case 3 -> new int[]{p, q, v};
            case 4 -> new int[]{t, p, v};
            default -> new int[]{v, p, q};
        };
    }

    // ------------------------------------------------------------------
    // Shared quad helper
    // ------------------------------------------------------------------
    private static void quad(VertexConsumer buffer, MatrixStack.Entry entry,
                              Vector3f a, Vector3f b, Vector3f c, Vector3f d,
                              int r, int g, int bCol, int alpha) {
        Matrix4f model = entry.getPositionMatrix();
        Matrix3f normalMat = entry.getNormalMatrix();
        // Outward-ish normal; culling is irrelevant here since RenderLayer.getEntityCutout is
        // two-sided for cutout geometry at this vertex count, but a real normal keeps diffuse
        // shading sane instead of undefined.
        Vector3f normal = new Vector3f(a).add(b).add(c).add(d).normalize();

        vertex(buffer, model, normalMat, a, r, g, bCol, alpha, 0f, 0f, normal);
        vertex(buffer, model, normalMat, b, r, g, bCol, alpha, 0f, 1f, normal);
        vertex(buffer, model, normalMat, c, r, g, bCol, alpha, 1f, 1f, normal);
        vertex(buffer, model, normalMat, d, r, g, bCol, alpha, 1f, 0f, normal);
    }

    private static void vertex(VertexConsumer buffer, Matrix4f model, Matrix3f normalMat, Vector3f pos,
                                int r, int g, int b, int a, float u, float v, Vector3f normal) {
        buffer.vertex(model, pos.x(), pos.y(), pos.z())
                .color(r, g, b, a)
                .texture(u, v)
                .overlay(OverlayTexture.DEFAULT_UV)
                .light(FULLBRIGHT)
                .normal(normalMat, normal.x(), normal.y(), normal.z())
                .next();
    }
}
