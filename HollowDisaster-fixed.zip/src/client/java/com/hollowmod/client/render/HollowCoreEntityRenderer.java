package com.hollowmod.client.render;

import com.hollowmod.HollowMod;
import com.hollowmod.entity.HollowCoreEntity;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix3f;
import org.joml.Matrix4f;
import org.joml.Vector3f;

/**
 * v1.1 visual rework. Renders the anomaly as a faceted, rim-lit sphere -- matching the reference
 * art (rainbow glow traces the visible SILHOUETTE edge as seen from the camera, not a fixed ring
 * geometry; the black surface itself has a subtle low-poly/faceted look rather than flat solid).
 *
 * Technique: this is a per-QUAD (flat-shaded, not per-vertex-smoothed) Fresnel/rim-light
 * approximation computed on the CPU, not a fragment shader:
 *   rim = 1 - |dot(quadNormal, viewDirection)|
 * A quad facing the camera head-on has rim near 0 (reads as the dark faceted base color); a quad
 * near the silhouette edge (its normal nearly perpendicular to the view direction) has rim near 1
 * (reads as the rainbow hue for that quad's position around the sphere). Flat-shading per quad
 * (instead of smoothly interpolating per vertex) is what produces the faceted/low-poly look for
 * free -- same computation serves both visual goals at once.
 *
 * Still deliberately avoids RenderLayer.of(...)/custom MultiPhaseParameters (package-private
 * since 1.17, needs an Access Widener) -- uses the always-public RenderLayer.getEntityCutoutNoCull
 * with a flat WHITE 2x2 texture (tint_white.png) so the texture is a neutral multiplier and our
 * computed per-quad vertex colors show through untouched.
 */
public class HollowCoreEntityRenderer extends EntityRenderer<HollowCoreEntity> {

    // Neutral (white) texture: RenderLayer.getEntityCutoutNoCull multiplies vertex color by the
    // texture's color, so white here means "vertex color shows through as-is".
    private static final Identifier NEUTRAL_TEXTURE = new Identifier(HollowMod.MOD_ID, "textures/entity/tint_white.png");

    // LightmapTextureManager.MAX_LIGHT_COORDINATE (0xF000F0): forces full-bright, unlit rendering,
    // so the surface reads consistently regardless of time of day / nearby torches.
    private static final int FULLBRIGHT = 0xF000F0;

    private static final int LAT_BANDS = 14;
    private static final int LON_BANDS = 28;

    // Rim falloff sharpness: higher = the glow stays tighter around the true silhouette edge,
    // matching the reference's fairly crisp (not overly broad/glowy) rim band.
    private static final double RIM_EXPONENT = 3.2; // slightly narrower glow band than v1.1's first pass

    public HollowCoreEntityRenderer(EntityRendererFactory.Context context) {
        super(context);
        this.shadowRadius = 0.0F; // skip the vanilla blob shadow; meaningless under a giant sphere
    }

    @Override
    public Identifier getTexture(HollowCoreEntity entity) {
        return NEUTRAL_TEXTURE;
    }

    @Override
    public boolean shouldRender(HollowCoreEntity entity, net.minecraft.client.render.Frustum frustum, double x, double y, double z) {
        // The sphere can be far larger than the entity's own (1x1) hitbox, so the default
        // frustum/distance culling (based on hitbox size) would cull it too early. Force it
        // visible whenever the *sphere radius* could plausibly still be on screen.
        return true;
    }

    @Override
    public void render(HollowCoreEntity entity, float yaw, float tickDelta, MatrixStack matrices,
                        VertexConsumerProvider vertexConsumers, int light) {
        // SMOOTH GROWTH (v1.1): the server only updates the tracked radius periodically (whatever
        // growth-tick-interval is set), which would otherwise look like discrete size "pops".
        // Interpolating between last tick's and this tick's radius using the frame's partial-tick
        // fraction (tickDelta) makes the growth look perfectly continuous every frame, the same
        // way vanilla smooths entity movement -- independent of how coarse the server's own
        // update rate is. This is the same trick black-hole-style mods use for their event horizon.
        float radius = MathHelper.lerp(tickDelta, entity.getPrevRadius(), entity.getCurrentRadius());

        if (radius >= 0.5F) {
            renderSphere(entity, radius, matrices, vertexConsumers);
        }
        super.render(entity, yaw, tickDelta, matrices, vertexConsumers, light);
    }

    private void renderSphere(HollowCoreEntity entity, float radius, MatrixStack matrices,
                               VertexConsumerProvider vertexConsumers) {
        matrices.push();
        VertexConsumer buffer = vertexConsumers.getBuffer(RenderLayer.getEntityCutoutNoCull(NEUTRAL_TEXTURE));
        MatrixStack.Entry entry = matrices.peek();

        // Camera position expressed relative to the entity's own origin, so it lines up with the
        // local-space vertex positions produced by spherePoint() below (matrices is already
        // translated to the entity's render position by the caller).
        Vec3d cameraWorldPos = this.dispatcher.camera.getPos();
        Vec3d entityWorldPos = entity.getPos();
        Vector3f camRelPos = new Vector3f(
                (float) (cameraWorldPos.x - entityWorldPos.x),
                (float) (cameraWorldPos.y - entityWorldPos.y),
                (float) (cameraWorldPos.z - entityWorldPos.z));

        float animOffset = (entity.age % 3600) * 0.2F; // slow hue drift over time, no light entities needed

        for (int lat = 0; lat < LAT_BANDS; lat++) {
            float theta1 = (float) (Math.PI * lat / LAT_BANDS);
            float theta2 = (float) (Math.PI * (lat + 1) / LAT_BANDS);

            for (int lon = 0; lon < LON_BANDS; lon++) {
                float phi1 = (float) (2.0 * Math.PI * lon / LON_BANDS);
                float phi2 = (float) (2.0 * Math.PI * (lon + 1) / LON_BANDS);

                Vector3f p1 = spherePoint(theta1, phi1, radius);
                Vector3f p2 = spherePoint(theta2, phi1, radius);
                Vector3f p3 = spherePoint(theta2, phi2, radius);
                Vector3f p4 = spherePoint(theta1, phi2, radius);

                Vector3f center = new Vector3f(p1).add(p2).add(p3).add(p4).mul(0.25F);
                Vector3f normal = new Vector3f(center).normalize();

                Vector3f viewDir = new Vector3f(center).sub(camRelPos);
                if (viewDir.lengthSquared() > 1.0e-6F) {
                    viewDir.normalize();
                } else {
                    viewDir.set(normal);
                }

                float ndotv = Math.abs(normal.dot(viewDir));
                float rim = MathHelper.clamp(1.0F - ndotv, 0.0F, 1.0F);
                rim = (float) Math.pow(rim, RIM_EXPONENT);

                float jitter = facetJitter(lat, lon);
                int baseR = 6 + (int) (jitter * 10);
                int baseG = 4 + (int) (jitter * 8);
                int baseB = 12 + (int) (jitter * 14);

                float hue = (float) Math.toDegrees(Math.atan2(center.z(), center.x()));
                if (hue < 0) hue += 360.0F;
                hue = (hue + animOffset) % 360.0F;
                int[] rimRgb = hsvToRgb(hue);
                // Reference photo reads as a soft/pastel neon (bright core fading into color)
                // rather than pure fully-saturated HSV -- blend a bit of white into the hue itself
                // to soften it, independent of the base<->rim blend below.
                int softR = (int) MathHelper.lerp(0.18F, rimRgb[0], 255);
                int softG = (int) MathHelper.lerp(0.18F, rimRgb[1], 255);
                int softB = (int) MathHelper.lerp(0.18F, rimRgb[2], 255);

                int r = (int) MathHelper.lerp(rim, baseR, softR);
                int g = (int) MathHelper.lerp(rim, baseG, softG);
                int b = (int) MathHelper.lerp(rim, baseB, softB);

                quad(buffer, entry, p1, p2, p3, p4, normal, r, g, b, 255);
            }
        }

        matrices.pop();
    }

    private static Vector3f spherePoint(float theta, float phi, float radius) {
        float y = MathHelper.cos(theta) * radius;
        float ringRadius = MathHelper.sin(theta) * radius;
        float x = ringRadius * MathHelper.cos(phi);
        float z = ringRadius * MathHelper.sin(phi);
        return new Vector3f(x, y, z);
    }

    /** Cheap deterministic 0..1 pseudo-random per facet, so the same quad always jitters the same way. */
    private static float facetJitter(int lat, int lon) {
        int h = lat * 92821 + lon * 68917;
        h ^= (h >>> 13);
        h *= 0x2545F491;
        return ((h >>> 8) & 0xFFFF) / 65535.0F;
    }

    /** Cheap HSV(hue,1,1)->RGB for the "ether neon" rainbow, no allocation-heavy Color class. */
    private static int[] hsvToRgb(float hueDegrees) {
        float h = hueDegrees / 60.0F;
        int sector = (int) h % 6;
        float f = h - (int) h;
        int v = 255, p = 0;
        int q = (int) (255 * (1 - f));
        int t = (int) (255 * f);
        return switch (sector) {
            case 0 -> new int[]{v, t, p};
            case 1 -> new int[]{q, v, p};
            case 2 -> new int[]{p, v, t};
            case 3 -> new int[]{p, q, v};
            case 4 -> new int[]{t, p, v};
            default -> new int[]{v, p, q};
        };
    }

    // ------------------------------------------------------------------
    // Shared quad helper -- flat shaded (same color on all 4 vertices), which is what gives the
    // low-poly faceted look between adjacent quads.
    // ------------------------------------------------------------------
    private static void quad(VertexConsumer buffer, MatrixStack.Entry entry,
                              Vector3f a, Vector3f b, Vector3f c, Vector3f d, Vector3f normal,
                              int r, int g, int bCol, int alpha) {
        Matrix4f model = entry.getPositionMatrix();
        Matrix3f normalMat = entry.getNormalMatrix();

        vertex(buffer, model, normalMat, a, r, g, bCol, alpha, 0f, 0f, normal);
        vertex(buffer, model, normalMat, b, r, g, bCol, alpha, 0f, 1f, normal);
        vertex(buffer, model, normalMat, c, r, g, bCol, alpha, 1f, 1f, normal);
        vertex(buffer, model, normalMat, d, r, g, bCol, alpha, 1f, 0f, normal);
    }

    private static void vertex(VertexConsumer buffer, Matrix4f model, Matrix3f normalMat, Vector3f pos,
                                int r, int g, int b, int a, float u, float v, Vector3f normal) {
        buffer.vertex(model, pos.x(), pos.y(), pos.z())
                .color(r, g, b, a)
                .texture(u, v)
                .overlay(OverlayTexture.DEFAULT_UV)
                .light(FULLBRIGHT)
                .normal(normalMat, normal.x(), normal.y(), normal.z())
                .next();
    }
}
