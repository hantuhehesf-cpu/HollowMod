package com.hollowmod.client.render;

import com.hollowmod.HollowMod;
import com.hollowmod.client.visual.HollowVisualConfig;
import com.hollowmod.client.visual.VisualMath;
import com.hollowmod.entity.HollowCoreEntity;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

import java.util.HashMap;
import java.util.Map;

/**
 * v2 "Hollow dome" look, made to match the Zenless Zone Zero references:
 *  - a SMOOTH sphere (many bands, smooth colors between vertices) instead of low-poly facets
 *  - a dark indigo body with a slow pastel swirl on it
 *  - a thin, bright, iridescent rim (rainbow oil-slick colors that shift with the viewing angle)
 *  - a soft translucent halo shell around the edge, so the rim glows like it is blooming
 *  - the fog of the world still fades far domes into mist
 *
 * How it stays fast enough: the unit-sphere geometry is built ONCE per detail level and cached. Each frame
 * colors are computed once per VERTEX (not per quad corner), and far-away domes automatically use a coarser mesh
 * (level of detail). Use /hollowvisual quality low|medium|high|ultra to change the detail.
 */
public class HollowCoreEntityRenderer extends EntityRenderer<HollowCoreEntity> {

    private static final Identifier NEUTRAL_TEXTURE = new Identifier(HollowMod.MOD_ID, "textures/entity/tint_white.png");

    // LightmapTextureManager.MAX_LIGHT_COORDINATE: forces full-bright, unlit rendering.
    private static final int FULLBRIGHT = 0xF000F0;

    // ------------------------------------------------------------------ cached sphere meshes

    private static final class Mesh {
        final int vertCount;
        final float[] ux;
        final float[] uy;
        final float[] uz;
        final float[] theta;
        final float[] phi;
        final int[] quads;     // 4 vertex indices per quad
        // per-frame scratch (the renderer draws one Hollow at a time, so sharing is safe)
        final float[] cr;
        final float[] cg;
        final float[] cb;
        final float[] hr;
        final float[] hg;
        final float[] hb;
        final float[] ha;

        Mesh(int lat, int lon) {
            int cols = lon + 1;
            vertCount = (lat + 1) * cols;
            ux = new float[vertCount];
            uy = new float[vertCount];
            uz = new float[vertCount];
            theta = new float[vertCount];
            phi = new float[vertCount];
            cr = new float[vertCount];
            cg = new float[vertCount];
            cb = new float[vertCount];
            hr = new float[vertCount];
            hg = new float[vertCount];
            hb = new float[vertCount];
            ha = new float[vertCount];
            for (int i = 0; i <= lat; i++) {
                float th = (float) (Math.PI * i / lat);
                float sinT = MathHelper.sin(th);
                float cosT = MathHelper.cos(th);
                for (int j = 0; j <= lon; j++) {
                    float ph = (float) (2.0 * Math.PI * j / lon);
                    int v = i * cols + j;
                    ux[v] = sinT * MathHelper.cos(ph);
                    uy[v] = cosT;
                    uz[v] = sinT * MathHelper.sin(ph);
                    theta[v] = th;
                    phi[v] = ph;
                }
            }
            quads = new int[lat * lon * 4];
            int q = 0;
            for (int i = 0; i < lat; i++) {
                for (int j = 0; j < lon; j++) {
                    quads[q++] = i * cols + j;
                    quads[q++] = (i + 1) * cols + j;
                    quads[q++] = (i + 1) * cols + j + 1;
                    quads[q++] = i * cols + j + 1;
                }
            }
        }
    }

    private static final Map<Integer, Mesh> MESHES = new HashMap<>();
    private static final float[] RGB = new float[3];

    private static Mesh mesh(int lat, int lon) {
        return MESHES.computeIfAbsent(lat * 1000 + lon, k -> new Mesh(lat, lon));
    }

    /** Picks the detail level: the smaller the dome looks on screen, the coarser the mesh. */
    private static Mesh chooseMesh(float radius, double distance) {
        HollowVisualConfig.Quality q = HollowVisualConfig.quality;
        float apparent = (float) (radius / Math.max(distance, 1.0));
        int div = apparent < 0.05f ? 3 : (apparent < 0.16f ? 2 : 1);
        int lat = Math.max(10, q.lat / div);
        int lon = Math.max(20, q.lon / div);
        return mesh(lat, lon);
    }

    // ------------------------------------------------------------------ renderer

    public HollowCoreEntityRenderer(EntityRendererFactory.Context context) {
        super(context);
        this.shadowRadius = 0.0F; // no blob shadow under a giant sphere
    }

    @Override
    public Identifier getTexture(HollowCoreEntity entity) {
        return NEUTRAL_TEXTURE;
    }

    @Override
    public boolean shouldRender(HollowCoreEntity entity, Frustum frustum, double x, double y, double z) {
        // The sphere is far bigger than the entity's 1x1 hitbox, so never cull by hitbox.
        return true;
    }

    @Override
    public void render(HollowCoreEntity entity, float yaw, float tickDelta, MatrixStack matrices,
                       VertexConsumerProvider vertexConsumers, int light) {
        float radius = MathHelper.lerp(tickDelta, entity.getPrevRadius(), entity.getCurrentRadius());
        if (radius >= 0.5F) {
            renderDome(entity, radius, tickDelta, matrices, vertexConsumers);
        }
        super.render(entity, yaw, tickDelta, matrices, vertexConsumers, light);
    }

    private void renderDome(HollowCoreEntity entity, float radius, float tickDelta, MatrixStack matrices,
                            VertexConsumerProvider vertexConsumers) {
        Vec3d cameraPos = this.dispatcher.camera.getPos();
        Vec3d entityPos = entity.getPos();
        float camX = (float) (cameraPos.x - entityPos.x);
        float camY = (float) (cameraPos.y - entityPos.y);
        float camZ = (float) (cameraPos.z - entityPos.z);
        double distance = Math.sqrt((double) camX * camX + (double) camY * camY + (double) camZ * camZ);

        Mesh m = chooseMesh(radius, distance);
        float time = (entity.age + tickDelta) / 20.0f;
        float bright = HollowVisualConfig.domeBrightnessPercent / 100.0f;

        // ---- 1. colors, once per vertex
        for (int v = 0; v < m.vertCount; v++) {
            float nx = m.ux[v];
            float ny = m.uy[v];
            float nz = m.uz[v];

            // how sideways we look at this point: 0 = straight at it, 1 = exactly on the silhouette edge
            float vx = nx * radius - camX;
            float vy = ny * radius - camY;
            float vz = nz * radius - camZ;
            float len = (float) Math.sqrt(vx * vx + vy * vy + vz * vz);
            if (len < 1.0e-3f) {
                len = 1.0e-3f;
            }
            float fres = 1.0f - Math.abs((nx * vx + ny * vy + nz * vz) / len);
            float f2 = fres * fres;
            float f3 = f2 * fres;
            float core = f3 * f3;   // fres^6: the thin bright outline
            float soft = f3;        // fres^3: the wide soft glow

            // slow swirling pattern over the surface
            float th = m.theta[v];
            float ph = m.phi[v];
            float w1 = MathHelper.sin(ph * 3.0f + th * 5.0f + time * 0.55f);
            float w2 = MathHelper.sin(ph * 5.0f - th * 3.0f - time * 0.40f + w1 * 1.4f);
            float swirl = 0.5f + 0.5f * w2;

            // iridescence: the hue shifts with the viewing angle (like a soap bubble) and drifts with time
            float hue = 205.0f + fres * 250.0f + swirl * 55.0f + time * 7.0f + ph * 8.0f;
            VisualMath.hsv(hue, 0.60f, 1.0f, RGB);
            float rr = RGB[0];
            float rg = RGB[1];
            float rb = RGB[2];

            // the very edge goes almost white, like the glowing outline in the references
            float white = core * 0.55f;
            float er = VisualMath.lerp(rr, 1.0f, white);
            float eg = VisualMath.lerp(rg, 1.0f, white);
            float eb = VisualMath.lerp(rb, 1.0f, white);

            float pastel = (0.05f + 0.13f * swirl) * (0.30f + 0.70f * fres) * bright;
            float glow = (core * 1.10f + soft * 0.45f) * bright;

            // dark indigo body + faint pastel swirl + glowing rim
            m.cr[v] = Math.min(1.0f, 0.035f + er * pastel * 0.85f + er * glow);
            m.cg[v] = Math.min(1.0f, 0.027f + eg * pastel * 0.85f + eg * glow);
            m.cb[v] = Math.min(1.0f, 0.094f + eb * pastel * 0.95f + eb * glow);

            // halo shell color and strength
            m.hr[v] = er;
            m.hg[v] = eg;
            m.hb[v] = eb;
            m.ha[v] = VisualMath.clamp01(core * 0.9f + soft * 0.55f) * 0.55f * Math.min(bright, 1.5f);
        }

        matrices.push();
        MatrixStack.Entry entry = matrices.peek();
        Matrix4f mat = entry.getPositionMatrix();
        Matrix3f nm = entry.getNormalMatrix();

        // ---- 2. opaque body
        VertexConsumer body = vertexConsumers.getBuffer(RenderLayer.getEntityCutoutNoCull(NEUTRAL_TEXTURE));
        int[] quads = m.quads;
        for (int q = 0; q < quads.length; q += 4) {
            for (int k = 0; k < 4; k++) {
                int v = quads[q + k];
                emit(body, mat, nm, m.ux[v] * radius, m.uy[v] * radius, m.uz[v] * radius,
                        VisualMath.to255(m.cr[v]), VisualMath.to255(m.cg[v]), VisualMath.to255(m.cb[v]), 255);
            }
        }

        // ---- 3. soft translucent halo shell (slightly bigger than the body)
        VertexConsumer halo = vertexConsumers.getBuffer(RenderLayer.getEntityTranslucent(NEUTRAL_TEXTURE));
        float haloRadius = radius * 1.02f + 0.25f;
        for (int q = 0; q < quads.length; q += 4) {
            int a = quads[q];
            int b = quads[q + 1];
            int c = quads[q + 2];
            int d = quads[q + 3];
            if (Math.max(Math.max(m.ha[a], m.ha[b]), Math.max(m.ha[c], m.ha[d])) < 0.03f) {
                continue; // nothing visible here (face-on part of the sphere)
            }
            emitHalo(halo, mat, nm, m, a, haloRadius);
            emitHalo(halo, mat, nm, m, b, haloRadius);
            emitHalo(halo, mat, nm, m, c, haloRadius);
            emitHalo(halo, mat, nm, m, d, haloRadius);
        }
        matrices.pop();
    }

    private static void emitHalo(VertexConsumer buf, Matrix4f mat, Matrix3f nm, Mesh m, int v, float radius) {
        emit(buf, mat, nm, m.ux[v] * radius, m.uy[v] * radius, m.uz[v] * radius,
                VisualMath.to255(m.hr[v]), VisualMath.to255(m.hg[v]), VisualMath.to255(m.hb[v]),
                VisualMath.to255(m.ha[v]));
    }

    /** One vertex. The normal always points up so the entity lighting does not darken parts of the glow. */
    private static void emit(VertexConsumer buf, Matrix4f mat, Matrix3f nm, float x, float y, float z,
                             int r, int g, int b, int a) {
        buf.vertex(mat, x, y, z)
                .color(r, g, b, a)
                .texture(0.5f, 0.5f)
                .overlay(OverlayTexture.DEFAULT_UV)
                .light(FULLBRIGHT)
                .normal(nm, 0.0f, 1.0f, 0.0f)
                .next();
    }
}
