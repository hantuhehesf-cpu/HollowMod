package com.hollowmod.client.render;

import com.hollowmod.HollowMod;
import com.hollowmod.client.dev.ClientHollows;
import com.hollowmod.client.visual.HollowVisualConfig;
import com.hollowmod.client.visual.VisualMath;
import com.hollowmod.entity.HollowCoreEntity;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import org.joml.Matrix3f;
import org.joml.Matrix4f;

/**
 * The Hollow dome seen from close by (an entity that exists on the client). The look itself (smooth sphere, dark body,
 * pastel swirl, iridescent rim, halo) lives in DomeMesh. Far domes, and domes the server never sent as entities,
 * are drawn by DistantHollowRenderer instead, which is why this renderer stays quiet past entityDrawLimit().
 */
public class HollowCoreEntityRenderer extends EntityRenderer<HollowCoreEntity> {

    private static final Identifier NEUTRAL_TEXTURE = new Identifier(HollowMod.MOD_ID, "textures/entity/tint_white.png");

    // LightmapTextureManager.MAX_LIGHT_COORDINATE: forces full-bright, unlit rendering.
    private static final int FULLBRIGHT = 0xF000F0;

    public HollowCoreEntityRenderer(EntityRendererFactory.Context context) {
        super(context);
        this.shadowRadius = 0.0F; // no blob shadow under a giant sphere
    }

    @Override
    public Identifier getTexture(HollowCoreEntity entity) {
        return NEUTRAL_TEXTURE;
    }

    @Override
    public boolean shouldRender(HollowCoreEntity entity, Frustum frustum, double x, double y, double z) {
        // The sphere is far bigger than the entity's 1x1 hitbox, so never cull by hitbox.
        return true;
    }

    @Override
    public void render(HollowCoreEntity entity, float yaw, float tickDelta, MatrixStack matrices,
                       VertexConsumerProvider vertexConsumers, int light) {
        float radius = MathHelper.lerp(tickDelta, entity.getPrevRadius(), entity.getCurrentRadius());
        if (radius >= 0.5F) {
            renderDome(entity, radius, tickDelta, matrices, vertexConsumers);
        }
        super.render(entity, yaw, tickDelta, matrices, vertexConsumers, light);
    }

    private void renderDome(HollowCoreEntity entity, float radius, float tickDelta, MatrixStack matrices,
                            VertexConsumerProvider vertexConsumers) {
        Vec3d cameraPos = this.dispatcher.camera.getPos();
        Vec3d entityPos = entity.getPos();
        float camX = (float) (cameraPos.x - entityPos.x);
        float camY = (float) (cameraPos.y - entityPos.y);
        float camZ = (float) (cameraPos.z - entityPos.z);

        // too far away for the normal path: the distant renderer draws a scaled copy instead
        if (HollowVisualConfig.distantHollows) {
            double distance = Math.sqrt((double) camX * camX + (double) camY * camY + (double) camZ * camZ);
            if (distance > ClientHollows.entityDrawLimit()) {
                return;
            }
        }

        float time = (entity.age + tickDelta) / 20.0f;
        DomeMesh.Mesh m = DomeMesh.prepare(radius, camX, camY, camZ, time);

        matrices.push();
        MatrixStack.Entry entry = matrices.peek();
        Matrix4f mat = entry.getPositionMatrix();
        Matrix3f nm = entry.getNormalMatrix();

        // opaque body
        VertexConsumer body = vertexConsumers.getBuffer(RenderLayer.getEntityCutoutNoCull(NEUTRAL_TEXTURE));
        int[] quads = m.quads;
        for (int q = 0; q < quads.length; q += 4) {
            for (int k = 0; k < 4; k++) {
                int v = quads[q + k];
                emit(body, mat, nm, m.ux[v] * radius, m.uy[v] * radius, m.uz[v] * radius,
                        VisualMath.to255(m.cr[v]), VisualMath.to255(m.cg[v]), VisualMath.to255(m.cb[v]), 255);
            }
        }

        // soft translucent halo shell (slightly bigger than the body)
        VertexConsumer halo = vertexConsumers.getBuffer(RenderLayer.getEntityTranslucent(NEUTRAL_TEXTURE));
        float haloRadius = radius * 1.02f + 0.25f;
        for (int q = 0; q < quads.length; q += 4) {
            int a = quads[q];
            int b = quads[q + 1];
            int c = quads[q + 2];
            int d = quads[q + 3];
            if (Math.max(Math.max(m.ha[a], m.ha[b]), Math.max(m.ha[c], m.ha[d])) < 0.03f) {
                continue; // nothing visible here (face-on part of the sphere)
            }
            emitHalo(halo, mat, nm, m, a, haloRadius);
            emitHalo(halo, mat, nm, m, b, haloRadius);
            emitHalo(halo, mat, nm, m, c, haloRadius);
            emitHalo(halo, mat, nm, m, d, haloRadius);
        }
        matrices.pop();
    }

    private static void emitHalo(VertexConsumer buf, Matrix4f mat, Matrix3f nm, DomeMesh.Mesh m, int v, float radius) {
        emit(buf, mat, nm, m.ux[v] * radius, m.uy[v] * radius, m.uz[v] * radius,
                VisualMath.to255(m.hr[v]), VisualMath.to255(m.hg[v]), VisualMath.to255(m.hb[v]),
                VisualMath.to255(m.ha[v]));
    }

    /** One vertex. The normal always points up so the entity lighting does not darken parts of the glow. */
    private static void emit(VertexConsumer buf, Matrix4f mat, Matrix3f nm, float x, float y, float z,
                             int r, int g, int b, int a) {
        buf.vertex(mat, x, y, z)
                .color(r, g, b, a)
                .texture(0.5f, 0.5f)
                .overlay(OverlayTexture.DEFAULT_UV)
                .light(FULLBRIGHT)
                .normal(nm, 0.0f, 1.0f, 0.0f)
                .next();
    }
}
