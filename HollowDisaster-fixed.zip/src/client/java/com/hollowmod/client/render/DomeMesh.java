package com.hollowmod.client.render;

import com.hollowmod.client.visual.HollowVisualConfig;
import com.hollowmod.client.visual.VisualMath;
import net.minecraft.util.math.MathHelper;

import java.util.HashMap;
import java.util.Map;

/**
 * The shared "Hollow dome" look: cached unit-sphere meshes + the per-vertex color math (dark body, pastel swirl,
 * iridescent rim, halo). Used by the entity renderer (near domes) and by DistantHollowRenderer (domes beyond
 * the render distance). Both only differ in HOW they send the finished vertices to the GPU.
 */
public final class DomeMesh {

    public static final class Mesh {
        public final int vertCount;
        public final float[] ux;
        public final float[] uy;
        public final float[] uz;
        public final float[] theta;
        public final float[] phi;
        public final int[] quads;      // 4 vertex indices per quad
        // per-frame results (filled by prepare)
        public final float[] cr;
        public final float[] cg;
        public final float[] cb;
        public final float[] hr;
        public final float[] hg;
        public final float[] hb;
        public final float[] ha;

        Mesh(int lat, int lon) {
            int cols = lon + 1;
            vertCount = (lat + 1) * cols;
            ux = new float[vertCount];
            uy = new float[vertCount];
            uz = new float[vertCount];
            theta = new float[vertCount];
            phi = new float[vertCount];
            cr = new float[vertCount];
            cg = new float[vertCount];
            cb = new float[vertCount];
            hr = new float[vertCount];
            hg = new float[vertCount];
            hb = new float[vertCount];
            ha = new float[vertCount];
            for (int i = 0; i <= lat; i++) {
                float th = (float) (Math.PI * i / lat);
                float sinT = MathHelper.sin(th);
                float cosT = MathHelper.cos(th);
                for (int j = 0; j <= lon; j++) {
                    float ph = (float) (2.0 * Math.PI * j / lon);
                    int v = i * cols + j;
                    ux[v] = sinT * MathHelper.cos(ph);
                    uy[v] = cosT;
                    uz[v] = sinT * MathHelper.sin(ph);
                    theta[v] = th;
                    phi[v] = ph;
                }
            }
            quads = new int[lat * lon * 4];
            int q = 0;
            for (int i = 0; i < lat; i++) {
                for (int j = 0; j < lon; j++) {
                    quads[q++] = i * cols + j;
                    quads[q++] = (i + 1) * cols + j;
                    quads[q++] = (i + 1) * cols + j + 1;
                    quads[q++] = i * cols + j + 1;
                }
            }
        }
    }

    private static final Map<Integer, Mesh> MESHES = new HashMap<>();
    private static final float[] RGB = new float[3];

    private static Mesh mesh(int lat, int lon) {
        return MESHES.computeIfAbsent(lat * 1000 + lon, k -> new Mesh(lat, lon));
    }

    /** Picks the detail level: the smaller the dome looks on screen, the coarser the mesh. */
    public static Mesh choose(float radius, double distance) {
        HollowVisualConfig.Quality q = HollowVisualConfig.quality;
        float apparent = (float) (radius / Math.max(distance, 1.0));
        int div = apparent < 0.05f ? 3 : (apparent < 0.16f ? 2 : 1);
        return mesh(Math.max(10, q.lat / div), Math.max(20, q.lon / div));
    }

    /**
     * Computes the colors of every vertex for a dome of the given radius, seen from a camera at (camX, camY, camZ)
     * measured from the dome CENTER. Results are in the returned mesh's cr/cg/cb (body) and hr/hg/hb/ha (halo).
     */
    public static Mesh prepare(float radius, float camX, float camY, float camZ, float time) {
        double distance = Math.sqrt((double) camX * camX + (double) camY * camY + (double) camZ * camZ);
        Mesh m = choose(radius, distance);
        float bright = HollowVisualConfig.domeBrightnessPercent / 100.0f;

        for (int v = 0; v < m.vertCount; v++) {
            float nx = m.ux[v];
            float ny = m.uy[v];
            float nz = m.uz[v];

            // 0 = looking straight at this point, 1 = exactly on the silhouette edge
            float vx = nx * radius - camX;
            float vy = ny * radius - camY;
            float vz = nz * radius - camZ;
            float len = (float) Math.sqrt(vx * vx + vy * vy + vz * vz);
            if (len < 1.0e-3f) {
                len = 1.0e-3f;
            }
            float fres = 1.0f - Math.abs((nx * vx + ny * vy + nz * vz) / len);
            float f2 = fres * fres;
            float f3 = f2 * fres;
            float core = f3 * f3;   // fres^6: thin bright outline
            float soft = f3;        // fres^3: wide soft glow

            float th = m.theta[v];
            float ph = m.phi[v];
            float w1 = MathHelper.sin(ph * 3.0f + th * 5.0f + time * 0.55f);
            float w2 = MathHelper.sin(ph * 5.0f - th * 3.0f - time * 0.40f + w1 * 1.4f);
            float swirl = 0.5f + 0.5f * w2;

            float hue = 205.0f + fres * 250.0f + swirl * 55.0f + time * 7.0f + ph * 8.0f;
            VisualMath.hsv(hue, 0.60f, 1.0f, RGB);
            float white = core * 0.55f;
            float er = VisualMath.lerp(RGB[0], 1.0f, white);
            float eg = VisualMath.lerp(RGB[1], 1.0f, white);
            float eb = VisualMath.lerp(RGB[2], 1.0f, white);

            float pastel = (0.05f + 0.13f * swirl) * (0.30f + 0.70f * fres) * bright;
            float glow = (core * 1.10f + soft * 0.45f) * bright;

            m.cr[v] = Math.min(1.0f, 0.035f + er * pastel * 0.85f + er * glow);
            m.cg[v] = Math.min(1.0f, 0.027f + eg * pastel * 0.85f + eg * glow);
            m.cb[v] = Math.min(1.0f, 0.094f + eb * pastel * 0.95f + eb * glow);

            m.hr[v] = er;
            m.hg[v] = eg;
            m.hb[v] = eb;
            m.ha[v] = VisualMath.clamp01(core * 0.9f + soft * 0.55f) * 0.55f * Math.min(bright, 1.5f);
        }
        return m;
    }

    private DomeMesh() {
    }
}
