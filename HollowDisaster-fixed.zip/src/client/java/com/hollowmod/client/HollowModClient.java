package com.hollowmod.client;

import com.hollowmod.client.render.EtherealEntityRenderer;
import com.hollowmod.client.render.HollowCoreEntityRenderer;
import com.hollowmod.client.screen.CarrotScreen;
import com.hollowmod.network.HollowNetworking;
import com.hollowmod.registry.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

public class HollowModClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(ModEntities.HOLLOW_CORE_ENTITY, HollowCoreEntityRenderer::new);
        EntityRendererRegistry.register(ModEntities.ETHEREAL_ENTITY, EtherealEntityRenderer::new);

        // System 6: server sends the scan map when a Carrot is used; parse it here, open the screen on the client thread
        ClientPlayNetworking.registerGlobalReceiver(HollowNetworking.CARROT_MAP, (client, handler, buf, responseSender) -> {
            CarrotScreen.Data data = CarrotScreen.Data.read(buf);
            client.execute(() -> client.setScreen(new CarrotScreen(data)));
        });
    }
}