package com.hollowmod.client;

import com.hollowmod.client.render.EtherealEntityRenderer;
import com.hollowmod.client.render.HollowCoreEntityRenderer;
import com.hollowmod.registry.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

public class HollowModClient implements ClientModInitializer {

    @Override
    public void onInitializeClient() {
        EntityRendererRegistry.register(ModEntities.HOLLOW_CORE_ENTITY, HollowCoreEntityRenderer::new);
        EntityRendererRegistry.register(ModEntities.ETHEREAL_ENTITY, EtherealEntityRenderer::new);
    }
}