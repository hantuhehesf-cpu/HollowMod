package com.hollowmod.client.screen;

import com.hollowmod.maze.MazeConfig;
import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.render.BufferBuilder;
import net.minecraft.client.render.GameRenderer;
import net.minecraft.client.render.Tessellator;
import net.minecraft.client.render.VertexFormat;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.text.Text;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.RotationAxis;
import org.joml.Matrix4f;

import java.util.HashSet;
import java.util.Set;

/**
 * Carrot map screen: the Hollow scan map as a free 3D view (drag to rotate, +/- to zoom).
 * Walls are gray blocks, known corridor is green floor, the exit portal is gold, pillars are
 * aqua, you are red. Older scan data is drawn darker, so you can see what may have shifted.
 * Plain colored quads only, one buffer, drawn only while this screen is open.
 */
public class CarrotScreen extends Screen {

    /** Plain data parsed off the network thread (a PacketByteBuf must not outlive its handler). */
    public static final class Data {
        final int nx;
        final int nz;
        final int playerCol;
        final byte[] state;
        final int[] age;
        final Set<Integer> marks = new HashSet<>();

        private Data(int nx, int nz, int playerCol) {
            this.nx = nx;
            this.nz = nz;
            this.playerCol = playerCol;
            this.state = new byte[nx * nz];
            this.age = new int[nx * nz];
        }

        public static Data read(PacketByteBuf buf) {
            int nx = buf.readInt();
            int nz = buf.readInt();
            Data d = new Data(nx, nz, buf.readInt());
            for (int i = 0; i < nx * nz; i++) {
                d.state[i] = buf.readByte();
                d.age[i] = buf.readUnsignedByte();
            }
            int n = buf.readInt();
            for (int i = 0; i < n; i++) {
                d.marks.add(buf.readInt());
            }
            return d;
        }
    }

    private static final float WALL_HEIGHT = 0.8f;

    private final Data data;
    private float yaw = 35f;
    private float pitch = 55f;
    private float zoom = 1f;

    public CarrotScreen(Data data) {
        super(Text.literal("Carrot"));
        this.data = data;
    }

    @Override
    protected void init() {
        int s = 28; // big enough for a virtual mouse on a phone
        addDrawableChild(ButtonWidget.builder(Text.literal("+"), b -> zoom = Math.min(3f, zoom * 1.25f))
                .dimensions(width - s - 8, height / 2 - s - 4, s, s).build());
        addDrawableChild(ButtonWidget.builder(Text.literal("-"), b -> zoom = Math.max(0.4f, zoom / 1.25f))
                .dimensions(width - s - 8, height / 2 + 4, s, s).build());
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int button, double deltaX, double deltaY) {
        yaw += (float) deltaX * 0.6f;
        pitch = MathHelper.clamp(pitch + (float) deltaY * 0.6f, 15f, 89f);
        return true;
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        renderBackground(ctx);

        float cell = Math.min(width, height) / 26f * zoom;
        MatrixStack ms = ctx.getMatrices();
        ms.push();
        ms.translate(width / 2f, height / 2f + 10f, 200f);
        ms.scale(cell, cell, cell);
        ms.multiply(RotationAxis.POSITIVE_X.rotationDegrees(-pitch));
        ms.multiply(RotationAxis.POSITIVE_Y.rotationDegrees(yaw));
        ms.translate(-data.nx / 2f, 0f, -data.nz / 2f);
        Matrix4f mat = ms.peek().getPositionMatrix();

        RenderSystem.enableDepthTest();
        RenderSystem.disableCull();
        RenderSystem.setShader(GameRenderer::getPositionColorProgram);
        BufferBuilder bb = Tessellator.getInstance().getBuffer();
        bb.begin(VertexFormat.DrawMode.QUADS, VertexFormats.POSITION_COLOR);
        drawMap(bb, mat);
        Tessellator.getInstance().draw();
        RenderSystem.enableCull();
        ms.pop();
        RenderSystem.clear(256, MinecraftClient.IS_SYSTEM_MAC); // depth only, so the buttons/text draw normally

        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Carrot \u2014 drag to rotate"), width / 2, 8, 0xFFFFFF);
        ctx.drawCenteredTextWithShadow(textRenderer,
                Text.literal("red = you   gold = exit   aqua = pillar   dark = old data"), width / 2, height - 14, 0xAAAAAA);
        super.render(ctx, mouseX, mouseY, delta);
    }

    private void drawMap(BufferBuilder bb, Matrix4f m) {
        for (int z = 0; z < data.nz; z++) {
            for (int x = 0; x < data.nx; x++) {
                int c = z * data.nx + x;
                byte s = data.state[c];
                if (s == MazeConfig.SCAN_UNKNOWN) {
                    continue;
                }
                float fresh = 1f - 0.6f * Math.min(data.age[c], 120) / 120f;
                if (s == MazeConfig.SCAN_WALL) {
                    box(bb, m, x, z, 1f, 1f, WALL_HEIGHT, 0.62f * fresh, 0.64f * fresh, 0.68f * fresh);
                } else {
                    box(bb, m, x, z, 1f, 1f, 0f, 0.15f * fresh, 0.55f * fresh, 0.30f * fresh);
                }
                if (s == MazeConfig.SCAN_PORTAL) {
                    box(bb, m, x + 0.3f, z + 0.3f, 0.4f, 0.4f, 1.4f, 1.0f, 0.78f, 0.15f);
                }
            }
        }
        for (int c : data.marks) {
            int x = c % data.nx;
            int z = c / data.nx;
            box(bb, m, x + 0.35f, z + 0.35f, 0.3f, 0.3f, 1.2f, 0.2f, 0.85f, 0.95f);
        }
        if (data.playerCol >= 0) {
            int x = data.playerCol % data.nx;
            int z = data.playerCol / data.nx;
            box(bb, m, x + 0.3f, z + 0.3f, 0.4f, 0.4f, 1.0f, 1.0f, 0.2f, 0.2f);
        }
    }

    /** A box standing on y=0 and rising to height h (model y points DOWN, so the top is at -h). */
    private static void box(BufferBuilder bb, Matrix4f m, float x0, float z0, float w, float d, float h,
                            float r, float g, float b) {
        float x1 = x0 + w;
        float z1 = z0 + d;
        float y = -h;
        quad(bb, m, x0, y, z0, x1, y, z0, x1, y, z1, x0, y, z1, r, g, b);                     // top
        if (h <= 0f) {
            return;
        }
        quad(bb, m, x0, 0, z0, x1, 0, z0, x1, y, z0, x0, y, z0, r * 0.8f, g * 0.8f, b * 0.8f); // z0 side
        quad(bb, m, x0, 0, z1, x1, 0, z1, x1, y, z1, x0, y, z1, r * 0.7f, g * 0.7f, b * 0.7f); // z1 side
        quad(bb, m, x0, 0, z0, x0, 0, z1, x0, y, z1, x0, y, z0, r * 0.6f, g * 0.6f, b * 0.6f); // x0 side
        quad(bb, m, x1, 0, z0, x1, 0, z1, x1, y, z1, x1, y, z0, r * 0.9f, g * 0.9f, b * 0.9f); // x1 side
    }

    private static void quad(BufferBuilder bb, Matrix4f m,
                             float x1, float y1, float z1, float x2, float y2, float z2,
                             float x3, float y3, float z3, float x4, float y4, float z4,
                             float r, float g, float b) {
        int ri = (int) (MathHelper.clamp(r, 0f, 1f) * 255f);
        int gi = (int) (MathHelper.clamp(g, 0f, 1f) * 255f);
        int bi = (int) (MathHelper.clamp(b, 0f, 1f) * 255f);
        bb.vertex(m, x1, y1, z1).color(ri, gi, bi, 255).next();
        bb.vertex(m, x2, y2, z2).color(ri, gi, bi, 255).next();
        bb.vertex(m, x3, y3, z3).color(ri, gi, bi, 255).next();
        bb.vertex(m, x4, y4, z4).color(ri, gi, bi, 255).next();
    }
}
