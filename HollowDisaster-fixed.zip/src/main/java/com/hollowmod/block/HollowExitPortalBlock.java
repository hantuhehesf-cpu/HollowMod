package com.hollowmod.block;

import com.hollowmod.event.HollowDimensionEvents;
import com.hollowmod.registry.ModDimensions;
import com.hollowmod.state.HollowWorldState;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.Entity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/**
 * The "kerja keras" exit: found by exploring HollowDimension. Stepping into it sends the player
 * back to wherever they were pulled in from (see HollowDimensionEvents#teleportToHollowDimension,
 * which records the return point in HollowWorldState before the player ever arrives).
 *
 * This is a simplified stand-in for a full vanilla-style jigsaw/structure NBT piece: hand-writing
 * a binary structure NBT file isn't practical without an in-game structure block, so this ships
 * as a single functional block you can dress up with a multiblock frame (built procedurally, or
 * exported as a proper structure once you've designed one in-game).
 */
public class HollowExitPortalBlock extends Block {

    public HollowExitPortalBlock(Settings settings) {
        super(settings);
    }

    @Override
    public void onEntityCollision(BlockState state, World world, BlockPos pos, Entity entity) {
        super.onEntityCollision(state, world, pos, entity);
        if (world.isClient || !(entity instanceof ServerPlayerEntity player)) {
            return;
        }
        if (player.getWorld().getRegistryKey() != ModDimensions.HOLLOW_DIMENSION_KEY) {
            return; // this block only does something when stepped on from inside the Hollow
        }

        MinecraftServerAccessHelper.teleportPlayerHome(player);
    }

    /**
     * Small static helper kept in this file (rather than inlined) so HollowDimensionEvents can
     * reuse the exact same "send them home" logic for the death/respawn-lock edge case.
     */
    public static final class MinecraftServerAccessHelper {
        public static void teleportPlayerHome(ServerPlayerEntity player) {
            HollowWorldState state = HollowWorldState.get(player.getServer());
            HollowWorldState.ReturnPoint rp = state.takeReturnPosition(player.getUuid());

            ServerWorld destination = rp != null
                    ? player.getServer().getWorld(rp.dimension())
                    : null;
            if (destination == null) {
                destination = player.getServer().getOverworld();
            }

            BlockPos spawn = destination.getSpawnPos();
            double x = rp != null ? rp.x() : spawn.getX() + 0.5;
            double y = rp != null ? rp.y() : spawn.getY();
            double z = rp != null ? rp.z() : spawn.getZ() + 0.5;

            // BUGFIX (v1.1.2): the recorded return point is literally where the player crossed
            // INTO a dome (distance <= radius was true right there), so sending them back to it
            // verbatim could get them immediately re-teleported into the Hollow the very next
            // tick -- worse if that dome grew while they were inside. Push them clear of every
            // active dome in the destination world before actually teleporting.
            BlockPos safePos = HollowDimensionEvents.pushOutsideAnyDome(destination, x, y, z);
            x = safePos.getX() + 0.5;
            y = safePos.getY();
            z = safePos.getZ() + 0.5;

            player.teleport(destination, x, y, z, player.getYaw(), player.getPitch());
            player.sendMessage(Text.translatable("hollowmod.exit_portal.escaped"), true);
        }

        private MinecraftServerAccessHelper() {
        }
    }
}
