package com.hollowmod.block;

import com.hollowmod.maze.MazeSystem;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.state.StateManager;
import net.minecraft.state.property.BooleanProperty;
import net.minecraft.text.Text;
import net.minecraft.util.ActionResult;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/**
 * SYSTEM 6: a sonar pillar inside the maze. Right-click to bring it online; from then on it
 * sweeps the surrounding cells every few seconds (see MazeSystem#ping).
 */
public class ObservationPillarBlock extends Block {

    public static final BooleanProperty ACTIVE = BooleanProperty.of("active");

    public ObservationPillarBlock(Settings settings) {
        super(settings);
        this.setDefaultState(this.getStateManager().getDefaultState().with(ACTIVE, false));
    }

    @Override
    protected void appendProperties(StateManager.Builder<Block, BlockState> builder) {
        builder.add(ACTIVE);
    }

    @Override
    public ActionResult onUse(BlockState state, World world, BlockPos pos, PlayerEntity player,
                              Hand hand, BlockHitResult hit) {
        if (world.isClient) {
            return ActionResult.SUCCESS;
        }
        if (state.get(ACTIVE)) {
            player.sendMessage(Text.literal("This pillar is already online."), true);
            return ActionResult.CONSUME;
        }
        if (world instanceof ServerWorld serverWorld && player instanceof ServerPlayerEntity serverPlayer) {
            MazeSystem.activatePillar(serverWorld, pos, serverPlayer);
        }
        return ActionResult.CONSUME;
    }
}
