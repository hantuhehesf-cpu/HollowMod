package com.hollowmod.maze;

import com.hollowmod.HollowMod;
import com.hollowmod.block.ObservationPillarBlock;
import com.hollowmod.registry.ModBlocks;
import com.hollowmod.registry.ModDimensions;
import com.hollowmod.state.HollowWorldState;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.block.Block;
import com.hollowmod.network.HollowNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.block.BlockState;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.Heightmap;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.UUID;

import static com.hollowmod.maze.MazeConfig.CELL;
import static com.hollowmod.maze.MazeConfig.NX;
import static com.hollowmod.maze.MazeConfig.NZ;
import static com.hollowmod.maze.MazeConfig.col;
import static com.hollowmod.maze.MazeConfig.colX;
import static com.hollowmod.maze.MazeConfig.colZ;

/**
 * SYSTEM 6: shifting maze + sonar navigation.
 * Everything here only runs while at least one player is inside a Hollow's sub-region.
 *
 *  1. Build: the first time someone is inside, the maze zone (centered on the sub-region
 *     center) is painted time-sliced, then the exit portal and the pillars are placed.
 *  2. Sonar: every PING_INTERVAL_TICKS each ACTIVE pillar casts rays through the cell grid and
 *     writes what it saw (open / wall / portal) into the scan map.
 *  3. Shift: every SHIFT_MIN..SHIFT_MAX ticks, 1-3 cells near a player flip wall<->open, but only
 *     if the exit portal stays reachable from everything it could reach before.
 */
public final class MazeSystem {

    private static final Random RNG = new Random();
    private static final CellContent CONTENT = new GenericCellContent();

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(MazeSystem::tick);
    }

    /** Min corner (floor layer) of the maze box. Requires m.groundY to be measured. */
    public static BlockPos origin(HollowWorldState hs, UUID id, MazeData m) {
        BlockPos c = HollowWorldState.slotToSubRegionCenter(hs.getOrAssignSlot(id));
        return new BlockPos(c.getX() - NX * CELL / 2, m.groundY - CELL, c.getZ() - NZ * CELL / 2);
    }

    private static BlockPos columnOrigin(BlockPos o, int x, int z) {
        return new BlockPos(o.getX() + x * CELL, o.getY(), o.getZ() + z * CELL);
    }

    private static BlockPos columnCenter(BlockPos o, int col, int y) {
        return new BlockPos(o.getX() + colX(col) * CELL + CELL / 2, y, o.getZ() + colZ(col) * CELL + CELL / 2);
    }

    // ------------------------------------------------------------------ tick

    private static void tick(MinecraftServer server) {
        ServerWorld world = server.getWorld(ModDimensions.HOLLOW_DIMENSION_KEY);
        if (world == null || world.getPlayers().isEmpty()) {
            return;
        }
        HollowWorldState hs = HollowWorldState.get(server);

        Map<UUID, List<ServerPlayerEntity>> byHollow = new HashMap<>();
        for (ServerPlayerEntity p : world.getPlayers()) {
            UUID id = hs.getCurrentHollow(p.getUuid());
            if (id != null) {
                byHollow.computeIfAbsent(id, k -> new ArrayList<>()).add(p);
            }
        }

        long now = world.getTime();
        for (Map.Entry<UUID, List<ServerPlayerEntity>> e : byHollow.entrySet()) {
            UUID id = e.getKey();
            MazeData m = hs.getMaze(id);
            if (m == null) {
                m = MazeGenerator.generate(new Random(id.getMostSignificantBits() ^ id.getLeastSignificantBits()));
                hs.putMaze(id, m);
            }
            if (!m.built) {
                paint(world, hs, id, m, now);
                continue;
            }
            if (now % MazeConfig.PING_INTERVAL_TICKS == 0) {
                ping(world, m, origin(hs, id, m), now);
                hs.markDirty();
            }
            if (now >= m.nextShiftTick) {
                shift(world, hs, id, m, e.getValue(), now);
            }
        }
    }

    // ------------------------------------------------------------------ build

    private static void paint(ServerWorld world, HollowWorldState hs, UUID id, MazeData m, long now) {
        if (m.groundY == Integer.MIN_VALUE) {
            BlockPos c = HollowWorldState.slotToSubRegionCenter(hs.getOrAssignSlot(id));
            world.getChunk(c.getX() >> 4, c.getZ() >> 4); // World#getTopY returns bottom Y for unloaded chunks
            int top = world.getTopY(Heightmap.Type.MOTION_BLOCKING, c.getX(), c.getZ());
            m.groundY = Math.max(top, world.getBottomY() + 2 * CELL);
            hs.markDirty();
        }
        BlockPos o = origin(hs, id, m);
        int total = NX * NZ;
        int budget = MazeConfig.PAINT_BUDGET_PER_TICK;
        while (m.paintCursor < total && budget > 0) {
            int c = m.paintCursor;
            budget -= CONTENT.paintColumn(world, columnOrigin(o, colX(c), colZ(c)), m.solid[c] != 0);
            m.paintCursor++;
        }
        if (m.paintCursor >= total) {
            finishBuild(world, hs, id, m, o, now);
        }
    }

    private static void finishBuild(ServerWorld world, HollowWorldState hs, UUID id, MazeData m, BlockPos o, long now) {
        int floorY = o.getY() + CELL;
        world.setBlockState(columnCenter(o, m.portalCol, floorY),
                ModBlocks.HOLLOW_EXIT_PORTAL.getDefaultState(), Block.NOTIFY_LISTENERS);
        for (int col : m.pillarCols) {
            BlockPos base = columnCenter(o, col, floorY);
            for (int i = 0; i < MazeConfig.PILLAR_HEIGHT; i++) {
                world.setBlockState(base.up(i), ModBlocks.OBSERVATION_PILLAR.getDefaultState(), Block.NOTIFY_LISTENERS);
            }
        }
        m.built = true;
        m.nextShiftTick = now + randomShiftInterval();
        hs.markDirty();
        HollowMod.LOGGER.info("[HollowMod] Maze built for Hollow {} ({}x{} cells, portal col {}, {} pillars)",
                id, NX, NZ, m.portalCol, m.pillarCols.length);
    }

    private static int randomShiftInterval() {
        return MazeConfig.SHIFT_MIN_TICKS + RNG.nextInt(MazeConfig.SHIFT_MAX_TICKS - MazeConfig.SHIFT_MIN_TICKS + 1);
    }

    // ------------------------------------------------------------------ sonar

    /**
     * One sweep of every active pillar (generated AND player-built). A pillar only sweeps if it
     * still exists and is active, and only if it stands inside the corridor layer (sonar does not
     * pass through floor or roof). Rays march through the cell grid; cells outside the grid are
     * skipped, so a pillar just outside a gate can still see the border walls.
     */
    private static void ping(ServerWorld world, MazeData m, BlockPos o, long now) {
        int floorY = o.getY() + CELL;
        Iterator<Long> it = m.sensors.iterator();
        while (it.hasNext()) {
            BlockPos s = BlockPos.fromLong(it.next());
            if (world.isChunkLoaded(s.getX() >> 4, s.getZ() >> 4)) {
                BlockState st = world.getBlockState(s);
                if (!st.isOf(ModBlocks.OBSERVATION_PILLAR) || !st.get(ObservationPillarBlock.ACTIVE)) {
                    it.remove(); // broken or replaced
                    continue;
                }
            }
            if (s.getY() < floorY || s.getY() >= floorY + CELL) {
                continue; // outside the corridor layer
            }
            double px = (s.getX() + 0.5 - o.getX()) / CELL;
            double pz = (s.getZ() + 0.5 - o.getZ()) / CELL;
            for (int r = 0; r < MazeConfig.SONAR_RAYS; r++) {
                double angle = 2.0 * Math.PI * r / MazeConfig.SONAR_RAYS;
                double dx = Math.cos(angle);
                double dz = Math.sin(angle);
                for (double t = 0.0; t <= MazeConfig.SONAR_RANGE_CELLS; t += 0.2) {
                    int ix = (int) Math.floor(px + dx * t);
                    int iz = (int) Math.floor(pz + dz * t);
                    if (ix < 0 || iz < 0 || ix >= NX || iz >= NZ) {
                        continue;
                    }
                    int c = col(ix, iz);
                    if (m.solid[c] != 0) {
                        m.scan[c] = MazeConfig.SCAN_WALL;
                        m.scanTick[c] = now;
                        break;
                    }
                    m.scan[c] = (c == m.portalCol) ? MazeConfig.SCAN_PORTAL : MazeConfig.SCAN_OPEN;
                    m.scanTick[c] = now;
                }
            }
        }
    }

    /** Called by ObservationPillarBlock when a player activates a pillar (any pillar, anywhere in the Hollow). */
    public static void activatePillar(ServerWorld world, BlockPos pos, ServerPlayerEntity player) {
        if (world.getRegistryKey() != ModDimensions.HOLLOW_DIMENSION_KEY) {
            player.sendMessage(Text.literal("The sonar only works inside a Hollow."), true);
            return;
        }
        HollowWorldState hs = HollowWorldState.get(world.getServer());
        UUID id = hs.getCurrentHollow(player.getUuid());
        MazeData m = id == null ? null : hs.getMaze(id);
        if (m == null || !m.built) {
            player.sendMessage(Text.literal("The maze isn't ready yet. Try again in a moment."), true);
            return;
        }

        // light up the whole stack of pillar blocks this one belongs to
        BlockPos bottom = pos;
        while (world.getBlockState(bottom.down()).isOf(ModBlocks.OBSERVATION_PILLAR)) {
            bottom = bottom.down();
        }
        BlockState active = ModBlocks.OBSERVATION_PILLAR.getDefaultState().with(ObservationPillarBlock.ACTIVE, true);
        for (int i = 0; i < 8 && world.getBlockState(bottom.up(i)).isOf(ModBlocks.OBSERVATION_PILLAR); i++) {
            world.setBlockState(bottom.up(i), active, Block.NOTIFY_ALL);
        }

        BlockPos o = origin(hs, id, m);
        long key = bottom.asLong();
        if (!m.sensors.contains(key)) {
            if (m.sensors.size() >= MazeConfig.MAX_SENSORS) {
                player.sendMessage(Text.literal("Too many active pillars in this Hollow."), true);
                return;
            }
            m.sensors.add(key);
        }

        // keep the "generated pillar is online" flag in sync (used by the debug map)
        int ix = Math.floorDiv(bottom.getX() - o.getX(), CELL);
        int iz = Math.floorDiv(bottom.getZ() - o.getZ(), CELL);
        if (ix >= 0 && iz >= 0 && ix < NX && iz < NZ) {
            int c = col(ix, iz);
            for (int i = 0; i < m.pillarCols.length; i++) {
                if (m.pillarCols[i] == c) {
                    m.pillarActive[i] = 1;
                }
            }
        }

        boolean inLayer = bottom.getY() >= o.getY() + CELL && bottom.getY() < o.getY() + 2 * CELL;
        ping(world, m, o, world.getTime());
        hs.markDirty();
        player.sendMessage(Text.literal(inLayer
                ? "Observation Pillar online. Sonar sweep started."
                : "Pillar online, but sonar can't pass through the maze floor or roof."), true);
    }

    // ------------------------------------------------------------------ Carrot map

    /** Sends the current scan map to the player so the client can open the Carrot screen. */
    public static boolean sendCarrotMap(ServerWorld world, ServerPlayerEntity player) {
        if (world.getRegistryKey() != ModDimensions.HOLLOW_DIMENSION_KEY) {
            return false;
        }
        HollowWorldState hs = HollowWorldState.get(world.getServer());
        UUID id = hs.getCurrentHollow(player.getUuid());
        MazeData m = id == null ? null : hs.getMaze(id);
        if (m == null || !m.built) {
            return false;
        }
        BlockPos o = origin(hs, id, m);
        long now = world.getTime();

        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeInt(NX);
        buf.writeInt(NZ);

        int px = Math.floorDiv(MathHelper.floor(player.getX()) - o.getX(), CELL);
        int pz = Math.floorDiv(MathHelper.floor(player.getZ()) - o.getZ(), CELL);
        boolean inside = px >= 0 && pz >= 0 && px < NX && pz < NZ;
        buf.writeInt(inside ? col(px, pz) : -1);

        for (int c = 0; c < NX * NZ; c++) {
            buf.writeByte(m.scan[c]);
            int age = m.scan[c] == MazeConfig.SCAN_UNKNOWN ? 0 : (int) Math.min(255L, Math.max(0L, (now - m.scanTick[c]) / 20L));
            buf.writeByte(age);
        }

        Set<Integer> marks = new HashSet<>();
        for (int c : m.pillarCols) {
            if (m.scan[c] != MazeConfig.SCAN_UNKNOWN) {
                marks.add(c);
            }
        }
        for (long key : m.sensors) {
            BlockPos s = BlockPos.fromLong(key);
            int ix = Math.floorDiv(s.getX() - o.getX(), CELL);
            int iz = Math.floorDiv(s.getZ() - o.getZ(), CELL);
            if (ix >= 0 && iz >= 0 && ix < NX && iz < NZ) {
                marks.add(col(ix, iz));
            }
        }
        buf.writeInt(marks.size());
        for (int c : marks) {
            buf.writeInt(c);
        }
        ServerPlayNetworking.send(player, HollowNetworking.CARROT_MAP, buf);
        return true;
    }

    // ------------------------------------------------------------------ shifting

    private static void shift(ServerWorld world, HollowWorldState hs, UUID id, MazeData m,
                              List<ServerPlayerEntity> players, long now) {
        m.nextShiftTick = now + randomShiftInterval();
        hs.markDirty();

        BlockPos o = origin(hs, id, m);
        List<int[]> playerCells = new ArrayList<>();
        for (ServerPlayerEntity p : players) {
            int ix = Math.floorDiv(MathHelper.floor(p.getX()) - o.getX(), CELL);
            int iz = Math.floorDiv(MathHelper.floor(p.getZ()) - o.getZ(), CELL);
            if (ix >= 0 && iz >= 0 && ix < NX && iz < NZ) {
                playerCells.add(new int[]{ix, iz});
            }
        }
        if (playerCells.isEmpty()) {
            return; // nobody is inside the maze box: nothing to shift
        }
        int flips = 1 + RNG.nextInt(3);
        for (int f = 0; f < flips; f++) {
            tryFlipOne(world, m, o, playerCells);
        }
    }

    private static void tryFlipOne(ServerWorld world, MazeData m, BlockPos o, List<int[]> playerCells) {
        int r = MazeConfig.SHIFT_RADIUS_CELLS;
        for (int attempt = 0; attempt < 12; attempt++) {
            int[] pc = playerCells.get(RNG.nextInt(playerCells.size()));
            int x = pc[0] + RNG.nextInt(2 * r + 1) - r;
            int z = pc[1] + RNG.nextInt(2 * r + 1) - r;
            if (x < 1 || z < 1 || x > NX - 2 || z > NZ - 2) {
                continue; // border (walls + gates) never flips
            }
            int c = col(x, z);
            if (isLocked(m, c) || nearAnyPlayer(playerCells, x, z) || containsPillar(world, columnOrigin(o, x, z))
                    || !flipKeepsMazeSolvable(m, c)) {
                continue;
            }
            m.solid[c] = (byte) (m.solid[c] != 0 ? 0 : 1);
            CONTENT.paintCorridor(world, columnOrigin(o, x, z), m.solid[c] != 0);
            return;
        }
    }

    private static boolean isLocked(MazeData m, int c) {
        if (c == m.portalCol) {
            return true;
        }
        for (int p : m.pillarCols) {
            if (p == c) {
                return true;
            }
        }
        return false;
    }

    /** Player-built (or generated) pillars inside a cell lock that cell so a flip can't erase them. */
    private static boolean containsPillar(ServerWorld world, BlockPos columnOrigin) {
        BlockPos.Mutable p = new BlockPos.Mutable();
        int y0 = columnOrigin.getY() + CELL;
        for (int dy = 0; dy < CELL; dy++) {
            for (int dx = 0; dx < CELL; dx++) {
                for (int dz = 0; dz < CELL; dz++) {
                    p.set(columnOrigin.getX() + dx, y0 + dy, columnOrigin.getZ() + dz);
                    if (world.getBlockState(p).isOf(ModBlocks.OBSERVATION_PILLAR)) {
                        return true;
                    }
                }
            }
        }
        return false;
    }

    private static boolean nearAnyPlayer(List<int[]> playerCells, int x, int z) {
        for (int[] pc : playerCells) {
            if (Math.abs(pc[0] - x) <= 1 && Math.abs(pc[1] - z) <= 1) {
                return true;
            }
        }
        return false;
    }

    /**
     * Opening a cell can never cut anything off. Closing one must not disconnect any other cell
     * the portal could reach (so the reachable count may only drop by that one cell).
     */
    private static boolean flipKeepsMazeSolvable(MazeData m, int c) {
        boolean wasSolid = m.solid[c] != 0;
        if (wasSolid) {
            return true;
        }
        int before = MazeGenerator.reach(m.solid, m.portalCol);
        m.solid[c] = 1;
        int after = MazeGenerator.reach(m.solid, m.portalCol);
        m.solid[c] = 0;
        return after >= before - 1;
    }

    private MazeSystem() {
    }
}
