package com.hollowmod.maze;

import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;

/**
 * "What does this cell become?" lives behind this interface so the shifting logic never needs to
 * know. v1.2 now: generic blocks (GenericCellContent). v1.2 end target: city pieces.
 * columnOrigin = min corner of the FLOOR layer of that column (x, originY, z).
 * Both methods return the block volume they covered (used only for the per-tick budget).
 */
public interface CellContent {

    /** Paints a whole column: floor slab + corridor cell + roof slab. Used for the first build. */
    int paintColumn(ServerWorld world, BlockPos columnOrigin, boolean solid);

    /** Re-paints only the corridor cell. Used when shifting flips a cell. */
    int paintCorridor(ServerWorld world, BlockPos columnOrigin, boolean solid);
}
