package com.hollowmod.maze;

/** All System 6 tuning numbers in one place. Everything marked (proposal) in the spec lives here. */
public final class MazeConfig {

    /** Edge length of one maze cell in blocks. */
    public static final int CELL = 8;
    /** Maze width/depth in cells. MUST be odd (walls on the border, nodes on odd coordinates). */
    public static final int NX = 21;
    public static final int NZ = 21;
    /** Thickness (blocks) of the floor slab and roof slab above/below the corridor layer. */
    public static final int SLAB = 2;

    public static final int PILLAR_COUNT = 3;
    public static final int PILLAR_HEIGHT = 3;
    /** Chance that a wall between two nodes is opened after generation (loops / alternate routes). */
    public static final double LOOP_CHANCE = 0.12;

    public static final int PING_INTERVAL_TICKS = 100;
    public static final double SONAR_RANGE_CELLS = 6.0;
    public static final int SONAR_RAYS = 32;

    public static final int SHIFT_MIN_TICKS = 1200;
    public static final int SHIFT_MAX_TICKS = 1800;
    public static final int SHIFT_RADIUS_CELLS = 4;

    /** Block-volume budget per server tick while painting the maze for the first time. */
    public static final int PAINT_BUDGET_PER_TICK = 2000;

    public static final byte SCAN_UNKNOWN = 0;
    public static final byte SCAN_OPEN = 1;
    public static final byte SCAN_WALL = 2;
    public static final byte SCAN_PORTAL = 3;

    public static int col(int x, int z) {
        return z * NX + x;
    }

    public static int colX(int col) {
        return col % NX;
    }

    public static int colZ(int col) {
        return col / NX;
    }

    private MazeConfig() {
    }
}
