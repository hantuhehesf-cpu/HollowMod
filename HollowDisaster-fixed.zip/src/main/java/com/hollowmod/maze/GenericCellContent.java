package com.hollowmod.maze;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;

import static com.hollowmod.maze.MazeConfig.CELL;
import static com.hollowmod.maze.MazeConfig.SLAB;

/** Plain concrete maze: floor slab, 8-high corridor cell (wall or air + one lamp), roof slab. */
public final class GenericCellContent implements CellContent {

    private static final BlockState WALL = Blocks.GRAY_CONCRETE.getDefaultState();
    private static final BlockState FLOOR = Blocks.LIGHT_GRAY_CONCRETE.getDefaultState();
    private static final BlockState LAMP = Blocks.SEA_LANTERN.getDefaultState();
    private static final BlockState AIR = Blocks.AIR.getDefaultState();

    @Override
    public int paintColumn(ServerWorld world, BlockPos o, boolean solid) {
        int n = 0;
        n += fill(world, o.getX(), o.getY() + CELL - SLAB, o.getZ(), SLAB, FLOOR);   // floor slab: top SLAB blocks of layer 0
        n += paintCorridor(world, o, solid);
        n += fill(world, o.getX(), o.getY() + 2 * CELL, o.getZ(), SLAB, WALL);       // roof slab: bottom SLAB blocks of layer 2
        return n;
    }

    @Override
    public int paintCorridor(ServerWorld world, BlockPos o, boolean solid) {
        int y0 = o.getY() + CELL;
        int n = fill(world, o.getX(), y0, o.getZ(), CELL, solid ? WALL : AIR);
        if (!solid) {
            BlockPos lamp = new BlockPos(o.getX() + CELL / 2, y0 + CELL - 1, o.getZ() + CELL / 2);
            world.setBlockState(lamp, LAMP, Block.NOTIFY_LISTENERS);
        }
        return n;
    }

    /** Fills a CELL x height x CELL box. Skips blocks that already match. */
    private static int fill(ServerWorld w, int x0, int y0, int z0, int height, BlockState state) {
        BlockPos.Mutable p = new BlockPos.Mutable();
        boolean wantAir = state.isAir();
        for (int dy = 0; dy < height; dy++) {
            int y = y0 + dy;
            if (w.isOutOfHeightLimit(y)) {
                continue;
            }
            for (int dx = 0; dx < CELL; dx++) {
                for (int dz = 0; dz < CELL; dz++) {
                    p.set(x0 + dx, y, z0 + dz);
                    BlockState cur = w.getBlockState(p);
                    if (wantAir ? cur.isAir() : cur == state) {
                        continue;
                    }
                    w.setBlockState(p, state, Block.NOTIFY_LISTENERS);
                }
            }
        }
        return CELL * CELL * height;
    }
}
