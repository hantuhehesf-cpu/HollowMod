package com.hollowmod.maze;

import net.minecraft.nbt.NbtCompound;

import java.util.ArrayList;
import java.util.List;

/**
 * Everything System 6 knows about one Hollow's maze. The maze is ONE corridor layer (floor slab
 * below, roof slab above), stored per "column" = one cell of the NX x NZ grid.
 */
public final class MazeData {

    /** 1 = solid wall, 0 = open corridor. Index = MazeConfig.col(x, z). */
    public byte[] solid = new byte[MazeConfig.NX * MazeConfig.NZ];
    /** What the sonar has seen: MazeConfig.SCAN_*. */
    public byte[] scan = new byte[MazeConfig.NX * MazeConfig.NZ];
    /** World time (ticks) the sonar last wrote each column. */
    public long[] scanTick = new long[MazeConfig.NX * MazeConfig.NZ];

    public int[] pillarCols = new int[0];
    public byte[] pillarActive = new byte[0];
    /** Positions (BlockPos#asLong) of every ACTIVE pillar that sweeps, generated or player-built. */
    public List<Long> sensors = new ArrayList<>();
    public int portalCol = -1;

    /** Ground height (feet Y) at the maze center, measured once. Integer.MIN_VALUE = not measured. */
    public int groundY = Integer.MIN_VALUE;
    public boolean built = false;
    public long nextShiftTick = 0;

    /** Painting progress; not saved (an unfinished paint simply restarts, which is harmless). */
    public int paintCursor = 0;

    public NbtCompound toNbt() {
        NbtCompound n = new NbtCompound();
        n.putByteArray("Solid", solid);
        n.putByteArray("Scan", scan);
        n.putLongArray("ScanTick", scanTick);
        n.putIntArray("PillarCols", pillarCols);
        n.putByteArray("PillarActive", pillarActive);
        long[] sensorArr = new long[sensors.size()];
        for (int i = 0; i < sensorArr.length; i++) {
            sensorArr[i] = sensors.get(i);
        }
        n.putLongArray("Sensors", sensorArr);
        n.putInt("PortalCol", portalCol);
        n.putInt("GroundY", groundY);
        n.putBoolean("Built", built);
        n.putLong("NextShift", nextShiftTick);
        return n;
    }

    /** Returns null if the saved data doesn't match the current grid size (config changed). */
    public static MazeData fromNbt(NbtCompound n) {
        int size = MazeConfig.NX * MazeConfig.NZ;
        byte[] solid = n.getByteArray("Solid");
        byte[] scan = n.getByteArray("Scan");
        long[] scanTick = n.getLongArray("ScanTick");
        if (solid.length != size || scan.length != size || scanTick.length != size) {
            return null;
        }
        MazeData d = new MazeData();
        d.solid = solid;
        d.scan = scan;
        d.scanTick = scanTick;
        d.pillarCols = n.getIntArray("PillarCols");
        d.pillarActive = n.getByteArray("PillarActive");
        if (d.pillarActive.length != d.pillarCols.length) {
            d.pillarActive = new byte[d.pillarCols.length];
        }
        for (long s : n.getLongArray("Sensors")) {
            d.sensors.add(s);
        }
        d.portalCol = n.getInt("PortalCol");
        d.groundY = n.getInt("GroundY");
        d.built = n.getBoolean("Built");
        d.nextShiftTick = n.getLong("NextShift");
        return d;
    }
}
