package com.hollowmod.maze;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import static com.hollowmod.maze.MazeConfig.NX;
import static com.hollowmod.maze.MazeConfig.NZ;
import static com.hollowmod.maze.MazeConfig.col;

/**
 * Initial maze layout: recursive backtracker on the odd-coordinate "node" lattice (guarantees
 * every open cell is connected), then a few extra openings for loops, four border gates, a
 * portal far from the gates and a few well-spread pillars.
 */
public final class MazeGenerator {

    public static MazeData generate(Random rnd) {
        int nodesX = (NX - 1) / 2;
        int nodesZ = (NZ - 1) / 2;
        MazeData d = new MazeData();
        Arrays.fill(d.solid, (byte) 1);

        // --- recursive backtracker (iterative) ---
        boolean[] visited = new boolean[nodesX * nodesZ];
        int[] stack = new int[nodesX * nodesZ];
        int sp = 0;
        int start = rnd.nextInt(nodesX * nodesZ);
        visited[start] = true;
        stack[sp++] = start;
        open(d, 2 * (start % nodesX) + 1, 2 * (start / nodesX) + 1);
        int[] dx = {1, -1, 0, 0};
        int[] dz = {0, 0, 1, -1};
        int[] cand = new int[4];
        while (sp > 0) {
            int cur = stack[sp - 1];
            int cx = cur % nodesX;
            int cz = cur / nodesX;
            int n = 0;
            for (int i = 0; i < 4; i++) {
                int ax = cx + dx[i];
                int az = cz + dz[i];
                if (ax < 0 || az < 0 || ax >= nodesX || az >= nodesZ) {
                    continue;
                }
                if (visited[az * nodesX + ax]) {
                    continue;
                }
                cand[n++] = i;
            }
            if (n == 0) {
                sp--;
                continue;
            }
            int dir = cand[rnd.nextInt(n)];
            int ax = cx + dx[dir];
            int az = cz + dz[dir];
            open(d, 2 * cx + 1 + dx[dir], 2 * cz + 1 + dz[dir]); // the wall between
            open(d, 2 * ax + 1, 2 * az + 1);                     // the new node
            visited[az * nodesX + ax] = true;
            stack[sp++] = az * nodesX + ax;
        }

        // --- loops: open some interior walls that sit between two nodes ---
        for (int z = 1; z <= NZ - 2; z++) {
            for (int x = 1; x <= NX - 2; x++) {
                boolean xOdd = (x & 1) == 1;
                boolean zOdd = (z & 1) == 1;
                if (xOdd == zOdd) {
                    continue; // nodes (odd,odd) and corner pillars (even,even) are not between-node walls
                }
                int c = col(x, z);
                if (d.solid[c] != 0 && rnd.nextDouble() < MazeConfig.LOOP_CHANCE) {
                    d.solid[c] = 0;
                }
            }
        }

        // --- four gates on the border, one per side ---
        List<Integer> gates = new ArrayList<>();
        gates.add(open(d, 0, 2 * rnd.nextInt(nodesZ) + 1));
        gates.add(open(d, NX - 1, 2 * rnd.nextInt(nodesZ) + 1));
        gates.add(open(d, 2 * rnd.nextInt(nodesX) + 1, 0));
        gates.add(open(d, 2 * rnd.nextInt(nodesX) + 1, NZ - 1));

        // --- distances from the nearest gate ---
        int[] dist = new int[NX * NZ];
        Arrays.fill(dist, -1);
        ArrayDeque<Integer> queue = new ArrayDeque<>();
        for (int g : gates) {
            dist[g] = 0;
            queue.add(g);
        }
        while (!queue.isEmpty()) {
            int c = queue.poll();
            int x = c % NX;
            int z = c / NX;
            int[] nb = {x > 0 ? c - 1 : -1, x < NX - 1 ? c + 1 : -1, z > 0 ? c - NX : -1, z < NZ - 1 ? c + NX : -1};
            for (int nc : nb) {
                if (nc >= 0 && d.solid[nc] == 0 && dist[nc] < 0) {
                    dist[nc] = dist[c] + 1;
                    queue.add(nc);
                }
            }
        }

        // --- nodes list, portal among the farthest quarter ---
        List<Integer> nodes = new ArrayList<>();
        for (int nz = 0; nz < nodesZ; nz++) {
            for (int nx = 0; nx < nodesX; nx++) {
                int c = col(2 * nx + 1, 2 * nz + 1);
                if (dist[c] >= 0) {
                    nodes.add(c);
                }
            }
        }
        List<Integer> byDistance = new ArrayList<>(nodes);
        byDistance.sort((a, b) -> Integer.compare(dist[b], dist[a]));
        int pool = Math.max(1, byDistance.size() / 4);
        d.portalCol = byDistance.get(rnd.nextInt(pool));

        // --- pillars: random nodes, spread apart (relax the spacing if it can't be met) ---
        int[] chosen = new int[MazeConfig.PILLAR_COUNT];
        int count = 0;
        for (int minSep = 8; minSep >= 0 && count < chosen.length; minSep -= 2) {
            for (int attempt = 0; attempt < 300 && count < chosen.length; attempt++) {
                int c = nodes.get(rnd.nextInt(nodes.size()));
                if (c == d.portalCol) {
                    continue;
                }
                boolean ok = true;
                for (int i = 0; i < count; i++) {
                    int manhattan = Math.abs(c % NX - chosen[i] % NX) + Math.abs(c / NX - chosen[i] / NX);
                    if (c == chosen[i] || manhattan < minSep) {
                        ok = false;
                        break;
                    }
                }
                if (ok) {
                    chosen[count++] = c;
                }
            }
        }
        d.pillarCols = Arrays.copyOf(chosen, count);
        d.pillarActive = new byte[count];
        return d;
    }

    private static int open(MazeData d, int x, int z) {
        int c = col(x, z);
        d.solid[c] = 0;
        return c;
    }

    /** How many open cells can be reached from start (0 if start is a wall). */
    public static int reach(byte[] solid, int start) {
        if (start < 0 || start >= solid.length || solid[start] != 0) {
            return 0;
        }
        boolean[] seen = new boolean[solid.length];
        int[] q = new int[solid.length];
        int head = 0;
        int tail = 0;
        q[tail++] = start;
        seen[start] = true;
        while (head < tail) {
            int c = q[head++];
            int x = c % NX;
            int z = c / NX;
            if (x > 0 && solid[c - 1] == 0 && !seen[c - 1]) {
                seen[c - 1] = true;
                q[tail++] = c - 1;
            }
            if (x < NX - 1 && solid[c + 1] == 0 && !seen[c + 1]) {
                seen[c + 1] = true;
                q[tail++] = c + 1;
            }
            if (z > 0 && solid[c - NX] == 0 && !seen[c - NX]) {
                seen[c - NX] = true;
                q[tail++] = c - NX;
            }
            if (z < NZ - 1 && solid[c + NX] == 0 && !seen[c + NX]) {
                seen[c + NX] = true;
                q[tail++] = c + NX;
            }
        }
        return tail;
    }

    private MazeGenerator() {
    }
}
