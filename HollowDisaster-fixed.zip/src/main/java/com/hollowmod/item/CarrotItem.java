package com.hollowmod.item;

import com.hollowmod.maze.MazeSystem;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

/**
 * "Carrot": a viewer for the Hollow's scan map (the data the Observation Pillars collect).
 * It stores nothing itself. Right-click sends the current map to the client, which opens the
 * 3D map screen.
 */
public class CarrotItem extends Item {

    public CarrotItem(Settings settings) {
        super(settings);
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity player, Hand hand) {
        ItemStack stack = player.getStackInHand(hand);
        if (!world.isClient && world instanceof ServerWorld serverWorld && player instanceof ServerPlayerEntity serverPlayer) {
            if (!MazeSystem.sendCarrotMap(serverWorld, serverPlayer)) {
                serverPlayer.sendMessage(Text.literal("Carrot tidak menerima data. Pakai di dalam Hollow yang labirinnya sudah jadi."), true);
            }
        }
        return TypedActionResult.success(stack);
    }
}
