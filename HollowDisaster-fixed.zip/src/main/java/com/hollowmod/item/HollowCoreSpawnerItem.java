package com.hollowmod.item;

import com.hollowmod.entity.HollowCoreEntity;
import com.hollowmod.registry.ModEntities;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemUsageContext;
import net.minecraft.util.ActionResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.World;

/**
 * Functions like a spawn egg (right-click a block face to spawn a Hollow Core there), but is a
 * plain Item rather than SpawnEggItem: vanilla's SpawnEggItem constructor requires
 * EntityType<? extends MobEntity>, and HollowCoreEntity deliberately extends plain Entity (not
 * MobEntity) to avoid AI/pathfinding overhead it doesn't need. This keeps that optimization
 * intact while still giving survival-friendly access instead of requiring /summon.
 */
public class HollowCoreSpawnerItem extends Item {

    public HollowCoreSpawnerItem(Settings settings) {
        super(settings);
    }

    @Override
    public ActionResult useOnBlock(ItemUsageContext context) {
        World world = context.getWorld();
        BlockPos pos = context.getBlockPos().offset(context.getSide());

        if (!world.isClient) {
            HollowCoreEntity entity = new HollowCoreEntity(ModEntities.HOLLOW_CORE_ENTITY, world);
            entity.setPosition(pos.getX() + 0.5, pos.getY(), pos.getZ() + 0.5);
            world.spawnEntity(entity);

            PlayerEntity player = context.getPlayer();
            if (player != null && !player.getAbilities().creativeMode) {
                context.getStack().decrement(1);
            }
        }

        return ActionResult.SUCCESS;
    }
}
