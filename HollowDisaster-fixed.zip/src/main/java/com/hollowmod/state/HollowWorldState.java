package com.hollowmod.state;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.PersistentState;
import net.minecraft.world.World;

import com.hollowmod.maze.MazeData;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Confirmed against Minecraft 1.20.1's PersistentStateManager, whose getOrCreate takes
 * (Function<NbtCompound, T> readFunction, Supplier<T> supplier, String id) directly -- the
 * PersistentState.Type<T> record wrapper is a 1.20.2+ change, so do NOT use that pattern here.
 *
 * v1.2 (System 4): extended with per-Hollow sub-region slot assignment, and a
 * player -> "which Hollow are they currently inside" association (needed so death/respawn and
 * the exit portal can send the player back to the SAME sub-region they entered, not always a
 * single shared location like in v1.1).
 */
public class HollowWorldState extends PersistentState {

    private static final String STATE_ID = "hollowmod_state";

    /** Where to send a player back to once they find the exit portal (or die inside the Hollow). */
    public record ReturnPoint(RegistryKey<World> dimension, double x, double y, double z) {
    }

    private final Map<UUID, ReturnPoint> returnPoints = new HashMap<>();

    // ---- System 4: sub-region slots ----
    // Grid of slots spaced far apart (10,000 blocks) so each Hollow's sub-region reads as its own
    // separate pocket. 5x5 = 25 slots, well beyond the 10-Hollow population cap for headroom.
    private static final int SLOT_GRID_WIDTH = 5;
    private static final int SLOT_SPACING = 10_000;
    private final Map<UUID, Integer> hollowSlots = new HashMap<>();

    // ---- System 5: backlog of eaten blocks not yet placed in the sub-region ----
    /** How far ABOVE the sub-region ground the center of the fragment sphere sits. 0 = center at
     *  ground level (fragments merge with the ground), bigger = floats higher. */
    public static final int FRAGMENT_LIFT = 16;
    /** Half-width of the keep-clear column around the spawn point, so fragments never
     *  materialize inside the player. */
    public static final int SPAWN_CLEAR_RADIUS = 2;
    /** Per-Hollow ground height (feet Y) at the sub-region center, measured once, before any
     *  fragment exists there. Used for spawning and to position the fragments. */
    private final Map<UUID, Integer> fragmentGroundY = new HashMap<>();
    private final Map<UUID, FragmentLog> fragmentLogs = new HashMap<>();

    // ---- System 6: one maze per Hollow ----
    private final Map<UUID, MazeData> mazes = new HashMap<>();

    /** The fragment/spawn column sits this far EAST of the sub-region center, so the fragments
     *  (radius up to 128) don't land inside the maze zone that occupies the center. */
    public static final int FRAGMENT_COLUMN_OFFSET_X = 240;

    // ---- System 4: which Hollow's sub-region is this player currently inside? ----
    private final Map<UUID, UUID> playerCurrentHollow = new HashMap<>();

    public static HollowWorldState get(MinecraftServer server) {
        ServerWorld overworld = server.getOverworld();
        return overworld.getPersistentStateManager().getOrCreate(
                HollowWorldState::fromNbt,
                HollowWorldState::new,
                STATE_ID);
    }

    public void setReturnPosition(UUID playerId, RegistryKey<World> dimension, double x, double y, double z) {
        returnPoints.put(playerId, new ReturnPoint(dimension, x, y, z));
        this.markDirty();
    }

    /** Reads and clears the stored return point in one step (each escape consumes it). */
    public ReturnPoint takeReturnPosition(UUID playerId) {
        ReturnPoint point = returnPoints.remove(playerId);
        if (point != null) {
            this.markDirty();
        }
        return point;
    }

    // ------------------------------------------------------------------
    // System 4: sub-region slot assignment
    // ------------------------------------------------------------------

    /** Returns this Hollow's already-assigned slot, or claims the lowest free one if it doesn't
     *  have one yet. Stable for the Hollow's lifetime once assigned. */
    public int getOrAssignSlot(UUID hollowId) {
        Integer existing = hollowSlots.get(hollowId);
        if (existing != null) {
            return existing;
        }

        int slot = 0;
        while (hollowSlots.containsValue(slot)) {
            slot++;
        }
        hollowSlots.put(hollowId, slot);
        this.markDirty();
        return slot;
    }

    /** Frees a Hollow's slot so a future Hollow can reuse it -- called when a Hollow collapses,
     *  explodes, or is otherwise removed (see HollowCoreEntity.registerTracking's unload hook). */
    public void freeSlot(UUID hollowId) {
        boolean removed = hollowSlots.remove(hollowId) != null;
        removed |= fragmentLogs.remove(hollowId) != null;
        removed |= fragmentGroundY.remove(hollowId) != null;
        removed |= mazes.remove(hollowId) != null;
        if (removed) {
            this.markDirty();
        }
    }

    /** Deterministic slot-index -> sub-region center position (Y matches the existing anchor
     *  height convention used elsewhere for HollowDimension spawn platforms). */
    public static BlockPos slotToSubRegionCenter(int slot) {
        int col = slot % SLOT_GRID_WIDTH;
        int row = slot / SLOT_GRID_WIDTH;
        int x = (col - SLOT_GRID_WIDTH / 2) * SLOT_SPACING;
        int z = (row - SLOT_GRID_WIDTH / 2) * SLOT_SPACING;
        return new BlockPos(x, 32, z);
    }

    /** Where System 5 anchors a Hollow's replicated fragments: same X/Z as the sub-region
     *  center (so they sit right where the player spawns), FRAGMENT_LIFT above the ground. */
    public static BlockPos slotToFragmentAnchor(int slot, int groundY) {
        BlockPos c = slotToFragmentColumn(slot);
        return new BlockPos(c.getX(), groundY + FRAGMENT_LIFT, c.getZ());
    }

    /** X/Z where the player spawns and the fragments are anchored (east of the maze). */
    public static BlockPos slotToFragmentColumn(int slot) {
        BlockPos c = slotToSubRegionCenter(slot);
        return new BlockPos(c.getX() + FRAGMENT_COLUMN_OFFSET_X, c.getY(), c.getZ());
    }

    public MazeData getMaze(UUID hollowId) {
        return mazes.get(hollowId);
    }

    public void putMaze(UUID hollowId, MazeData maze) {
        mazes.put(hollowId, maze);
        this.markDirty();
    }

    public Integer getFragmentGroundY(UUID hollowId) {
        return fragmentGroundY.get(hollowId);
    }

    public void setFragmentGroundY(UUID hollowId, int y) {
        fragmentGroundY.put(hollowId, y);
        this.markDirty();
    }

    /** Backlog for this Hollow, created on first use. */
    public FragmentLog getFragmentLog(UUID hollowId) {
        return fragmentLogs.computeIfAbsent(hollowId, k -> new FragmentLog());
    }

    /** Backlog for this Hollow, or null if it never had one (does not create). */
    public FragmentLog peekFragmentLog(UUID hollowId) {
        return fragmentLogs.get(hollowId);
    }

    // ------------------------------------------------------------------
    // System 4: player <-> "current Hollow" association
    // ------------------------------------------------------------------

    public void setCurrentHollow(UUID playerId, UUID hollowId) {
        playerCurrentHollow.put(playerId, hollowId);
        this.markDirty();
    }

    public UUID getCurrentHollow(UUID playerId) {
        return playerCurrentHollow.get(playerId);
    }

    public void clearCurrentHollow(UUID playerId) {
        if (playerCurrentHollow.remove(playerId) != null) {
            this.markDirty();
        }
    }

    // ------------------------------------------------------------------
    // NBT
    // ------------------------------------------------------------------

    private static HollowWorldState fromNbt(NbtCompound nbt) {
        HollowWorldState state = new HollowWorldState();

        NbtList list = nbt.getList("ReturnPoints", 10); // 10 = NbtCompound tag id
        for (int i = 0; i < list.size(); i++) {
            NbtCompound entry = list.getCompound(i);
            UUID id = entry.getUuid("Player");
            RegistryKey<World> dim = RegistryKey.of(RegistryKeys.WORLD,
                    new Identifier(entry.getString("Dimension")));
            state.returnPoints.put(id, new ReturnPoint(dim, entry.getDouble("X"), entry.getDouble("Y"), entry.getDouble("Z")));
        }

        NbtList slotList = nbt.getList("HollowSlots", 10);
        for (int i = 0; i < slotList.size(); i++) {
            NbtCompound entry = slotList.getCompound(i);
            state.hollowSlots.put(entry.getUuid("Hollow"), entry.getInt("Slot"));
        }

        NbtList currentHollowList = nbt.getList("PlayerCurrentHollow", 10);
        for (int i = 0; i < currentHollowList.size(); i++) {
            NbtCompound entry = currentHollowList.getCompound(i);
            state.playerCurrentHollow.put(entry.getUuid("Player"), entry.getUuid("Hollow"));
        }

        NbtList fragList = nbt.getList("FragmentLogs", 10);
        for (int i = 0; i < fragList.size(); i++) {
            NbtCompound entry = fragList.getCompound(i);
            state.fragmentLogs.put(entry.getUuid("Hollow"), FragmentLog.fromNbt(entry.getCompound("Log")));
        }

        NbtList groundList = nbt.getList("FragmentGround", 10);
        for (int i = 0; i < groundList.size(); i++) {
            NbtCompound entry = groundList.getCompound(i);
            state.fragmentGroundY.put(entry.getUuid("Hollow"), entry.getInt("Y"));
        }

        NbtList mazeList = nbt.getList("Mazes", 10);
        for (int i = 0; i < mazeList.size(); i++) {
            NbtCompound entry = mazeList.getCompound(i);
            MazeData md = MazeData.fromNbt(entry.getCompound("Data"));
            if (md != null) {
                state.mazes.put(entry.getUuid("Hollow"), md);
            }
        }

        return state;
    }

    @Override
    public NbtCompound writeNbt(NbtCompound nbt) {
        NbtList list = new NbtList();
        for (Map.Entry<UUID, ReturnPoint> e : returnPoints.entrySet()) {
            NbtCompound entry = new NbtCompound();
            entry.putUuid("Player", e.getKey());
            entry.putString("Dimension", e.getValue().dimension().getValue().toString());
            entry.putDouble("X", e.getValue().x());
            entry.putDouble("Y", e.getValue().y());
            entry.putDouble("Z", e.getValue().z());
            list.add(entry);
        }
        nbt.put("ReturnPoints", list);

        NbtList slotList = new NbtList();
        for (Map.Entry<UUID, Integer> e : hollowSlots.entrySet()) {
            NbtCompound entry = new NbtCompound();
            entry.putUuid("Hollow", e.getKey());
            entry.putInt("Slot", e.getValue());
            slotList.add(entry);
        }
        nbt.put("HollowSlots", slotList);

        NbtList currentHollowList = new NbtList();
        for (Map.Entry<UUID, UUID> e : playerCurrentHollow.entrySet()) {
            NbtCompound entry = new NbtCompound();
            entry.putUuid("Player", e.getKey());
            entry.putUuid("Hollow", e.getValue());
            currentHollowList.add(entry);
        }
        nbt.put("PlayerCurrentHollow", currentHollowList);

        NbtList fragList = new NbtList();
        for (Map.Entry<UUID, FragmentLog> e : fragmentLogs.entrySet()) {
            if (!e.getValue().hasPending()) {
                continue;
            }
            NbtCompound entry = new NbtCompound();
            entry.putUuid("Hollow", e.getKey());
            entry.put("Log", e.getValue().toNbt());
            fragList.add(entry);
        }
        nbt.put("FragmentLogs", fragList);

        NbtList groundList = new NbtList();
        for (Map.Entry<UUID, Integer> e : fragmentGroundY.entrySet()) {
            NbtCompound entry = new NbtCompound();
            entry.putUuid("Hollow", e.getKey());
            entry.putInt("Y", e.getValue());
            groundList.add(entry);
        }
        nbt.put("FragmentGround", groundList);

        NbtList mazeList = new NbtList();
        for (Map.Entry<UUID, MazeData> e : mazes.entrySet()) {
            NbtCompound entry = new NbtCompound();
            entry.putUuid("Hollow", e.getKey());
            entry.put("Data", e.getValue().toNbt());
            mazeList.add(entry);
        }
        nbt.put("Mazes", mazeList);

        return nbt;
    }
}
