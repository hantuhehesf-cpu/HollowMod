package com.hollowmod.state;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import net.minecraft.world.PersistentState;
import net.minecraft.world.World;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Confirmed against Minecraft 1.20.1's PersistentStateManager, whose getOrCreate takes
 * (Function<NbtCompound, T> readFunction, Supplier<T> supplier, String id) directly -- the
 * PersistentState.Type<T> record wrapper is a 1.20.2+ change, so do NOT use that pattern here.
 */
public class HollowWorldState extends PersistentState {

    private static final String STATE_ID = "hollowmod_state";

    /** Where to send a player back to once they find the exit portal (or die inside the Hollow). */
    public record ReturnPoint(RegistryKey<World> dimension, double x, double y, double z) {
    }

    private final Map<UUID, ReturnPoint> returnPoints = new HashMap<>();

    public static HollowWorldState get(MinecraftServer server) {
        ServerWorld overworld = server.getOverworld();
        return overworld.getPersistentStateManager().getOrCreate(
                HollowWorldState::fromNbt,
                HollowWorldState::new,
                STATE_ID);
    }

    public void setReturnPosition(UUID playerId, RegistryKey<World> dimension, double x, double y, double z) {
        returnPoints.put(playerId, new ReturnPoint(dimension, x, y, z));
        this.markDirty();
    }

    /** Reads and clears the stored return point in one step (each escape consumes it). */
    public ReturnPoint takeReturnPosition(UUID playerId) {
        ReturnPoint point = returnPoints.remove(playerId);
        if (point != null) {
            this.markDirty();
        }
        return point;
    }

    private static HollowWorldState fromNbt(NbtCompound nbt) {
        HollowWorldState state = new HollowWorldState();
        NbtList list = nbt.getList("ReturnPoints", 10); // 10 = NbtCompound tag id
        for (int i = 0; i < list.size(); i++) {
            NbtCompound entry = list.getCompound(i);
            UUID id = entry.getUuid("Player");
            RegistryKey<World> dim = RegistryKey.of(RegistryKeys.WORLD,
                    new Identifier(entry.getString("Dimension")));
            state.returnPoints.put(id, new ReturnPoint(dim, entry.getDouble("X"), entry.getDouble("Y"), entry.getDouble("Z")));
        }
        return state;
    }

    @Override
    public NbtCompound writeNbt(NbtCompound nbt) {
        NbtList list = new NbtList();
        for (Map.Entry<UUID, ReturnPoint> e : returnPoints.entrySet()) {
            NbtCompound entry = new NbtCompound();
            entry.putUuid("Player", e.getKey());
            entry.putString("Dimension", e.getValue().dimension().getValue().toString());
            entry.putDouble("X", e.getValue().x());
            entry.putDouble("Y", e.getValue().y());
            entry.putDouble("Z", e.getValue().z());
            list.add(entry);
        }
        nbt.put("ReturnPoints", list);
        return nbt;
    }
}
