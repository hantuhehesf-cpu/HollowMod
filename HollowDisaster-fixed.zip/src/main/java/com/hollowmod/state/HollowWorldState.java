package com.hollowmod.state;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtList;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.PersistentState;
import net.minecraft.world.World;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Confirmed against Minecraft 1.20.1's PersistentStateManager, whose getOrCreate takes
 * (Function<NbtCompound, T> readFunction, Supplier<T> supplier, String id) directly -- the
 * PersistentState.Type<T> record wrapper is a 1.20.2+ change, so do NOT use that pattern here.
 *
 * v1.2 (System 4): extended with per-Hollow sub-region slot assignment, and a
 * player -> "which Hollow are they currently inside" association (needed so death/respawn and
 * the exit portal can send the player back to the SAME sub-region they entered, not always a
 * single shared location like in v1.1).
 */
public class HollowWorldState extends PersistentState {

    private static final String STATE_ID = "hollowmod_state";

    /** Where to send a player back to once they find the exit portal (or die inside the Hollow). */
    public record ReturnPoint(RegistryKey<World> dimension, double x, double y, double z) {
    }

    private final Map<UUID, ReturnPoint> returnPoints = new HashMap<>();

    // ---- System 4: sub-region slots ----
    // Grid of slots spaced far apart (10,000 blocks) so each Hollow's sub-region reads as its own
    // separate pocket. 5x5 = 25 slots, well beyond the 10-Hollow population cap for headroom.
    private static final int SLOT_GRID_WIDTH = 5;
    private static final int SLOT_SPACING = 10_000;
    private final Map<UUID, Integer> hollowSlots = new HashMap<>();

    // ---- System 4: which Hollow's sub-region is this player currently inside? ----
    private final Map<UUID, UUID> playerCurrentHollow = new HashMap<>();

    public static HollowWorldState get(MinecraftServer server) {
        ServerWorld overworld = server.getOverworld();
        return overworld.getPersistentStateManager().getOrCreate(
                HollowWorldState::fromNbt,
                HollowWorldState::new,
                STATE_ID);
    }

    public void setReturnPosition(UUID playerId, RegistryKey<World> dimension, double x, double y, double z) {
        returnPoints.put(playerId, new ReturnPoint(dimension, x, y, z));
        this.markDirty();
    }

    /** Reads and clears the stored return point in one step (each escape consumes it). */
    public ReturnPoint takeReturnPosition(UUID playerId) {
        ReturnPoint point = returnPoints.remove(playerId);
        if (point != null) {
            this.markDirty();
        }
        return point;
    }

    // ------------------------------------------------------------------
    // System 4: sub-region slot assignment
    // ------------------------------------------------------------------

    /** Returns this Hollow's already-assigned slot, or claims the lowest free one if it doesn't
     *  have one yet. Stable for the Hollow's lifetime once assigned. */
    public int getOrAssignSlot(UUID hollowId) {
        Integer existing = hollowSlots.get(hollowId);
        if (existing != null) {
            return existing;
        }

        int slot = 0;
        while (hollowSlots.containsValue(slot)) {
            slot++;
        }
        hollowSlots.put(hollowId, slot);
        this.markDirty();
        return slot;
    }

    /** Frees a Hollow's slot so a future Hollow can reuse it -- called when a Hollow collapses,
     *  explodes, or is otherwise removed (see HollowCoreEntity.registerTracking's unload hook). */
    public void freeSlot(UUID hollowId) {
        if (hollowSlots.remove(hollowId) != null) {
            this.markDirty();
        }
    }

    /** Deterministic slot-index -> sub-region center position (Y matches the existing anchor
     *  height convention used elsewhere for HollowDimension spawn platforms). */
    public static BlockPos slotToSubRegionCenter(int slot) {
        int col = slot % SLOT_GRID_WIDTH;
        int row = slot / SLOT_GRID_WIDTH;
        int x = (col - SLOT_GRID_WIDTH / 2) * SLOT_SPACING;
        int z = (row - SLOT_GRID_WIDTH / 2) * SLOT_SPACING;
        return new BlockPos(x, 32, z);
    }

    // ------------------------------------------------------------------
    // System 4: player <-> "current Hollow" association
    // ------------------------------------------------------------------

    public void setCurrentHollow(UUID playerId, UUID hollowId) {
        playerCurrentHollow.put(playerId, hollowId);
        this.markDirty();
    }

    public UUID getCurrentHollow(UUID playerId) {
        return playerCurrentHollow.get(playerId);
    }

    public void clearCurrentHollow(UUID playerId) {
        if (playerCurrentHollow.remove(playerId) != null) {
            this.markDirty();
        }
    }

    // ------------------------------------------------------------------
    // NBT
    // ------------------------------------------------------------------

    private static HollowWorldState fromNbt(NbtCompound nbt) {
        HollowWorldState state = new HollowWorldState();

        NbtList list = nbt.getList("ReturnPoints", 10); // 10 = NbtCompound tag id
        for (int i = 0; i < list.size(); i++) {
            NbtCompound entry = list.getCompound(i);
            UUID id = entry.getUuid("Player");
            RegistryKey<World> dim = RegistryKey.of(RegistryKeys.WORLD,
                    new Identifier(entry.getString("Dimension")));
            state.returnPoints.put(id, new ReturnPoint(dim, entry.getDouble("X"), entry.getDouble("Y"), entry.getDouble("Z")));
        }

        NbtList slotList = nbt.getList("HollowSlots", 10);
        for (int i = 0; i < slotList.size(); i++) {
            NbtCompound entry = slotList.getCompound(i);
            state.hollowSlots.put(entry.getUuid("Hollow"), entry.getInt("Slot"));
        }

        NbtList currentHollowList = nbt.getList("PlayerCurrentHollow", 10);
        for (int i = 0; i < currentHollowList.size(); i++) {
            NbtCompound entry = currentHollowList.getCompound(i);
            state.playerCurrentHollow.put(entry.getUuid("Player"), entry.getUuid("Hollow"));
        }

        return state;
    }

    @Override
    public NbtCompound writeNbt(NbtCompound nbt) {
        NbtList list = new NbtList();
        for (Map.Entry<UUID, ReturnPoint> e : returnPoints.entrySet()) {
            NbtCompound entry = new NbtCompound();
            entry.putUuid("Player", e.getKey());
            entry.putString("Dimension", e.getValue().dimension().getValue().toString());
            entry.putDouble("X", e.getValue().x());
            entry.putDouble("Y", e.getValue().y());
            entry.putDouble("Z", e.getValue().z());
            list.add(entry);
        }
        nbt.put("ReturnPoints", list);

        NbtList slotList = new NbtList();
        for (Map.Entry<UUID, Integer> e : hollowSlots.entrySet()) {
            NbtCompound entry = new NbtCompound();
            entry.putUuid("Hollow", e.getKey());
            entry.putInt("Slot", e.getValue());
            slotList.add(entry);
        }
        nbt.put("HollowSlots", slotList);

        NbtList currentHollowList = new NbtList();
        for (Map.Entry<UUID, UUID> e : playerCurrentHollow.entrySet()) {
            NbtCompound entry = new NbtCompound();
            entry.putUuid("Player", e.getKey());
            entry.putUuid("Hollow", e.getValue());
            currentHollowList.add(entry);
        }
        nbt.put("PlayerCurrentHollow", currentHollowList);

        return nbt;
    }
}
