package com.hollowmod.state;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtHelper;
import net.minecraft.nbt.NbtList;
import net.minecraft.registry.Registries;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * System 5 backlog: blocks a Hollow ate while NOBODY was inside its sub-region (so they could
 * not be placed right away). They wait here, packed into one long per block, and are replayed
 * (time-sliced) as soon as a player enters that sub-region. Blocks that are placed immediately
 * (someone is inside) never go through this log, so it only ever holds the real backlog.
 *
 * Entry layout (one long): bits 0-8 = relX+256, 9-17 = relY+256, 18-26 = relZ+256,
 * 27-38 = palette index. Relative offsets are limited to +-255 (Hollow radius cap is 128).
 */
public final class FragmentLog {

    /** Hard cap on backlog size per Hollow (~1.2 MB of NBT at the cap). Further blocks are dropped. */
    public static final int MAX_ENTRIES = 150_000;

    private static final int OFFSET = 256;
    private static final int MAX_PALETTE = 4095;

    private final List<BlockState> palette = new ArrayList<>();
    private final Map<BlockState, Integer> paletteIndex = new HashMap<>();
    private long[] entries = new long[256];
    private int size = 0;
    private int placed = 0;

    public boolean add(BlockPos relative, BlockState state) {
        if (size >= MAX_ENTRIES) {
            return false;
        }
        int x = relative.getX() + OFFSET;
        int y = relative.getY() + OFFSET;
        int z = relative.getZ() + OFFSET;
        if (((x | y | z) & ~511) != 0) {
            return false;
        }
        Integer idx = paletteIndex.get(state);
        if (idx == null) {
            if (palette.size() > MAX_PALETTE) {
                return false;
            }
            idx = palette.size();
            palette.add(state);
            paletteIndex.put(state, idx);
        }
        if (size == entries.length) {
            entries = Arrays.copyOf(entries, Math.min(MAX_ENTRIES, entries.length * 2));
        }
        entries[size++] = (long) x | ((long) y << 9) | ((long) z << 18) | ((long) idx << 27);
        return true;
    }

    public boolean hasPending() {
        return placed < size;
    }

    /** Returns the next unplaced entry and advances the cursor. Call only if hasPending(). */
    public long next() {
        return entries[placed++];
    }

    public static BlockPos relativePos(long entry) {
        int x = (int) (entry & 511L) - OFFSET;
        int y = (int) ((entry >> 9) & 511L) - OFFSET;
        int z = (int) ((entry >> 18) & 511L) - OFFSET;
        return new BlockPos(x, y, z);
    }

    public BlockState stateOf(long entry) {
        return palette.get((int) ((entry >> 27) & 4095L));
    }

    /** Everything has been placed: drop the arrays so the log costs nothing while idle. */
    public void reset() {
        size = 0;
        placed = 0;
        entries = new long[256];
        palette.clear();
        paletteIndex.clear();
    }

    // ---- NBT (only the still-pending entries are saved) ----

    public NbtCompound toNbt() {
        NbtCompound nbt = new NbtCompound();
        NbtList pal = new NbtList();
        for (BlockState s : palette) {
            pal.add(NbtHelper.fromBlockState(s));
        }
        nbt.put("Palette", pal);
        nbt.putLongArray("Entries", Arrays.copyOfRange(entries, placed, size));
        return nbt;
    }

    public static FragmentLog fromNbt(NbtCompound nbt) {
        FragmentLog log = new FragmentLog();
        var lookup = Registries.BLOCK.getReadOnlyWrapper();
        NbtList pal = nbt.getList("Palette", 10); // 10 = NbtCompound tag id
        for (int i = 0; i < pal.size(); i++) {
            BlockState s = NbtHelper.toBlockState(lookup, pal.getCompound(i));
            log.palette.add(s);
            log.paletteIndex.put(s, i);
        }
        long[] arr = nbt.getLongArray("Entries");
        log.entries = Arrays.copyOf(arr, Math.max(256, arr.length));
        log.size = arr.length;
        log.placed = 0;
        return log;
    }
}
