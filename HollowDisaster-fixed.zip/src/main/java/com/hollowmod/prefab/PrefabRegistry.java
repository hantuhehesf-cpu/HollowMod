package com.hollowmod.prefab;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.hollowmod.HollowMod;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;
import java.util.stream.Stream;

/**
 * Knows every prefab by id. Loaded in this order (a later one with the same id replaces an earlier one):
 *  1. built-in presets (PresetPrefabs)
 *  2. the six hand-built buildings bundled in the mod (building_1 .. building_6)
 *  3. your own files in  <game folder>/config/hollowmod/prefabs/   (.schem and .nbt)
 * Optional next to a file: name.json with {"tags":["street"],"weight":3,"connections":"NS","ground":true}
 */
public final class PrefabRegistry {

    private static final Map<String, Prefab> PREFABS = new TreeMap<>();

    public static Path folder() {
        return FabricLoader.getInstance().getConfigDir().resolve("hollowmod").resolve("prefabs");
    }

    /** (Re)loads everything. Returns how many prefabs are available. */
    public static synchronized int reload() {
        PREFABS.clear();

        for (Prefab p : PresetPrefabs.all()) {
            PREFABS.put(p.id, p);
        }

        for (int i = 1; i <= 6; i++) {
            String id = "building_" + i;
            try {
                Prefab p = SchematicLoader.loadResourceStructure(id, "/data/hollowmod/structures/" + id + ".nbt");
                p.tags.add("building");
                p.source = "bundled structure";
                PREFABS.put(id, p);
            } catch (Exception e) {
                HollowMod.LOGGER.warn("[HollowMod] Could not load bundled {}: {}", id, e.toString());
            }
        }

        Path dir = folder();
        try {
            Files.createDirectories(dir);
            writeReadme(dir);
            try (Stream<Path> files = Files.list(dir)) {
                List<Path> sorted = new ArrayList<>();
                files.sorted().forEach(sorted::add);
                for (Path f : sorted) {
                    loadUserFile(f);
                }
            }
        } catch (IOException e) {
            HollowMod.LOGGER.warn("[HollowMod] Could not read the prefab folder {}: {}", dir, e.toString());
        }
        return PREFABS.size();
    }

    private static void loadUserFile(Path file) {
        String name = file.getFileName().toString();
        String lower = name.toLowerCase(Locale.ROOT);
        if (!lower.endsWith(".schem") && !lower.endsWith(".nbt")) {
            return;
        }
        try {
            Prefab p = SchematicLoader.loadFile(file);
            p.tags.add("user");
            applyMetadata(p, file.resolveSibling(name.substring(0, name.lastIndexOf('.')) + ".json"));
            PREFABS.put(p.id, p);
            HollowMod.LOGGER.info("[HollowMod] Loaded prefab '{}' ({}x{}x{}) from {}", p.id, p.sizeX, p.sizeY, p.sizeZ, name);
        } catch (Exception e) {
            HollowMod.LOGGER.warn("[HollowMod] Could not load prefab file {}: {}", name, e.toString());
        }
    }

    private static void applyMetadata(Prefab p, Path json) {
        if (!Files.exists(json)) {
            return;
        }
        try {
            JsonObject o = JsonParser.parseString(Files.readString(json)).getAsJsonObject();
            if (o.has("tags")) {
                for (JsonElement e : o.getAsJsonArray("tags")) {
                    p.tags.add(e.getAsString());
                }
            }
            if (o.has("weight")) {
                p.weight = Math.max(1, o.get("weight").getAsInt());
            }
            if (o.has("connections")) {
                p.connections = parseConnections(o.get("connections").getAsString());
            }
            if (o.has("ground")) {
                p.groundLayer = o.get("ground").getAsBoolean();
            }
        } catch (Exception e) {
            HollowMod.LOGGER.warn("[HollowMod] Bad metadata file {}: {}", json.getFileName(), e.toString());
        }
    }

    private static int parseConnections(String letters) {
        int c = 0;
        for (char ch : letters.toUpperCase(Locale.ROOT).toCharArray()) {
            switch (ch) {
                case 'N' -> c |= Prefab.NORTH;
                case 'E' -> c |= Prefab.EAST;
                case 'S' -> c |= Prefab.SOUTH;
                case 'W' -> c |= Prefab.WEST;
                default -> {
                }
            }
        }
        return c;
    }

    private static void writeReadme(Path dir) throws IOException {
        Path readme = dir.resolve("README.txt");
        if (Files.exists(readme)) {
            return;
        }
        Files.writeString(readme, """
                HOLLOW MOD PREFAB FOLDER
                ------------------------
                Put your own city pieces here, then run  /hollow prefab reload  in game.

                Supported files:
                  .schem  = WorldEdit schematic (WorldEdit does NOT need to be installed in this mod)
                  .nbt    = vanilla Structure Block file

                How to make a .schem with WorldEdit:
                  1. Build your piece. Stand at its lowest corner.   //pos1  and  //pos2  to select it.
                  2. //copy      then      //schem save my_piece
                  3. Copy config/worldedit/schematics/my_piece.schem into this folder.

                The file name (without .schem) is the prefab id.  Try:  /hollow prefab place my_piece

                Optional: my_piece.json next to the file:
                  {"tags":["street"], "weight":3, "connections":"NS", "ground":true}
                  connections = which sides have a road (N, E, S, W).
                  ground = true if the bottom layer of your piece is the ground itself.
                """);
    }

    public static synchronized Prefab get(String id) {
        return id == null ? null : PREFABS.get(id.toLowerCase(Locale.ROOT));
    }

    public static synchronized Collection<Prefab> all() {
        return new ArrayList<>(PREFABS.values());
    }

    public static synchronized List<String> ids() {
        return new ArrayList<>(PREFABS.keySet());
    }

    private PrefabRegistry() {
    }
}
