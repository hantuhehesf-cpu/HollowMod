package com.hollowmod.prefab;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.text.Text;
import net.minecraft.util.BlockMirror;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;
import java.util.UUID;

/**
 * DEMO of how System 6 will feel with city pieces.
 *  /hollow prefab demo       builds a 3x3 grid of district pieces in front of you
 *  /hollow prefab shiftdemo  warns, then swaps two districts and rotates a third one.
 *                            If you stand on the rotating district, you are turned with it.
 * The grid lives only in memory (it is a demo). The real shifting engine will come later.
 */
public final class DistrictDemo {

    private static final int D = PrefabSystem.DISTRICT;
    private static final Random RNG = new Random();

    // rows go north -> south (z), columns go west -> east (x)
    private static final String[][] IDS = {
            {"preset_leaning_tower", "preset_office_tower", "preset_subway_entrance"},
            {"preset_overpass", "preset_crossroad", "preset_billboard_gantry"},
            {"preset_rubble", "preset_shop_row", "preset_leaning_tower"}
    };
    private static final BlockRotation[][] ROTS = {
            {BlockRotation.NONE, BlockRotation.NONE, BlockRotation.NONE},
            {BlockRotation.NONE, BlockRotation.NONE, BlockRotation.NONE},
            {BlockRotation.NONE, BlockRotation.CLOCKWISE_180, BlockRotation.CLOCKWISE_90}
    };

    private static final class Slot {
        String id;
        BlockRotation rot;
        BlockMirror mir = BlockMirror.NONE;

        Slot(String id, BlockRotation rot) {
            this.id = id;
            this.rot = rot;
        }
    }

    private static final class Grid {
        final ServerWorld world;
        final int x0;
        final int y0;
        final int z0;
        final Slot[][] slots = new Slot[3][3];

        Grid(ServerWorld world, int x0, int y0, int z0) {
            this.world = world;
            this.x0 = x0;
            this.y0 = y0;
            this.z0 = z0;
        }

        Slot slot(int index) {
            return slots[index / 3][index % 3];
        }

        void setSlot(int index, Slot s) {
            slots[index / 3][index % 3] = s;
        }

        int minX(int index) {
            return x0 + (index % 3) * D;
        }

        int minZ(int index) {
            return z0 + (index / 3) * D;
        }

        double centerX() {
            return x0 + D * 1.5;
        }

        double centerZ() {
            return z0 + D * 1.5;
        }
    }

    private static Grid grid;
    private static Sequence sequence;

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (sequence != null) {
                sequence.tick();
            }
        });
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> {
            grid = null;
            sequence = null;
        });
    }

    /** Stops a running shift (used by /hollow prefab cancel). */
    public static void reset() {
        sequence = null;
    }

    // ------------------------------------------------------------------ /hollow prefab demo

    public static int build(ServerCommandSource source) throws CommandSyntaxException {
        ServerPlayerEntity player = source.getPlayerOrThrow();
        if (sequence != null) {
            source.sendError(Text.literal("A shift is still running. Wait for it or use /hollow prefab cancel."));
            return 0;
        }
        for (String[] row : IDS) {
            for (String id : row) {
                if (PrefabRegistry.get(id) == null) {
                    source.sendError(Text.literal("Preset '" + id + "' is missing. Check the game log for preset errors."));
                    return 0;
                }
            }
        }
        ServerWorld world = source.getWorld();
        Direction dir = player.getHorizontalFacing();
        double cx = player.getX() + dir.getOffsetX() * (D * 1.5 + 16);
        double cz = player.getZ() + dir.getOffsetZ() * (D * 1.5 + 16);
        int x0 = MathHelper.floor(cx) - D * 3 / 2;
        int z0 = MathHelper.floor(cz) - D * 3 / 2;
        int y0 = player.getBlockPos().getY() - 1; // layer 0 of every piece replaces the ground surface

        Grid g = new Grid(world, x0, y0, z0);
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 3; col++) {
                g.slots[row][col] = new Slot(IDS[row][col], ROTS[row][col]);
            }
        }
        grid = g;
        PrefabPlacer.cancelAll();
        for (int i = 0; i < 9; i++) {
            placeSlot(g, i, false, null);
        }
        source.sendFeedback(() -> Text.literal("Building a 3x3 demo city ahead of you (about 15 seconds). "
                + "Then use /hollow prefab shiftdemo."), false);
        return 1;
    }

    private static void placeSlot(Grid g, int index, boolean effects, Runnable done) {
        Slot s = g.slot(index);
        Prefab p = PrefabRegistry.get(s.id);
        if (p == null) {
            if (done != null) {
                done.run();
            }
            return;
        }
        long seed = ((long) g.minX(index) * 31L) ^ g.minZ(index) ^ RNG.nextLong();
        PrefabPlacer.enqueue(g.world, p, new BlockPos(g.minX(index), g.y0, g.minZ(index)),
                s.rot, s.mir, true, 1.0f, seed, effects, done);
    }

    // ------------------------------------------------------------------ /hollow prefab shiftdemo

    public static int shift(ServerCommandSource source) throws CommandSyntaxException {
        ServerPlayerEntity player = source.getPlayerOrThrow();
        if (grid == null) {
            source.sendError(Text.literal("Build the demo first: /hollow prefab demo"));
            return 0;
        }
        if (grid.world != source.getWorld()) {
            source.sendError(Text.literal("The demo city is in another dimension."));
            return 0;
        }
        if (sequence != null) {
            source.sendError(Text.literal("A shift is already running."));
            return 0;
        }
        if (PrefabPlacer.queueSize() > 0) {
            source.sendError(Text.literal("The city is still being built. Wait until it is finished."));
            return 0;
        }

        // The district you stand on is the one that rotates (so you get carried). Otherwise a random one.
        int c = slotIndexAt(grid, player);
        if (c < 0) {
            c = RNG.nextInt(9);
        }
        List<Integer> others = new ArrayList<>();
        for (int i = 0; i < 9; i++) {
            if (i != c) {
                others.add(i);
            }
        }
        Collections.shuffle(others, RNG);
        int a = others.get(0);
        int b = -1;
        for (int i = 1; i < others.size(); i++) {
            if (!grid.slot(others.get(i)).id.equals(grid.slot(a).id)) {
                b = others.get(i);
                break;
            }
        }
        if (b < 0) {
            b = others.get(1);
        }
        sequence = new Sequence(grid, a, b, c);
        source.sendFeedback(() -> Text.literal("Space distortion incoming..."), false);
        return 1;
    }

    private static boolean inSlot(Grid g, ServerPlayerEntity p, int index) {
        double x = p.getX();
        double z = p.getZ();
        double y = p.getY();
        return x >= g.minX(index) && x < g.minX(index) + D
                && z >= g.minZ(index) && z < g.minZ(index) + D
                && y >= g.y0 - 3 && y <= g.y0 + PrefabSystem.DISTRICT_HEIGHT + 3;
    }

    private static int slotIndexAt(Grid g, ServerPlayerEntity p) {
        if (p.getWorld() != g.world) {
            return -1;
        }
        for (int i = 0; i < 9; i++) {
            if (inSlot(g, p, i)) {
                return i;
            }
        }
        return -1;
    }

    // ------------------------------------------------------------------ the shift sequence

    private static final class Sequence {
        final Grid g;
        final int a;
        final int b;
        final int c;
        int phase = 0;             // 0 warn, 1 swap, 2 rotate
        int ticksLeft = PrefabSystem.WARN_TICKS;
        int pending = 0;
        final List<UUID> riders = new ArrayList<>();

        Sequence(Grid g, int a, int b, int c) {
            this.g = g;
            this.a = a;
            this.b = b;
            this.c = c;
        }

        void tick() {
            switch (phase) {
                case 0 -> warn();
                case 1 -> {
                    if (pending == 0) {
                        startRotate();
                    }
                }
                case 2 -> {
                    if (pending == 0) {
                        finish();
                    }
                }
                default -> sequence = null;
            }
        }

        private BlockPos centerPos() {
            return new BlockPos(MathHelper.floor(g.centerX()), g.y0 + 2, MathHelper.floor(g.centerZ()));
        }

        private void warn() {
            ServerWorld w = g.world;
            ticksLeft--;
            int elapsed = PrefabSystem.WARN_TICKS - ticksLeft;
            if (elapsed == 1) {
                for (ServerPlayerEntity p : w.getPlayers()) {
                    if (p.squaredDistanceTo(g.centerX(), g.y0, g.centerZ()) < 130.0 * 130.0) {
                        p.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 160, 0, false, false, false));
                        p.addStatusEffect(new StatusEffectInstance(StatusEffects.RESISTANCE, 400, 4, false, false, false));
                        p.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOW_FALLING, 400, 0, false, false, false));
                        p.sendMessage(Text.literal("The space is bending..."), true);
                    }
                }
            }
            if (elapsed % 20 == 1) {
                w.playSound(null, centerPos(), SoundEvents.ENTITY_WARDEN_HEARTBEAT, SoundCategory.AMBIENT, 8.0f, 0.7f);
            }
            if (elapsed % 4 == 0) {
                edgeParticles(w, a);
                edgeParticles(w, b);
                edgeParticles(w, c);
            }
            if (ticksLeft <= 0) {
                startSwap();
            }
        }

        private void edgeParticles(ServerWorld w, int index) {
            int x0 = g.minX(index);
            int z0 = g.minZ(index);
            double y = g.y0 + 1.5;
            for (int i = 0; i <= D; i += 4) {
                w.spawnParticles(ParticleTypes.END_ROD, x0 + i, y + RNG.nextInt(3), z0, 1, 0, 0.4, 0, 0.01);
                w.spawnParticles(ParticleTypes.END_ROD, x0 + i, y + RNG.nextInt(3), z0 + D, 1, 0, 0.4, 0, 0.01);
                w.spawnParticles(ParticleTypes.END_ROD, x0, y + RNG.nextInt(3), z0 + i, 1, 0, 0.4, 0, 0.01);
                w.spawnParticles(ParticleTypes.END_ROD, x0 + D, y + RNG.nextInt(3), z0 + i, 1, 0, 0.4, 0, 0.01);
            }
            for (int h = 0; h < 40; h += 5) {
                w.spawnParticles(ParticleTypes.END_ROD, x0, g.y0 + h, z0, 1, 0, 0, 0, 0.0);
                w.spawnParticles(ParticleTypes.END_ROD, x0 + D, g.y0 + h, z0, 1, 0, 0, 0, 0.0);
                w.spawnParticles(ParticleTypes.END_ROD, x0, g.y0 + h, z0 + D, 1, 0, 0, 0, 0.0);
                w.spawnParticles(ParticleTypes.END_ROD, x0 + D, g.y0 + h, z0 + D, 1, 0, 0, 0, 0.0);
            }
        }

        private void startSwap() {
            g.world.playSound(null, centerPos(), SoundEvents.BLOCK_RESPAWN_ANCHOR_DEPLETE, SoundCategory.AMBIENT, 6.0f, 0.5f);
            Slot sa = g.slot(a);
            Slot sb = g.slot(b);
            g.setSlot(a, sb);
            g.setSlot(b, sa);
            pending = 2;
            placeSlot(g, a, true, () -> pending--);
            placeSlot(g, b, true, () -> pending--);
            phase = 1;
        }

        private void startRotate() {
            Slot s = g.slot(c);
            s.rot = s.rot.rotate(BlockRotation.CLOCKWISE_90);
            riders.clear();
            for (ServerPlayerEntity p : g.world.getPlayers()) {
                if (inSlot(g, p, c)) {
                    riders.add(p.getUuid());
                }
            }
            pending = 1;
            placeSlot(g, c, true, () -> {
                carryRiders();
                pending--;
            });
            phase = 2;
        }

        /** Turns everyone who was standing on the rotated district together with it. */
        private void carryRiders() {
            double cx = g.minX(c) + D / 2.0;
            double cz = g.minZ(c) + D / 2.0;
            for (UUID id : riders) {
                ServerPlayerEntity p = g.world.getServer().getPlayerManager().getPlayer(id);
                if (p == null || p.getWorld() != g.world || !inSlot(g, p, c)) {
                    continue;
                }
                double rx = p.getX() - cx;
                double rz = p.getZ() - cz;
                // clockwise 90 degrees: (rx, rz) -> (-rz, rx), same as the blocks
                p.networkHandler.requestTeleport(cx - rz, p.getY(), cz + rx, p.getYaw() + 90.0f, p.getPitch());
            }
        }

        private void finish() {
            g.world.playSound(null, centerPos(), SoundEvents.BLOCK_BEACON_DEACTIVATE, SoundCategory.AMBIENT, 6.0f, 0.6f);
            for (ServerPlayerEntity p : g.world.getPlayers()) {
                if (p.squaredDistanceTo(g.centerX(), g.y0, g.centerZ()) < 130.0 * 130.0) {
                    p.sendMessage(Text.literal("The space settles."), true);
                }
            }
            sequence = null;
        }
    }

    private DistrictDemo() {
    }
}
