package com.hollowmod.prefab;

import com.hollowmod.HollowMod;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.function.Supplier;

/**
 * Built-in DEMO prefabs (ruined ZZZ-style city districts). Each one is 48 x 44 x 48 blocks and
 * has its own ground layer (layer 0 replaces the ground surface). Roads are 12 wide and always sit in the
 * middle of a side, so pieces line up when rotated or swapped:
 *   north road: x 18..29, z 0..23     south road: x 18..29, z 24..47
 *   west road : z 18..29, x 0..23     east road : z 18..29, x 24..47
 * They are built in code so you can see how the system works before making your own .schem files.
 */
public final class PresetPrefabs {

    private static final int D = PrefabSystem.DISTRICT;
    private static final int H = PrefabSystem.DISTRICT_HEIGHT;

    private static final BlockState AIR = Blocks.AIR.getDefaultState();
    private static final BlockState SIDEWALK = Blocks.LIGHT_GRAY_CONCRETE.getDefaultState();
    private static final BlockState ROAD = Blocks.GRAY_CONCRETE.getDefaultState();
    private static final BlockState WHITE = Blocks.WHITE_CONCRETE.getDefaultState();
    private static final BlockState YELLOW = Blocks.YELLOW_CONCRETE.getDefaultState();
    private static final BlockState WALL = Blocks.POLISHED_ANDESITE.getDefaultState();
    private static final BlockState WALL_DARK = Blocks.GRAY_CONCRETE.getDefaultState();
    private static final BlockState GLASS = Blocks.LIGHT_BLUE_STAINED_GLASS.getDefaultState();
    private static final BlockState LAMP = Blocks.SEA_LANTERN.getDefaultState();
    private static final BlockState BARS = Blocks.IRON_BARS.getDefaultState();
    private static final BlockState BLACK = Blocks.BLACK_CONCRETE.getDefaultState();

    private static final BlockState[] RUBBLE = {
            Blocks.COBBLESTONE.getDefaultState(),
            Blocks.LIGHT_GRAY_CONCRETE.getDefaultState(),
            Blocks.GRAY_CONCRETE.getDefaultState(),
            Blocks.ANDESITE.getDefaultState(),
            Blocks.COBBLED_DEEPSLATE.getDefaultState()
    };

    /** Builds every preset. A preset that fails is skipped (logged) so it can never crash the game. */
    public static List<Prefab> all() {
        List<Prefab> list = new ArrayList<>();
        add(list, "preset_crossroad", PresetPrefabs::crossroad);
        add(list, "preset_office_tower", PresetPrefabs::officeTower);
        add(list, "preset_shop_row", PresetPrefabs::shopRow);
        add(list, "preset_overpass", PresetPrefabs::overpass);
        add(list, "preset_rubble", PresetPrefabs::rubbleField);
        add(list, "preset_subway_entrance", PresetPrefabs::subwayEntrance);
        add(list, "preset_billboard_gantry", PresetPrefabs::billboardGantry);
        add(list, "preset_leaning_tower", PresetPrefabs::leaningTower);
        return list;
    }

    private static void add(List<Prefab> list, String id, Supplier<Prefab> maker) {
        try {
            list.add(maker.get());
        } catch (Exception e) {
            HollowMod.LOGGER.error("[HollowMod] Could not build preset " + id, e);
        }
    }

    // ------------------------------------------------------------------ helpers

    private static Prefab.Builder district(String id) {
        return new Prefab.Builder(id, D, H, D);
    }

    private static Prefab finish(Prefab.Builder b, int connections, String... tags) {
        Prefab p = b.build();
        p.connections = connections;
        p.groundLayer = true;
        p.source = "built-in preset";
        p.tags.add("district");
        for (String t : tags) {
            p.tags.add(t);
        }
        return p;
    }

    /** Layer 0: sidewalk everywhere, 12-wide roads on the connected sides, dashed yellow center lines. */
    private static void ground(Prefab.Builder b, int conn) {
        b.fill(0, 0, 0, D - 1, 0, D - 1, SIDEWALK);
        if (conn == 0) {
            return;
        }
        if ((conn & Prefab.NORTH) != 0) b.fill(18, 0, 0, 29, 0, 23, ROAD);
        if ((conn & Prefab.SOUTH) != 0) b.fill(18, 0, 24, 29, 0, 47, ROAD);
        if ((conn & Prefab.WEST) != 0) b.fill(0, 0, 18, 23, 0, 29, ROAD);
        if ((conn & Prefab.EAST) != 0) b.fill(24, 0, 18, 47, 0, 29, ROAD);
        b.fill(18, 0, 18, 29, 0, 29, ROAD);
        for (int i = 0; i < D; i++) {
            if (i % 4 >= 2) {
                continue;
            }
            if ((conn & Prefab.NORTH) != 0 && i < 18) b.fill(23, 0, i, 24, 0, i, YELLOW);
            if ((conn & Prefab.SOUTH) != 0 && i > 29) b.fill(23, 0, i, 24, 0, i, YELLOW);
            if ((conn & Prefab.WEST) != 0 && i < 18) b.fill(i, 0, 23, i, 0, 24, YELLOW);
            if ((conn & Prefab.EAST) != 0 && i > 29) b.fill(i, 0, 23, i, 0, 24, YELLOW);
        }
    }

    private static void lampPost(Prefab.Builder b, int x, int z) {
        b.fill(x, 1, z, x, 7, z, BARS);
        b.set(x, 8, z, LAMP);
    }

    private static void trafficLight(Prefab.Builder b, int x, int z) {
        b.fill(x, 1, z, x, 9, z, BARS);
        b.fill(x, 10, z, x, 12, z, BLACK);
        b.set(x, 12, z, Blocks.RED_CONCRETE.getDefaultState());
        b.set(x, 11, z, Blocks.OCHRE_FROGLIGHT.getDefaultState());
        b.set(x, 10, z, Blocks.VERDANT_FROGLIGHT.getDefaultState());
        b.set(x, 13, z, WALL_DARK);
    }

    private static void car(Prefab.Builder b, int x, int z) {
        BlockState body = Blocks.BLUE_CONCRETE.getDefaultState();
        b.fill(x, 1, z, x + 4, 1, z + 2, body);
        b.fill(x + 1, 2, z, x + 3, 2, z + 2, GLASS);
        b.fill(x + 1, 3, z, x + 3, 3, z + 2, body);
        b.set(x + 1, 4, z + 1, Blocks.RED_CONCRETE.getDefaultState());
        b.set(x + 3, 4, z + 1, Blocks.LIGHT_BLUE_CONCRETE.getDefaultState());
    }

    private static BlockState pick(Random rng, BlockState[] options) {
        return options[rng.nextInt(options.length)];
    }

    /** A heap of broken concrete: tall in the middle, low at the edge. */
    private static void rubblePile(Prefab.Builder b, Random rng, int cx, int cz, int r, int h) {
        for (int x = cx - r; x <= cx + r; x++) {
            for (int z = cz - r; z <= cz + r; z++) {
                double d = Math.hypot(x - cx, z - cz);
                if (d > r) {
                    continue;
                }
                int height = (int) Math.round(h * (1.0 - d / r) * (0.5 + rng.nextDouble() * 0.8));
                for (int y = 1; y <= height; y++) {
                    b.set(x, y, z, pick(rng, RUBBLE));
                }
            }
        }
    }

    // ------------------------------------------------------------------ the 8 presets

    /** Four-way junction with crosswalks, traffic lights, street lamps and a wrecked car. Roads: N E S W. */
    private static Prefab crossroad() {
        Prefab.Builder b = district("preset_crossroad");
        ground(b, 15);
        for (int i = 18; i <= 29; i += 2) {
            b.fill(i, 0, 14, i, 0, 16, WHITE);
            b.fill(i, 0, 31, i, 0, 33, WHITE);
            b.fill(14, 0, i, 16, 0, i, WHITE);
            b.fill(31, 0, i, 33, 0, i, WHITE);
        }
        trafficLight(b, 16, 16);
        trafficLight(b, 31, 16);
        trafficLight(b, 16, 31);
        trafficLight(b, 31, 31);
        lampPost(b, 10, 10);
        lampPost(b, 37, 10);
        lampPost(b, 10, 37);
        lampPost(b, 37, 37);
        car(b, 20, 20);
        return finish(b, 15, "street", "junction");
    }

    /** Tall office tower with window bands and a ruined top. Road: S (rotate it to point the road elsewhere). */
    private static Prefab officeTower() {
        Prefab.Builder b = district("preset_office_tower");
        Random rng = new Random(1001);
        ground(b, Prefab.SOUTH);
        int x1 = 8;
        int x2 = 39;
        int z1 = 3;
        int z2 = 20;
        int top = 36;
        b.shell(x1, 1, z1, x2, top, z2, WALL);
        for (int y = 4; y < top; y += 4) {
            b.fill(x1 + 1, y, z1 + 1, x2 - 1, y, z2 - 1, SIDEWALK);
        }
        for (int y = 2; y < top - 1; y++) {
            if (y % 4 != 2 && y % 4 != 3) {
                continue;
            }
            for (int x = x1 + 2; x <= x2 - 2; x++) {
                if (x % 3 != 0) {
                    b.set(x, y, z1, GLASS);
                    b.set(x, y, z2, GLASS);
                }
            }
            for (int z = z1 + 2; z <= z2 - 2; z++) {
                if (z % 3 != 0) {
                    b.set(x1, y, z, GLASS);
                    b.set(x2, y, z, GLASS);
                }
            }
        }
        for (int y = 3; y < top; y += 4) {
            for (int x = 14; x <= 34; x += 10) {
                b.set(x, y, 12, LAMP);
            }
        }
        b.fill(21, 1, z2, 26, 4, z2, AIR); // lobby entrance
        for (int y = 22; y <= top; y++) {  // the top is eaten away, more on the west side
            double p = (y - 21) / 18.0;
            for (int x = x1; x <= x2; x++) {
                for (int z = z1; z <= z2; z++) {
                    if (!b.isAir(x, y, z) && rng.nextDouble() < p * (1.0 - (x - x1) / 40.0)) {
                        b.set(x, y, z, AIR);
                    }
                }
            }
        }
        b.fill(36, top + 1, 10, 36, top + 7, 10, BARS); // antenna
        rubblePile(b, rng, 10, 25, 4, 3);
        lampPost(b, 16, 27);
        lampPost(b, 31, 27);
        return finish(b, Prefab.SOUTH, "building", "tall");
    }

    /** Row of three broken shops with awnings and signs. Road: S. */
    private static Prefab shopRow() {
        Prefab.Builder b = district("preset_shop_row");
        Random rng = new Random(2002);
        ground(b, Prefab.SOUTH);
        BlockState[] awnings = {
                Blocks.RED_CONCRETE.getDefaultState(),
                Blocks.YELLOW_CONCRETE.getDefaultState(),
                Blocks.LIGHT_BLUE_CONCRETE.getDefaultState()
        };
        for (int i = 0; i < 3; i++) {
            int x0 = 1 + i * 15;
            int x1 = x0 + 13;
            b.shell(x0, 1, 8, x1, 7, 21, i == 1 ? WALL_DARK : WALL);
            b.fill(x0 + 2, 2, 21, x1 - 2, 4, 21, GLASS);
            b.fill(x0 + 6, 1, 21, x0 + 7, 3, 21, AIR);               // door
            b.fill(x0 + 3, 6, 21, x1 - 3, 6, 21, YELLOW);            // sign band
            b.fill(x0 + 1, 5, 22, x1 - 1, 5, 23, awnings[i]);        // awning
            b.set(x0 + 6, 6, 14, LAMP);
            b.set(x0 + 7, 6, 14, LAMP);
            b.damage(x0, 5, 8, x1, 7, 21, 0.12, rng);
            b.damage(x0 + 2, 2, 21, x1 - 2, 4, 21, 0.3, rng);
            b.damage(x0 + 1, 5, 22, x1 - 1, 5, 23, 0.3, rng);
        }
        rubblePile(b, rng, 40, 27, 4, 3);
        lampPost(b, 14, 27);
        return finish(b, Prefab.SOUTH, "building", "shops");
    }

    /** Elevated road crossing over a street, with a collapsed section. Roads on the ground: E W. */
    private static Prefab overpass() {
        Prefab.Builder b = district("preset_overpass");
        Random rng = new Random(3003);
        ground(b, Prefab.EAST | Prefab.WEST);
        b.fill(19, 9, 0, 28, 10, 47, ROAD);
        for (int z = 0; z < D; z++) {
            if (z % 4 < 2) {
                b.fill(23, 10, z, 24, 10, z, YELLOW);
            }
        }
        b.fill(19, 11, 0, 19, 11, 47, WALL);
        b.fill(28, 11, 0, 28, 11, 47, WALL);
        for (int z = 2; z < D - 1; z += 8) {
            b.fill(19, 12, z, 19, 14, z, BARS);
            b.set(19, 15, z, LAMP);
            b.fill(28, 12, z, 28, 14, z, BARS);
            b.set(28, 15, z, LAMP);
        }
        for (int z : new int[]{3, 14, 33, 44}) {
            for (int x : new int[]{19, 27}) {
                b.fill(x, 1, z, x + 1, 8, z + 1, WALL);
            }
        }
        b.damage(19, 9, 16, 28, 10, 30, 0.25, rng);
        b.fill(19, 9, 20, 28, 15, 26, AIR); // collapsed section
        rubblePile(b, rng, 23, 23, 6, 4);
        return finish(b, Prefab.EAST | Prefab.WEST, "street", "landmark");
    }

    /** Cracked street covered in rubble piles, leaning pillars and rebar. Roads: N E S W. */
    private static Prefab rubbleField() {
        Prefab.Builder b = district("preset_rubble");
        Random rng = new Random(4004);
        ground(b, 15);
        BlockState[] cracks = {RUBBLE[0], RUBBLE[4]};
        for (int x = 0; x < D; x++) {
            for (int z = 0; z < D; z++) {
                if (rng.nextDouble() < 0.07) {
                    b.set(x, 0, z, pick(rng, cracks));
                }
            }
        }
        for (int i = 0; i < 6; i++) {
            rubblePile(b, rng, 6 + rng.nextInt(36), 6 + rng.nextInt(36), 4 + rng.nextInt(4), 3 + rng.nextInt(5));
        }
        for (int k = 0; k < 3; k++) {
            int px = 8 + rng.nextInt(32);
            int pz = 8 + rng.nextInt(32);
            int dir = rng.nextBoolean() ? 1 : -1;
            for (int y = 1; y <= 12; y++) {
                int off = dir * (y / 3);
                b.fill(px + off, y, pz, px + off + 1, y, pz + 1, WALL);
            }
        }
        for (int i = 0; i < 30; i++) {
            int x = 2 + rng.nextInt(44);
            int z = 2 + rng.nextInt(44);
            int top = 0;
            for (int y = 12; y >= 1; y--) {
                if (!b.isAir(x, y, z)) {
                    top = y;
                    break;
                }
            }
            if (top > 0) {
                b.fill(x, top + 1, z, x, top + 1 + rng.nextInt(3), z, BARS);
            }
        }
        return finish(b, 15, "street", "rubble");
    }

    /** Subway kiosk with a big green sign and a white M. Road: S. */
    private static Prefab subwayEntrance() {
        Prefab.Builder b = district("preset_subway_entrance");
        ground(b, Prefab.SOUTH);
        b.shell(16, 1, 9, 31, 6, 16, WALL_DARK);
        b.fill(22, 1, 16, 25, 4, 16, AIR);       // doorway
        b.fill(17, 0, 10, 30, 0, 15, BLACK);     // dark floor inside
        b.fill(14, 7, 7, 33, 7, 19, SIDEWALK);   // canopy
        for (int x : new int[]{14, 33}) {
            for (int z : new int[]{7, 19}) {
                b.fill(x, 1, z, x, 6, z, WALL);
            }
        }
        b.fill(18, 8, 19, 29, 12, 19, Blocks.GREEN_CONCRETE.getDefaultState());
        String[] m = {"X...X", "XX.XX", "X.X.X", "X...X", "X...X"};
        for (int row = 0; row < 5; row++) {
            for (int col = 0; col < 5; col++) {
                if (m[row].charAt(col) == 'X') {
                    b.set(21 + col, 12 - row, 20, WHITE);
                }
            }
        }
        b.set(18, 13, 19, LAMP);
        b.set(29, 13, 19, LAMP);
        b.set(23, 5, 12, LAMP);
        b.set(24, 5, 12, LAMP);
        lampPost(b, 12, 28);
        lampPost(b, 35, 28);
        return finish(b, Prefab.SOUTH, "building", "landmark");
    }

    /** Steel gantry over an east-west road carrying two glowing billboards. Roads: E W. */
    private static Prefab billboardGantry() {
        Prefab.Builder b = district("preset_billboard_gantry");
        ground(b, Prefab.EAST | Prefab.WEST);
        for (int z : new int[]{16, 31}) {
            b.fill(24, 1, z, 25, 14, z, WALL_DARK);
        }
        b.fill(24, 12, 16, 25, 12, 31, WALL);
        b.fill(24, 14, 16, 25, 14, 31, WALL);
        for (int z = 17; z < 31; z += 3) {
            b.fill(24, 13, z, 25, 13, z, WALL_DARK);
        }
        b.fill(24, 15, 17, 24, 19, 23, LAMP);
        b.fill(24, 16, 18, 24, 18, 22, Blocks.MAGENTA_CONCRETE.getDefaultState());
        b.fill(24, 15, 25, 24, 19, 30, LAMP);
        b.fill(24, 16, 26, 24, 18, 29, Blocks.CYAN_CONCRETE.getDefaultState());
        b.fill(25, 15, 17, 25, 19, 23, WALL_DARK);
        b.fill(25, 15, 25, 25, 19, 30, WALL_DARK);
        b.fill(38, 1, 33, 44, 3, 36, Blocks.LIGHT_BLUE_CONCRETE.getDefaultState()); // blue tarp pile
        lampPost(b, 10, 14);
        lampPost(b, 37, 33);
        return finish(b, Prefab.EAST | Prefab.WEST, "street", "landmark");
    }

    /** A tower that leans one block east every five floors, with a gash near the top. Road: S. */
    private static Prefab leaningTower() {
        Prefab.Builder b = district("preset_leaning_tower");
        Random rng = new Random(6006);
        ground(b, Prefab.SOUTH);
        int z1 = 4;
        int z2 = 17;
        for (int y = 1; y <= 31; y++) {
            int s = y / 5;
            int x1 = 6 + s;
            int x2 = 19 + s;
            b.fill(x1, y, z1, x2, y, z2, WALL);
            if (y == 31) {
                continue; // roof layer stays solid
            }
            b.fill(x1 + 1, y, z1 + 1, x2 - 1, y, z2 - 1, AIR);
            if (y % 4 == 0) {
                b.fill(x1 + 1, y, z1 + 1, x2 - 1, y, z2 - 1, SIDEWALK);
            }
            if (y % 4 == 2 || y % 4 == 3) {
                for (int x = x1 + 1; x <= x2 - 1; x++) {
                    if (x % 3 != 0) {
                        b.set(x, y, z1, GLASS);
                        b.set(x, y, z2, GLASS);
                    }
                }
                for (int z = z1 + 1; z <= z2 - 1; z++) {
                    if (z % 3 != 0) {
                        b.set(x1, y, z, GLASS);
                        b.set(x2, y, z, GLASS);
                    }
                }
            }
        }
        b.fill(11, 1, z2, 14, 3, z2, AIR); // doorway
        for (int dx = -5; dx <= 5; dx++) {  // big gash near the top
            for (int dy = -5; dy <= 5; dy++) {
                for (int dz = -5; dz <= 5; dz++) {
                    if (dx * dx + dy * dy + dz * dz <= 25) {
                        b.set(19 + dx, 24 + dy, 4 + dz, AIR);
                    }
                }
            }
        }
        for (int y = 20; y <= 31; y++) {
            b.damage(6, y, z1, 26, y, z2, (y - 19) / 12.0 * 0.5, rng);
        }
        rubblePile(b, rng, 24, 10, 6, 4);
        rubblePile(b, rng, 12, 21, 5, 3);
        lampPost(b, 14, 27);
        lampPost(b, 33, 27);
        return finish(b, Prefab.SOUTH, "building", "tall", "leaning");
    }

    private PresetPrefabs() {
    }
}
