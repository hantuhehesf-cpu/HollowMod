package com.hollowmod.prefab;

import com.hollowmod.HollowMod;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtIo;
import net.minecraft.nbt.NbtList;
import net.minecraft.registry.Registries;
import net.minecraft.state.property.Property;
import net.minecraft.util.Identifier;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

/**
 * Reads prefab files WITHOUT needing WorldEdit installed.
 *  - .schem  : WorldEdit / Sponge schematic, version 2 and version 3.
 *  - .nbt    : vanilla Structure Block file (the same kind as building_1..6).
 * Old MCEdit ".schematic" files use numeric block ids and are NOT supported.
 */
public final class SchematicLoader {

    private static final long MAX_VOXELS = 4_000_000L;
    private static final Set<String> WARNED = new HashSet<>();

    // ------------------------------------------------------------------ entry points

    /** Loads a .schem or .nbt file from disk. The prefab id is the file name without the extension. */
    public static Prefab loadFile(Path file) throws IOException {
        String name = file.getFileName().toString();
        String lower = name.toLowerCase(Locale.ROOT);
        String id = name.substring(0, name.lastIndexOf('.')).toLowerCase(Locale.ROOT).replace(' ', '_');
        try (InputStream in = Files.newInputStream(file)) {
            Prefab prefab;
            if (lower.endsWith(".schem")) {
                prefab = readSponge(id, in);
            } else if (lower.endsWith(".nbt")) {
                prefab = readStructure(id, in);
            } else {
                throw new IOException("Unsupported file type (use .schem or .nbt): " + name);
            }
            prefab.source = "file " + name;
            return prefab;
        }
    }

    /** Loads a vanilla structure .nbt that is bundled inside the mod jar (e.g. building_1). */
    public static Prefab loadResourceStructure(String id, String resourcePath) throws IOException {
        try (InputStream in = SchematicLoader.class.getResourceAsStream(resourcePath)) {
            if (in == null) {
                throw new IOException("Resource not found: " + resourcePath);
            }
            return readStructure(id, in);
        }
    }

    // ------------------------------------------------------------------ Sponge .schem

    private static Prefab readSponge(String id, InputStream in) throws IOException {
        NbtCompound root = NbtIo.readCompressed(in);
        // Version 3 wraps everything in a "Schematic" compound; version 2 does not.
        NbtCompound s = root.contains("Schematic", NbtElement.COMPOUND_TYPE) ? root.getCompound("Schematic") : root;
        int version = s.getInt("Version");

        int w = s.getShort("Width") & 0xFFFF;
        int h = s.getShort("Height") & 0xFFFF;
        int l = s.getShort("Length") & 0xFFFF;
        if (w <= 0 || h <= 0 || l <= 0) {
            throw new IOException("Schematic has no size (is it really a Sponge .schem?)");
        }
        long total = (long) w * h * l;
        if (total > MAX_VOXELS) {
            throw new IOException("Schematic is too big (" + w + "x" + h + "x" + l + ")");
        }

        NbtCompound paletteTag;
        byte[] blockData;
        NbtList blockEntityList;
        if (version >= 3 || s.contains("Blocks", NbtElement.COMPOUND_TYPE)) {
            NbtCompound blocks = s.getCompound("Blocks");
            paletteTag = blocks.getCompound("Palette");
            blockData = blocks.getByteArray("Data");
            blockEntityList = blocks.getList("BlockEntities", NbtElement.COMPOUND_TYPE);
        } else {
            paletteTag = s.getCompound("Palette");
            blockData = s.getByteArray("BlockData");
            blockEntityList = s.getList("BlockEntities", NbtElement.COMPOUND_TYPE);
        }

        // palette: "minecraft:oak_stairs[facing=north]" -> number
        int maxIndex = -1;
        for (String key : paletteTag.getKeys()) {
            maxIndex = Math.max(maxIndex, paletteTag.getInt(key));
        }
        if (maxIndex < 0) {
            throw new IOException("Schematic palette is empty");
        }
        BlockState[] palette = new BlockState[maxIndex + 1];
        Arrays.fill(palette, Blocks.AIR.getDefaultState());
        for (String key : paletteTag.getKeys()) {
            palette[paletteTag.getInt(key)] = parseState(key);
        }

        // block data: one varint per block
        int[] data = new int[(int) total];
        int pos = 0;
        int out = 0;
        while (pos < blockData.length && out < data.length) {
            int value = 0;
            int shift = 0;
            int b;
            do {
                b = blockData[pos++] & 0xFF;
                value |= (b & 0x7F) << shift;
                shift += 7;
            } while ((b & 0x80) != 0 && pos < blockData.length);
            data[out++] = (value >= 0 && value <= maxIndex) ? value : 0;
        }
        if (out < data.length) {
            HollowMod.LOGGER.warn("[HollowMod] Schematic '{}' block data is shorter than its size; the rest stays empty.", id);
            Arrays.fill(data, out, data.length, -1);
        }

        Map<Integer, NbtCompound> blockEntities = new HashMap<>();
        for (int i = 0; i < blockEntityList.size(); i++) {
            NbtCompound be = blockEntityList.getCompound(i);
            int[] p = be.getIntArray("Pos");
            if (p.length < 3 || p[0] < 0 || p[1] < 0 || p[2] < 0 || p[0] >= w || p[1] >= h || p[2] >= l) {
                continue;
            }
            NbtCompound content;
            if (be.contains("Data", NbtElement.COMPOUND_TYPE)) {
                content = be.getCompound("Data").copy();
            } else {
                content = be.copy();
                content.remove("Pos");
                content.remove("Id");
            }
            String beId = be.getString("Id");
            if (!beId.isEmpty()) {
                content.putString("id", beId);
            }
            blockEntities.put((p[1] * l + p[2]) * w + p[0], content);
        }

        return new Prefab(id, w, h, l, palette, data, blockEntities);
    }

    // ------------------------------------------------------------------ vanilla structure .nbt

    private static Prefab readStructure(String id, InputStream in) throws IOException {
        NbtCompound root = NbtIo.readCompressed(in);
        NbtList size = root.getList("size", NbtElement.INT_TYPE);
        if (size.size() < 3) {
            throw new IOException("Structure file has no size");
        }
        int w = size.getInt(0);
        int h = size.getInt(1);
        int l = size.getInt(2);
        if (w <= 0 || h <= 0 || l <= 0 || (long) w * h * l > MAX_VOXELS) {
            throw new IOException("Structure has a bad size: " + w + "x" + h + "x" + l);
        }

        NbtList paletteList = root.getList("palette", NbtElement.COMPOUND_TYPE);
        BlockState[] palette = new BlockState[paletteList.size()];
        boolean[] isVoid = new boolean[paletteList.size()];
        for (int i = 0; i < paletteList.size(); i++) {
            NbtCompound entry = paletteList.getCompound(i);
            String name = entry.getString("Name");
            isVoid[i] = name.equals("minecraft:structure_void");
            Map<String, String> props = new HashMap<>();
            NbtCompound propsTag = entry.getCompound("Properties");
            for (String key : propsTag.getKeys()) {
                props.put(key, propsTag.getString(key));
            }
            palette[i] = stateFrom(name, props);
        }

        int[] data = new int[w * h * l];
        Arrays.fill(data, -1);
        Map<Integer, NbtCompound> blockEntities = new HashMap<>();
        NbtList blocks = root.getList("blocks", NbtElement.COMPOUND_TYPE);
        for (int i = 0; i < blocks.size(); i++) {
            NbtCompound b = blocks.getCompound(i);
            NbtList p = b.getList("pos", NbtElement.INT_TYPE);
            if (p.size() < 3) {
                continue;
            }
            int x = p.getInt(0);
            int y = p.getInt(1);
            int z = p.getInt(2);
            int state = b.getInt("state");
            if (x < 0 || y < 0 || z < 0 || x >= w || y >= h || z >= l || state < 0 || state >= palette.length) {
                continue;
            }
            int index = (y * l + z) * w + x;
            if (isVoid[state]) {
                continue; // structure_void = "leave whatever is there"
            }
            data[index] = state;
            if (b.contains("nbt", NbtElement.COMPOUND_TYPE)) {
                blockEntities.put(index, b.getCompound("nbt").copy());
            }
        }
        return new Prefab(id, w, h, l, palette, data, blockEntities);
    }

    // ------------------------------------------------------------------ block state parsing

    /** Parses "minecraft:oak_stairs[facing=north,half=bottom]". Unknown blocks become PrefabSystem.MISSING_BLOCK. */
    static BlockState parseState(String full) {
        String name = full;
        Map<String, String> props = new HashMap<>();
        int bracket = full.indexOf('[');
        if (bracket >= 0 && full.endsWith("]")) {
            name = full.substring(0, bracket);
            String inside = full.substring(bracket + 1, full.length() - 1);
            for (String pair : inside.split(",")) {
                int eq = pair.indexOf('=');
                if (eq > 0) {
                    props.put(pair.substring(0, eq).trim(), pair.substring(eq + 1).trim());
                }
            }
        }
        return stateFrom(name, props);
    }

    static BlockState stateFrom(String name, Map<String, String> props) {
        Identifier id = Identifier.tryParse(name);
        if (id == null || !Registries.BLOCK.containsId(id)) {
            if (WARNED.add(name)) {
                HollowMod.LOGGER.warn("[HollowMod] Unknown block '{}' in a prefab; it will be replaced.", name);
            }
            return PrefabSystem.MISSING_BLOCK;
        }
        Block block = Registries.BLOCK.get(id);
        BlockState state = block.getDefaultState();
        for (Map.Entry<String, String> e : props.entrySet()) {
            Property<?> property = block.getStateManager().getProperty(e.getKey());
            if (property != null) {
                state = withProperty(state, property, e.getValue());
            }
        }
        return state;
    }

    private static <T extends Comparable<T>> BlockState withProperty(BlockState state, Property<T> property, String value) {
        Optional<T> parsed = property.parse(value);
        return parsed.isPresent() ? state.with(property, parsed.get()) : state;
    }

    private SchematicLoader() {
    }
}
