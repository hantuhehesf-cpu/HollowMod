package com.hollowmod.prefab;

import com.hollowmod.HollowMod;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.particle.ParticleTypes;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.BlockMirror;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.math.BlockPos;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Random;

/**
 * Pastes prefabs into the world a little bit every tick (budget: PrefabSystem.BLOCKS_PER_TICK), so the
 * game never freezes. Blocks are visited layer by layer from the bottom up, which makes a piece
 * "reform" upward like a wave. Same idea as the maze painter.
 */
public final class PrefabPlacer {

    private static final Deque<Job> JOBS = new ArrayDeque<>();
    private static int particlesThisTick = 0;

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(PrefabPlacer::tick);
        ServerLifecycleEvents.SERVER_STOPPING.register(server -> JOBS.clear());
    }

    /**
     * Queues a paste.
     *
     * @param min      the lowest corner (smallest x, y, z) of the piece AFTER rotation
     * @param placeAir true = air blocks of the prefab also overwrite the world (clears the area)
     * @param integrity 1.0 = every block is placed; 0.9 = about 10% of solid blocks are skipped (ruin look)
     * @param effects  true = spawn "dissolve" particles while placing
     * @param onDone   called on the server thread when the last block is placed (may be null)
     */
    public static Job enqueue(ServerWorld world, Prefab prefab, BlockPos min, BlockRotation rotation, BlockMirror mirror,
                              boolean placeAir, float integrity, long seed, boolean effects, Runnable onDone) {
        Job job = new Job(world, prefab, min, rotation, mirror, placeAir, integrity, seed, effects, onDone);
        JOBS.add(job);
        return job;
    }

    public static int queueSize() {
        return JOBS.size();
    }

    public static void cancelAll() {
        JOBS.clear();
    }

    private static void tick(MinecraftServer server) {
        particlesThisTick = 0;
        int budget = PrefabSystem.BLOCKS_PER_TICK;
        while (budget > 0 && !JOBS.isEmpty()) {
            Job job = JOBS.peek();
            budget -= job.step(budget);
            if (job.done) {
                JOBS.poll();
                if (job.onDone != null) {
                    try {
                        job.onDone.run();
                    } catch (Exception e) {
                        HollowMod.LOGGER.warn("[HollowMod] Prefab completion callback failed", e);
                    }
                }
            }
        }
    }

    // ------------------------------------------------------------------ one paste job

    public static final class Job {
        private final ServerWorld world;
        private final Prefab p;
        private final int minX;
        private final int minY;
        private final int minZ;
        private final BlockRotation rotation;
        private final BlockMirror mirror;
        private final boolean placeAir;
        private final float integrity;
        private final boolean effects;
        private final Runnable onDone;
        private final BlockState[] states;
        private final boolean[] airFlag;
        private final Random rng;
        private final int total;
        private int cursor = 0;
        private int lastChunkX = Integer.MIN_VALUE;
        private int lastChunkZ = Integer.MIN_VALUE;
        boolean done = false;

        Job(ServerWorld world, Prefab p, BlockPos min, BlockRotation rotation, BlockMirror mirror,
            boolean placeAir, float integrity, long seed, boolean effects, Runnable onDone) {
            this.world = world;
            this.p = p;
            this.minX = min.getX();
            this.minY = min.getY();
            this.minZ = min.getZ();
            this.rotation = rotation;
            this.mirror = mirror;
            this.placeAir = placeAir;
            this.integrity = integrity;
            this.effects = effects;
            this.onDone = onDone;
            this.rng = new Random(seed);
            this.total = p.data.length;

            // Rotate/mirror every palette entry ONCE (stairs, logs, doors... must face the right way).
            this.states = new BlockState[p.palette.length];
            this.airFlag = new boolean[p.palette.length];
            for (int i = 0; i < p.palette.length; i++) {
                BlockState s = p.palette[i];
                if (mirror != BlockMirror.NONE) {
                    s = s.mirror(mirror);
                }
                if (rotation != BlockRotation.NONE) {
                    s = s.rotate(rotation);
                }
                states[i] = s;
                airFlag[i] = s.isAir();
            }
        }

        /** Visits up to `budget` positions. Returns how many it used. */
        int step(int budget) {
            int sx = p.sizeX;
            int sz = p.sizeZ;
            int used = 0;
            BlockPos.Mutable pos = new BlockPos.Mutable();
            while (used < budget && cursor < total) {
                int i = cursor++;
                used++;
                int code = p.data[i];
                if (code < 0 || code >= states.length) {
                    continue;
                }
                boolean air = airFlag[code];
                if (air && !placeAir) {
                    continue;
                }

                int x = i % sx;
                int rest = i / sx;
                int z = rest % sz;
                int y = rest / sz;

                int mx = x;
                int mz = z;
                if (mirror == BlockMirror.LEFT_RIGHT) {
                    mz = sz - 1 - z;
                } else if (mirror == BlockMirror.FRONT_BACK) {
                    mx = sx - 1 - x;
                }
                int rx;
                int rz;
                switch (rotation) {
                    case CLOCKWISE_90 -> {
                        rx = sz - 1 - mz;
                        rz = mx;
                    }
                    case CLOCKWISE_180 -> {
                        rx = sx - 1 - mx;
                        rz = sz - 1 - mz;
                    }
                    case COUNTERCLOCKWISE_90 -> {
                        rx = mz;
                        rz = sx - 1 - mx;
                    }
                    default -> {
                        rx = mx;
                        rz = mz;
                    }
                }

                int wx = minX + rx;
                int wy = minY + y;
                int wz = minZ + rz;
                if (world.isOutOfHeightLimit(wy)) {
                    continue;
                }
                if (!air && integrity < 1.0f && rng.nextFloat() > integrity) {
                    continue;
                }

                // Make sure the chunk is loaded (a blocking load, but only once per chunk per tick of work).
                int cx = wx >> 4;
                int cz = wz >> 4;
                if (cx != lastChunkX || cz != lastChunkZ) {
                    world.getChunk(cx, cz);
                    lastChunkX = cx;
                    lastChunkZ = cz;
                }

                pos.set(wx, wy, wz);
                BlockState state = states[code];
                if (world.getBlockState(pos) == state) {
                    continue;
                }
                world.setBlockState(pos, state, Block.NOTIFY_LISTENERS);

                if (!air) {
                    NbtCompound nbt = p.blockEntities.get(i);
                    if (nbt != null) {
                        applyBlockEntity(pos, nbt, wx, wy, wz);
                    }
                    if (effects && particlesThisTick < PrefabSystem.PARTICLES_PER_TICK && rng.nextInt(20) == 0) {
                        particlesThisTick++;
                        world.spawnParticles(ParticleTypes.REVERSE_PORTAL, wx + 0.5, wy + 0.5, wz + 0.5,
                                2, 0.3, 0.3, 0.3, 0.05);
                    }
                }
            }
            if (cursor >= total) {
                done = true;
            }
            return used;
        }

        private void applyBlockEntity(BlockPos pos, NbtCompound nbt, int wx, int wy, int wz) {
            try {
                BlockEntity be = world.getBlockEntity(pos);
                if (be != null) {
                    NbtCompound copy = nbt.copy();
                    copy.putInt("x", wx);
                    copy.putInt("y", wy);
                    copy.putInt("z", wz);
                    be.readNbt(copy);
                    be.markDirty();
                }
            } catch (Exception e) {
                HollowMod.LOGGER.warn("[HollowMod] Could not restore block entity data at {}: {}", pos, e.toString());
            }
        }
    }

    private PrefabPlacer() {
    }
}
