package com.hollowmod.prefab;

import com.hollowmod.HollowMod;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;

/**
 * SYSTEM 6 PREFAB LAYER: entry point + every tunable number.
 * (Commands are registered separately through registry/PrefabCommands, see ModCommands.)
 */
public final class PrefabSystem {

    /** How many voxels (block positions) the placer visits per server tick, across all jobs. Higher = faster but may lag. */
    public static final int BLOCKS_PER_TICK = 3000;
    /** Max particles the placer's "dissolve" effect spawns per tick. */
    public static final int PARTICLES_PER_TICK = 80;

    /** Size of one district piece (blocks). The built-in presets are exactly this wide and deep. */
    public static final int DISTRICT = 48;
    /** Height of the built-in presets. They are padded with air so placing one fully clears the old piece. */
    public static final int DISTRICT_HEIGHT = 44;

    /** Ticks of warning (sound + sparks) before the shift demo starts changing blocks. 20 ticks = 1 second. */
    public static final int WARN_TICKS = 80;

    /** What a schematic block that this Minecraft version doesn't know becomes. Change to Blocks.STONE to see them. */
    public static final BlockState MISSING_BLOCK = Blocks.AIR.getDefaultState();

    public static void register() {
        try {
            int count = PrefabRegistry.reload();
            HollowMod.LOGGER.info("[HollowMod] Prefab system ready: {} prefab(s) loaded.", count);
        } catch (Exception e) {
            HollowMod.LOGGER.error("[HollowMod] Prefab loading failed (the rest of the mod still works)", e);
        }
        PrefabPlacer.register();
        DistrictDemo.register();
    }

    private PrefabSystem() {
    }
}
