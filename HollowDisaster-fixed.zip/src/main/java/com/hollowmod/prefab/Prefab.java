package com.hollowmod.prefab;

import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.util.BlockMirror;
import net.minecraft.util.BlockRotation;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

/**
 * One reusable piece of city (a "prefab"). It is just data: a box of blocks plus a little metadata.
 * It can come from a WorldEdit .schem file, a vanilla structure .nbt file, or be built in code.
 *
 * Block storage: data[index] is an index into palette. index = (y * sizeZ + z) * sizeX + x.
 * data value -1 means "nothing here" (used by structure files; it is never placed).
 */
public final class Prefab {

    // Road connection bits (which sides of the piece have a road). Used later by the shifting engine.
    public static final int NORTH = 1;
    public static final int EAST = 2;
    public static final int SOUTH = 4;
    public static final int WEST = 8;

    public final String id;
    public final int sizeX;
    public final int sizeY;
    public final int sizeZ;
    public final BlockState[] palette;
    public final int[] data;
    /** Block entity data (chests, signs...) keyed by the same index as data. */
    public final Map<Integer, NbtCompound> blockEntities;

    public final Set<String> tags = new LinkedHashSet<>();
    public int weight = 1;
    /** Bitmask of NORTH/EAST/SOUTH/WEST. 0 = no road. */
    public int connections = 0;
    /** true = layer 0 is the ground (it replaces the ground surface). false = piece sits ON the ground. */
    public boolean groundLayer = false;
    public String source = "unknown";

    public Prefab(String id, int sizeX, int sizeY, int sizeZ, BlockState[] palette, int[] data,
                  Map<Integer, NbtCompound> blockEntities) {
        this.id = id;
        this.sizeX = sizeX;
        this.sizeY = sizeY;
        this.sizeZ = sizeZ;
        this.palette = palette;
        this.data = data;
        this.blockEntities = blockEntities;
    }

    public int index(int x, int y, int z) {
        return (y * sizeZ + z) * sizeX + x;
    }

    private static boolean swapsAxes(BlockRotation rotation) {
        return rotation == BlockRotation.CLOCKWISE_90 || rotation == BlockRotation.COUNTERCLOCKWISE_90;
    }

    /** Width (X) of the piece after rotating. */
    public int footprintX(BlockRotation rotation) {
        return swapsAxes(rotation) ? sizeZ : sizeX;
    }

    /** Depth (Z) of the piece after rotating. */
    public int footprintZ(BlockRotation rotation) {
        return swapsAxes(rotation) ? sizeX : sizeZ;
    }

    /** Which sides have a road after mirroring and rotating (mirror first, then rotate, like vanilla). */
    public int connectionsFor(BlockRotation rotation, BlockMirror mirror) {
        int c = connections;
        if (mirror == BlockMirror.LEFT_RIGHT) {
            c = swapBits(c, NORTH, SOUTH);
        } else if (mirror == BlockMirror.FRONT_BACK) {
            c = swapBits(c, EAST, WEST);
        }
        int turns = switch (rotation) {
            case NONE -> 0;
            case CLOCKWISE_90 -> 1;
            case CLOCKWISE_180 -> 2;
            case COUNTERCLOCKWISE_90 -> 3;
        };
        for (int i = 0; i < turns; i++) {
            c = ((c << 1) | (c >> 3)) & 15;
        }
        return c;
    }

    private static int swapBits(int c, int a, int b) {
        boolean hasA = (c & a) != 0;
        boolean hasB = (c & b) != 0;
        c &= ~(a | b);
        if (hasA) {
            c |= b;
        }
        if (hasB) {
            c |= a;
        }
        return c;
    }

    public String connectionLetters() {
        StringBuilder sb = new StringBuilder();
        if ((connections & NORTH) != 0) sb.append('N');
        if ((connections & EAST) != 0) sb.append('E');
        if ((connections & SOUTH) != 0) sb.append('S');
        if ((connections & WEST) != 0) sb.append('W');
        return sb.length() == 0 ? "-" : sb.toString();
    }

    // ------------------------------------------------------------------ builder (used by presets)

    /** Tiny helper to build a prefab in code. Palette index 0 is always air. */
    public static final class Builder {
        private final String id;
        private final int sx;
        private final int sy;
        private final int sz;
        private final List<BlockState> palette = new ArrayList<>();
        private final Map<BlockState, Integer> paletteIndex = new HashMap<>();
        private final int[] data;

        public Builder(String id, int sx, int sy, int sz) {
            this.id = id;
            this.sx = sx;
            this.sy = sy;
            this.sz = sz;
            this.data = new int[sx * sy * sz];
            indexOf(Blocks.AIR.getDefaultState()); // index 0 = air, so a fresh array is all air
        }

        private int indexOf(BlockState state) {
            Integer existing = paletteIndex.get(state);
            if (existing != null) {
                return existing;
            }
            palette.add(state);
            int index = palette.size() - 1;
            paletteIndex.put(state, index);
            return index;
        }

        private boolean inBounds(int x, int y, int z) {
            return x >= 0 && y >= 0 && z >= 0 && x < sx && y < sy && z < sz;
        }

        public Builder set(int x, int y, int z, BlockState state) {
            if (inBounds(x, y, z)) {
                data[(y * sz + z) * sx + x] = indexOf(state);
            }
            return this;
        }

        public boolean isAir(int x, int y, int z) {
            return !inBounds(x, y, z) || data[(y * sz + z) * sx + x] == 0;
        }

        /** Fills a box (both corners included). Parts outside the prefab are ignored. */
        public Builder fill(int x1, int y1, int z1, int x2, int y2, int z2, BlockState state) {
            int idx = indexOf(state);
            int minX = Math.max(0, Math.min(x1, x2));
            int maxX = Math.min(sx - 1, Math.max(x1, x2));
            int minY = Math.max(0, Math.min(y1, y2));
            int maxY = Math.min(sy - 1, Math.max(y1, y2));
            int minZ = Math.max(0, Math.min(z1, z2));
            int maxZ = Math.min(sz - 1, Math.max(z1, z2));
            for (int y = minY; y <= maxY; y++) {
                for (int z = minZ; z <= maxZ; z++) {
                    for (int x = minX; x <= maxX; x++) {
                        data[(y * sz + z) * sx + x] = idx;
                    }
                }
            }
            return this;
        }

        /** Four walls plus a roof on the top layer (y2). No floor: the ground layer is the floor. */
        public Builder shell(int x1, int y1, int z1, int x2, int y2, int z2, BlockState wall) {
            fill(x1, y1, z1, x2, y2, z2, wall);
            fill(x1 + 1, y1, z1 + 1, x2 - 1, y2 - 1, z2 - 1, Blocks.AIR.getDefaultState());
            return this;
        }

        /** Randomly deletes blocks inside a box (ruin effect). */
        public Builder damage(int x1, int y1, int z1, int x2, int y2, int z2, double chance, Random rng) {
            int minX = Math.max(0, Math.min(x1, x2));
            int maxX = Math.min(sx - 1, Math.max(x1, x2));
            int minY = Math.max(0, Math.min(y1, y2));
            int maxY = Math.min(sy - 1, Math.max(y1, y2));
            int minZ = Math.max(0, Math.min(z1, z2));
            int maxZ = Math.min(sz - 1, Math.max(z1, z2));
            for (int y = minY; y <= maxY; y++) {
                for (int z = minZ; z <= maxZ; z++) {
                    for (int x = minX; x <= maxX; x++) {
                        int i = (y * sz + z) * sx + x;
                        if (data[i] != 0 && rng.nextDouble() < chance) {
                            data[i] = 0;
                        }
                    }
                }
            }
            return this;
        }

        public Prefab build() {
            return new Prefab(id, sx, sy, sz, palette.toArray(new BlockState[0]), data, new HashMap<>());
        }
    }
}
