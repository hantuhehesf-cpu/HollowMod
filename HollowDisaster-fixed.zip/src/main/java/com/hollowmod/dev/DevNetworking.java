package com.hollowmod.dev;

import com.hollowmod.HollowMod;
import net.minecraft.util.Identifier;

/** Channel names for the dev menu. */
public final class DevNetworking {

    /** Server -> client: every Hollow (loaded and remembered) + the server-side dev settings. */
    public static final Identifier SYNC = new Identifier(HollowMod.MOD_ID, "dev_sync");
    /** Server -> client: one line of feedback for the dev menu log. */
    public static final Identifier FEEDBACK = new Identifier(HollowMod.MOD_ID, "dev_feedback");
    /** Client -> server: "send me a sync right now". */
    public static final Identifier REQUEST_SYNC = new Identifier(HollowMod.MOD_ID, "dev_request_sync");
    /** Client -> server: do something to a Hollow (or a global dev action). */
    public static final Identifier ACTION = new Identifier(HollowMod.MOD_ID, "dev_action");

    private DevNetworking() {
    }
}
