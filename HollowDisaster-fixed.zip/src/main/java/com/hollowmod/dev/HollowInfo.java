package com.hollowmod.dev;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.PacketByteBuf;

import java.util.UUID;

/**
 * A plain snapshot of one Hollow (position, size, meters, family...). It is what the server sends to the
 * dev menu / distant renderer, and what the server remembers (in DevRegistryState) for Hollows whose chunk is
 * not loaded right now. No game objects inside, so it is safe to use on both client and server.
 */
public final class HollowInfo {

    public static final UUID NONE = new UUID(0L, 0L);

    public UUID uuid = NONE;
    /** Dimension id, e.g. "minecraft:overworld". */
    public String dim = "minecraft:overworld";
    public double x;
    public double y;
    public double z;
    public float radius;
    public float maxRadius;
    public boolean frozen;
    public float activity;
    public float gauge;
    public int generation;
    public UUID parent = NONE;
    public int children;
    /** true = the Hollow entity exists right now. false = last known data from the save file. */
    public boolean loaded = true;
    /** true = its chunk is force-loaded so it keeps ticking even when nobody is near. */
    public boolean kept;
    public int growthInterval = 20;
    /** Ticks until collapse, -1 = not collapsing. */
    public int collapseTicks = -1;

    public String shortId() {
        return uuid.toString().substring(0, 8);
    }

    public void write(PacketByteBuf b) {
        b.writeUuid(uuid);
        b.writeString(dim);
        b.writeDouble(x);
        b.writeDouble(y);
        b.writeDouble(z);
        b.writeFloat(radius);
        b.writeFloat(maxRadius);
        b.writeBoolean(frozen);
        b.writeFloat(activity);
        b.writeFloat(gauge);
        b.writeVarInt(generation);
        b.writeUuid(parent == null ? NONE : parent);
        b.writeVarInt(children);
        b.writeBoolean(loaded);
        b.writeBoolean(kept);
        b.writeVarInt(growthInterval);
        b.writeInt(collapseTicks);
    }

    public static HollowInfo read(PacketByteBuf b) {
        HollowInfo h = new HollowInfo();
        h.uuid = b.readUuid();
        h.dim = b.readString(64);
        h.x = b.readDouble();
        h.y = b.readDouble();
        h.z = b.readDouble();
        h.radius = b.readFloat();
        h.maxRadius = b.readFloat();
        h.frozen = b.readBoolean();
        h.activity = b.readFloat();
        h.gauge = b.readFloat();
        h.generation = b.readVarInt();
        h.parent = b.readUuid();
        h.children = b.readVarInt();
        h.loaded = b.readBoolean();
        h.kept = b.readBoolean();
        h.growthInterval = b.readVarInt();
        h.collapseTicks = b.readInt();
        return h;
    }

    public NbtCompound toNbt() {
        NbtCompound n = new NbtCompound();
        n.putUuid("Id", uuid);
        n.putString("Dim", dim);
        n.putDouble("X", x);
        n.putDouble("Y", y);
        n.putDouble("Z", z);
        n.putFloat("Radius", radius);
        n.putFloat("MaxRadius", maxRadius);
        n.putBoolean("Frozen", frozen);
        n.putFloat("Activity", activity);
        n.putFloat("Gauge", gauge);
        n.putInt("Gen", generation);
        n.putUuid("Parent", parent == null ? NONE : parent);
        n.putInt("Children", children);
        n.putInt("Interval", growthInterval);
        return n;
    }

    public static HollowInfo fromNbt(NbtCompound n) {
        HollowInfo h = new HollowInfo();
        h.uuid = n.getUuid("Id");
        h.dim = n.getString("Dim");
        h.x = n.getDouble("X");
        h.y = n.getDouble("Y");
        h.z = n.getDouble("Z");
        h.radius = n.getFloat("Radius");
        h.maxRadius = n.getFloat("MaxRadius");
        h.frozen = n.getBoolean("Frozen");
        h.activity = n.getFloat("Activity");
        h.gauge = n.getFloat("Gauge");
        h.generation = n.getInt("Gen");
        h.parent = n.containsUuid("Parent") ? n.getUuid("Parent") : NONE;
        h.children = n.getInt("Children");
        h.growthInterval = n.contains("Interval") ? n.getInt("Interval") : 20;
        h.loaded = false;
        return h;
    }

    public HollowInfo copy() {
        HollowInfo h = new HollowInfo();
        h.uuid = uuid;
        h.dim = dim;
        h.x = x;
        h.y = y;
        h.z = z;
        h.radius = radius;
        h.maxRadius = maxRadius;
        h.frozen = frozen;
        h.activity = activity;
        h.gauge = gauge;
        h.generation = generation;
        h.parent = parent;
        h.children = children;
        h.loaded = loaded;
        h.kept = kept;
        h.growthInterval = growthInterval;
        h.collapseTicks = collapseTicks;
        return h;
    }
}
