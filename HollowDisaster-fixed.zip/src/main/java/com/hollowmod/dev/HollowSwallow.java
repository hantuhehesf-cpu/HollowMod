package com.hollowmod.dev;

import com.hollowmod.HollowMod;
import com.hollowmod.entity.EtherealEntity;
import com.hollowmod.entity.HollowCoreEntity;
import com.hollowmod.event.HollowDimensionEvents;
import com.hollowmod.registry.ModDimensions;
import com.hollowmod.state.HollowWorldState;
import net.fabricmc.fabric.api.dimension.v1.FabricDimensions;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.TeleportTarget;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * SWALLOWING.
 * Every second each Hollow looks for creatures inside its dome (players are already pulled in by the dome-touch
 * rule, so they are skipped here). A creature found is NOT harmed: it is carried into that Hollow's sub-region in the
 * Hollow dimension, keeping all its data, and gets a tag remembering which Hollow swallowed it.
 * If a tagged creature (or a player inside that Hollow) later dies, its mass goes to the Hollow's Ether Activity
 * (1.0 mass = 0.5% Activity). If the Hollow is not loaded at that moment, the mass waits in DevRegistryState.
 */
public final class HollowSwallow {

    public static final String TAG_PREFIX = "hollowmod.swallowed.";
    /** At most this many creatures are swallowed per Hollow per pass (once a second). */
    private static final int MAX_PER_PASS = 4;

    private static int counter = 0;

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            if (++counter % 20 != 0) {
                return;
            }
            DevRegistryState state = DevRegistryState.get(server);
            if (!state.swallowEnabled) {
                return;
            }
            for (HollowCoreEntity core : new ArrayList<>(HollowCoreEntity.getActiveCores())) {
                swallowNearby(server, core, MAX_PER_PASS);
            }
        });
        ServerLivingEntityEvents.AFTER_DEATH.register((entity, source) -> onDeath(entity));
    }

    /** Swallows up to `max` creatures inside the dome now. Returns how many were swallowed. */
    public static int swallowNearby(MinecraftServer server, HollowCoreEntity core, int max) {
        if (!(core.getWorld() instanceof ServerWorld world) || world.getRegistryKey() == ModDimensions.HOLLOW_DIMENSION_KEY) {
            return 0;
        }
        double radius = core.getCurrentRadius();
        if (radius < 1.0D) {
            return 0;
        }
        Vec3d center = core.getPos();
        double radiusSq = radius * radius;
        Box box = new Box(center.x - radius, center.y - radius, center.z - radius,
                center.x + radius, center.y + radius, center.z + radius);
        List<LivingEntity> found = world.getEntitiesByClass(LivingEntity.class, box, e ->
                e.isAlive()
                        && !(e instanceof PlayerEntity)
                        && !(e instanceof EtherealEntity)
                        && e.canUsePortals()
                        && e.squaredDistanceTo(center) <= radiusSq);
        int count = 0;
        for (LivingEntity e : found) {
            if (count >= max) {
                break;
            }
            if (swallow(server, e, core)) {
                count++;
            }
        }
        if (count > 0) {
            DevServer.note(server, false, "Hollow " + core.getUuid().toString().substring(0, 8) + " swallowed " + count + " creature(s).");
        }
        return count;
    }

    private static boolean swallow(MinecraftServer server, LivingEntity entity, HollowCoreEntity core) {
        ServerWorld hollowWorld = server.getWorld(ModDimensions.HOLLOW_DIMENSION_KEY);
        if (hollowWorld == null) {
            return false;
        }
        try {
            HollowWorldState state = HollowWorldState.get(server);
            int slot = state.getOrAssignSlot(core.getUuid());
            BlockPos anchor = HollowWorldState.slotToSubRegionCenter(slot);
            BlockPos spawn = HollowDimensionEvents.findSafeSpawnNear(hollowWorld, core.getUuid(), anchor);

            double jitterX = (core.getWorld().random.nextDouble() * 2.0 - 1.0) * 4.0;
            double jitterZ = (core.getWorld().random.nextDouble() * 2.0 - 1.0) * 4.0;
            Vec3d target = new Vec3d(spawn.getX() + 0.5 + jitterX, spawn.getY() + 1.0, spawn.getZ() + 0.5 + jitterZ);

            Entity moved = FabricDimensions.teleport(entity, hollowWorld,
                    new TeleportTarget(target, Vec3d.ZERO, entity.getYaw(), entity.getPitch()));
            if (moved == null) {
                return false;
            }
            moved.addCommandTag(TAG_PREFIX + core.getUuid());
            moved.fallDistance = 0.0F;
            if (moved instanceof LivingEntity living) {
                living.addStatusEffect(new StatusEffectInstance(StatusEffects.SLOW_FALLING, 100, 0, false, false, false));
            }
            return true;
        } catch (Exception ex) {
            HollowMod.LOGGER.warn("[HollowMod] Could not swallow {}: {}", entity.getType().getTranslationKey(), ex.toString());
            return false;
        }
    }

    /** A creature died. If a Hollow swallowed it (or it is a player inside a Hollow), feed that Hollow. */
    private static void onDeath(LivingEntity entity) {
        if (!(entity.getWorld() instanceof ServerWorld world) || entity instanceof EtherealEntity) {
            return;
        }
        MinecraftServer server = world.getServer();
        if (server == null) {
            return;
        }

        UUID hollowId = null;
        for (String tag : entity.getCommandTags()) {
            if (tag.startsWith(TAG_PREFIX)) {
                try {
                    hollowId = UUID.fromString(tag.substring(TAG_PREFIX.length()));
                } catch (IllegalArgumentException ignored) {
                    // bad tag, ignore
                }
            }
        }
        if (hollowId == null && entity instanceof ServerPlayerEntity player
                && world.getRegistryKey() == ModDimensions.HOLLOW_DIMENSION_KEY) {
            hollowId = HollowWorldState.get(server).getCurrentHollow(player.getUuid());
        }
        if (hollowId == null) {
            return;
        }

        DevRegistryState state = DevRegistryState.get(server);
        double mass = state.mobMassPerHealth * Math.max(1.0F, entity.getMaxHealth());
        if (entity instanceof PlayerEntity) {
            mass *= 1.5D;
        }

        HollowCoreEntity core = findCore(hollowId);
        if (core != null) {
            core.addMass(mass);
            DevServer.note(server, false, "Death feeds Hollow " + hollowId.toString().substring(0, 8)
                    + ": +" + String.format("%.2f", mass) + " mass (+" + String.format("%.2f", mass * 0.5) + "% Activity)");
        } else {
            state.pendingMass.merge(hollowId, mass, Double::sum);
            state.markDirty();
        }
    }

    public static HollowCoreEntity findCore(UUID id) {
        for (HollowCoreEntity core : HollowCoreEntity.getActiveCores()) {
            if (core.getUuid().equals(id)) {
                return core;
            }
        }
        return null;
    }

    private HollowSwallow() {
    }
}
