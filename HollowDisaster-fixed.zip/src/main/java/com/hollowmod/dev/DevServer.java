package com.hollowmod.dev;

import com.hollowmod.HollowMod;
import com.hollowmod.entity.EtherealEntity;
import com.hollowmod.entity.HollowCoreEntity;
import com.hollowmod.event.HollowDimensionEvents;
import com.hollowmod.registry.ModDimensions;
import com.hollowmod.registry.ModEntities;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.mob.MobEntity;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;

/**
 * Server half of the Hollow dev menu (client half: client/dev/DevMenuScreen).
 *  - every half second it sends every Hollow (loaded ones live, unloaded ones from the saved snapshot) to all players,
 *    which the dev map and the "distant Hollow" renderer use
 *  - it receives dev actions (size, radius, freeze, overflow, collapse, move, delete...) and checks permission first
 *  - it keeps chunks of "kept loaded" Hollows force-loaded so those Hollows keep growing when nobody is near
 * Permission: operator level 2, or you are the owner of a single-player world.
 */
public final class DevServer {

    private static int tickCounter = 0;

    public static void register() {
        ServerPlayNetworking.registerGlobalReceiver(DevNetworking.ACTION, (server, player, handler, buf, responseSender) -> {
            UUID id = buf.readUuid();
            String action = buf.readString(32);
            double a = buf.readDouble();
            double b = buf.readDouble();
            double c = buf.readDouble();
            String s = buf.readString(64);
            server.execute(() -> handleAction(server, player, id, action, a, b, c, s));
        });
        ServerPlayNetworking.registerGlobalReceiver(DevNetworking.REQUEST_SYNC, (server, player, handler, buf, responseSender) ->
                server.execute(() -> sendSync(server, player, collect(server, DevRegistryState.get(server)))));

        ServerTickEvents.END_SERVER_TICK.register(DevServer::tick);

        // A Hollow that is really destroyed (removed, exploded, collapsed) is forgotten. One that only unloads is kept.
        ServerEntityEvents.ENTITY_UNLOAD.register((entity, world) -> {
            if (entity instanceof HollowCoreEntity core && entity.getRemovalReason() != null
                    && entity.getRemovalReason().shouldDestroy()) {
                MinecraftServer server = world.getServer();
                if (server != null) {
                    DevRegistryState st = DevRegistryState.get(server);
                    st.snapshots.remove(core.getUuid());
                    st.kept.remove(core.getUuid());
                    st.pendingMass.remove(core.getUuid());
                    st.markDirty();
                }
            }
        });

        HollowSwallow.register();
    }

    public static boolean canUse(MinecraftServer server, ServerPlayerEntity player) {
        return player.hasPermissionLevel(2) || server.isSingleplayer();
    }

    // ------------------------------------------------------------------ feedback

    /** One line in the dev menu log of every player who may use the menu. */
    public static void note(MinecraftServer server, boolean error, String message) {
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            if (canUse(server, p)) {
                feedback(p, error, message);
            }
        }
    }

    public static void feedback(ServerPlayerEntity player, boolean error, String message) {
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeBoolean(error);
        buf.writeString(message, 400);
        ServerPlayNetworking.send(player, DevNetworking.FEEDBACK, buf);
    }

    // ------------------------------------------------------------------ periodic sync

    private static void tick(MinecraftServer server) {
        if (++tickCounter % 10 != 0) {
            return;
        }
        DevRegistryState st = DevRegistryState.get(server);
        List<HollowInfo> list = collect(server, st);

        // mass from deaths that happened while a Hollow was unloaded
        if (!st.pendingMass.isEmpty()) {
            for (HollowCoreEntity core : HollowCoreEntity.getActiveCores()) {
                Double pending = st.pendingMass.remove(core.getUuid());
                if (pending != null) {
                    core.addMass(pending);
                    st.markDirty();
                }
            }
        }

        applyForcedChunks(server, st, list);

        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            sendSync(server, p, list);
        }
    }

    /** Builds the full list: every loaded Hollow (live data) plus remembered ones that are not loaded. */
    private static List<HollowInfo> collect(MinecraftServer server, DevRegistryState st) {
        List<HollowInfo> list = new ArrayList<>();
        Set<UUID> loadedIds = new HashSet<>();
        boolean dirty = false;

        for (HollowCoreEntity core : HollowCoreEntity.getActiveCores()) {
            HollowInfo h = new HollowInfo();
            h.uuid = core.getUuid();
            h.dim = core.getWorld().getRegistryKey().getValue().toString();
            h.x = core.getX();
            h.y = core.getY();
            h.z = core.getZ();
            h.radius = core.getCurrentRadius();
            h.maxRadius = (float) core.getTargetRadius();
            h.frozen = core.isGrowthFrozen();
            h.activity = (float) core.getEtherActivity();
            h.gauge = (float) core.getZenlessLimitGauge();
            h.generation = core.getGeneration();
            h.parent = core.getParentId() == null ? HollowInfo.NONE : core.getParentId();
            h.children = core.getChildIds().size();
            h.loaded = true;
            h.kept = st.keepAllLoaded || st.kept.contains(core.getUuid());
            h.growthInterval = core.getGrowthTickInterval();
            h.collapseTicks = core.getCollapseTicksLeft();
            list.add(h);
            loadedIds.add(h.uuid);

            // refresh the saved snapshot a few times a minute (not every sync, to avoid needless disk writes)
            HollowInfo old = st.snapshots.get(h.uuid);
            if (old == null || tickCounter % 100 == 0 || old.dim == null) {
                st.snapshots.put(h.uuid, h.copy());
                dirty = true;
            }
        }
        for (HollowInfo snap : st.snapshots.values()) {
            if (!loadedIds.contains(snap.uuid)) {
                HollowInfo h = snap.copy();
                h.loaded = false;
                h.kept = st.keepAllLoaded || st.kept.contains(h.uuid);
                list.add(h);
            }
        }
        if (dirty) {
            st.markDirty();
        }
        return list;
    }

    private static void sendSync(MinecraftServer server, ServerPlayerEntity player, List<HollowInfo> list) {
        DevRegistryState st = DevRegistryState.get(server);
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeBoolean(canUse(server, player));
        buf.writeBoolean(st.swallowEnabled);
        buf.writeBoolean(st.keepAllLoaded);
        buf.writeDouble(st.mobMassPerHealth);
        buf.writeVarInt(list.size());
        for (HollowInfo h : list) {
            h.write(buf);
        }
        ServerPlayNetworking.send(player, DevNetworking.SYNC, buf);
    }

    // ------------------------------------------------------------------ force-loaded chunks

    private static void applyForcedChunks(MinecraftServer server, DevRegistryState st, List<HollowInfo> list) {
        Set<String> desired = new HashSet<>();
        for (HollowInfo h : list) {
            if (h.kept) {
                desired.add(h.dim + "|" + (MathHelper.floor(h.x) >> 4) + "|" + (MathHelper.floor(h.z) >> 4));
            }
        }
        if (desired.equals(st.forcedChunks)) {
            return;
        }
        for (String key : desired) {
            if (!st.forcedChunks.contains(key)) {
                setForced(server, key, true);
            }
        }
        for (String key : new ArrayList<>(st.forcedChunks)) {
            if (!desired.contains(key)) {
                setForced(server, key, false);
            }
        }
        st.forcedChunks.clear();
        st.forcedChunks.addAll(desired);
        st.markDirty();
    }

    private static void setForced(MinecraftServer server, String key, boolean forced) {
        try {
            String[] p = key.split("\\|");
            RegistryKey<World> worldKey = RegistryKey.of(RegistryKeys.WORLD, new Identifier(p[0]));
            ServerWorld world = server.getWorld(worldKey);
            if (world != null) {
                world.setChunkForced(Integer.parseInt(p[1]), Integer.parseInt(p[2]), forced);
            }
        } catch (Exception e) {
            HollowMod.LOGGER.warn("[HollowMod] Could not change forced chunk {}: {}", key, e.toString());
        }
    }

    // ------------------------------------------------------------------ actions

    private static void handleAction(MinecraftServer server, ServerPlayerEntity player, UUID id, String action,
                                     double a, double b, double c, String s) {
        if (!canUse(server, player)) {
            feedback(player, true, "You need operator permission (level 2) to use the Hollow dev tools.");
            return;
        }
        try {
            if (HollowInfo.NONE.equals(id)) {
                String result = handleGlobal(server, player, action, a, b, c, s);
                if (result != null) {
                    feedback(player, false, result);
                }
                return;
            }
            HollowCoreEntity core = HollowSwallow.findCore(id);
            DevRegistryState st = DevRegistryState.get(server);
            if (core == null) {
                // actions that work even when the Hollow is not loaded
                if ("keep".equals(action)) {
                    setKept(st, id, a > 0.5);
                    feedback(player, false, a > 0.5 ? "Hollow will be kept loaded." : "Hollow is no longer force-loaded.");
                } else if ("tp_me".equals(action) || "forget".equals(action)) {
                    HollowInfo snap = st.snapshots.get(id);
                    if (snap == null) {
                        feedback(player, true, "That Hollow is not known any more.");
                    } else if ("forget".equals(action)) {
                        st.snapshots.remove(id);
                        st.kept.remove(id);
                        st.markDirty();
                        feedback(player, false, "Forgot the saved data of an unloaded Hollow.");
                    } else {
                        teleportPlayerNear(server, player, snap.dim, snap.x, snap.y, snap.z, snap.radius);
                        feedback(player, false, "Teleported to the saved position of an unloaded Hollow.");
                    }
                } else {
                    feedback(player, true, "That Hollow is not loaded. Teleport next to it (Teleport me) or turn on Keep loaded.");
                }
                return;
            }
            String result = handleCoreAction(server, player, core, st, action, a, b, c, s);
            if (result != null) {
                feedback(player, result.startsWith("!"), result.startsWith("!") ? result.substring(1) : result);
            }
        } catch (Exception e) {
            HollowMod.LOGGER.warn("[HollowMod] Dev action '{}' failed", action, e);
            feedback(player, true, "Action '" + action + "' failed: " + e);
        }
    }

    /** Returns a message to show. A leading "!" marks an error. */
    private static String handleCoreAction(MinecraftServer server, ServerPlayerEntity player, HollowCoreEntity core,
                                           DevRegistryState st, String action, double a, double b, double c, String s) {
        String name = "Hollow " + core.getUuid().toString().substring(0, 8);
        switch (action) {
            case "size" -> {
                core.setSizeInstant((int) Math.round(a));
                return name + ": size set to " + (int) Math.round(a);
            }
            case "maxradius" -> {
                core.setMaxRadiusExact(a);
                return name + ": max radius set to " + (int) Math.round(a);
            }
            case "freeze" -> {
                core.setGrowthFrozen(a > 0.5);
                return name + ": growth " + (a > 0.5 ? "FROZEN" : "running");
            }
            case "speed" -> {
                core.setGrowthTickInterval((int) Math.round(a));
                return name + ": +1 radius every " + (int) Math.round(a) + " ticks";
            }
            case "activity" -> {
                core.applyEtherActivityDelta(a - core.getEtherActivity());
                return name + ": Ether Activity = " + Math.round(a) + "%";
            }
            case "gauge" -> {
                core.setZenlessLimitGauge(a);
                return name + ": Zenless gauge = " + Math.round(a) + "%";
            }
            case "overflow" -> {
                Vec3d pos = c > 0.5 ? new Vec3d(a, core.getY(), b) : null;
                String err = core.devOverflow(pos, "force".equals(s));
                if (err != null) {
                    return "!" + err;
                }
                return name + ": Overflow! A companion Hollow was born"
                        + (pos != null ? " at " + Math.round(a) + ", " + Math.round(b) : " at a random spot") + ".";
            }
            case "collapse" -> {
                if (a <= -1.5) {
                    HollowCollapse.cancel(core);
                    return name + ": collapse cancelled.";
                }
                if (a < 0.5 && a > -0.5) {
                    // instant: start with 1 tick left
                    HollowCollapse.begin(core, 1);
                    return name + ": collapsing NOW.";
                }
                HollowCollapse.begin(core, (int) Math.round(a));
                return name + ": collapse countdown started (" + ((int) Math.round(a) > 0 ? Math.round(a) / 20 + " s" : "random 3-5 min") + ").";
            }
            case "delete" -> {
                core.discard();
                return name + ": deleted.";
            }
            case "move" -> {
                ServerWorld world = (ServerWorld) core.getWorld();
                world.getChunk(MathHelper.floor(a) >> 4, MathHelper.floor(c) >> 4);
                core.moveCoreTo(a, b, c);
                return name + ": moved to " + Math.round(a) + ", " + Math.round(b) + ", " + Math.round(c);
            }
            case "keep" -> {
                setKept(st, core.getUuid(), a > 0.5);
                return name + (a > 0.5 ? ": kept loaded (its chunk is force-loaded)." : ": no longer force-loaded.");
            }
            case "tp_me" -> {
                teleportPlayerNear(server, player, core.getWorld().getRegistryKey().getValue().toString(),
                        core.getX(), core.getY(), core.getZ(), core.getCurrentRadius());
                return "Teleported next to " + name;
            }
            case "tp_enter" -> {
                HollowDimensionEvents.teleportToHollowDimension(player, core);
                return "Entered " + name + " (sub-region in the Hollow dimension).";
            }
            case "swallow" -> {
                int n = HollowSwallow.swallowNearby(server, core, 64);
                return name + ": swallowed " + n + " creature(s) now.";
            }
            case "spawn_mobs" -> {
                int n = spawnTestMobs(core, (int) Math.max(1, Math.min(32, a)));
                return name + ": spawned " + n + " test cows inside the dome.";
            }
            default -> {
                return "!Unknown action: " + action;
            }
        }
    }

    private static String handleGlobal(MinecraftServer server, ServerPlayerEntity player, String action,
                                       double a, double b, double c, String s) {
        DevRegistryState st = DevRegistryState.get(server);
        switch (action) {
            case "spawn_hollow" -> {
                ServerWorld world = player.getServerWorld();
                double x = Double.isNaN(a) ? player.getX() : a;
                double y = Double.isNaN(b) ? player.getY() : b;
                double z = Double.isNaN(c) ? player.getZ() : c;
                world.getChunk(MathHelper.floor(x) >> 4, MathHelper.floor(z) >> 4);
                HollowCoreEntity core = new HollowCoreEntity(ModEntities.HOLLOW_CORE_ENTITY, world);
                core.setPosition(x, y, z);
                world.spawnEntity(core);
                return "Spawned a Hollow at " + Math.round(x) + ", " + Math.round(y) + ", " + Math.round(z);
            }
            case "spawn_ethereal" -> {
                ServerWorld world = player.getServerWorld();
                EtherealEntity e = new EtherealEntity(ModEntities.ETHEREAL_ENTITY, world);
                e.refreshPositionAndAngles(player.getX() + 3.0, player.getY(), player.getZ(), 0.0F, 0.0F);
                world.spawnEntity(e);
                return "Spawned an Ethereal next to you.";
            }
            case "setting" -> {
                switch (s) {
                    case "swallow" -> st.swallowEnabled = a > 0.5;
                    case "keepall" -> st.keepAllLoaded = a > 0.5;
                    case "mobmass" -> st.mobMassPerHealth = Math.max(0.0, Math.min(2.0, a));
                    default -> {
                        return "Unknown setting: " + s;
                    }
                }
                st.markDirty();
                return "Setting " + s + " = " + (s.equals("mobmass") ? String.format("%.3f", a) : (a > 0.5 ? "on" : "off"));
            }
            case "enter_nearest" -> {
                HollowCoreEntity nearest = null;
                double best = Double.MAX_VALUE;
                for (HollowCoreEntity core : HollowCoreEntity.getActiveCores()) {
                    if (core.getWorld() != player.getWorld()) {
                        continue;
                    }
                    double d = core.squaredDistanceTo(player);
                    if (d < best) {
                        best = d;
                        nearest = core;
                    }
                }
                if (nearest == null) {
                    return "No Hollow in this dimension.";
                }
                HollowDimensionEvents.teleportToHollowDimension(player, nearest);
                return "Entered the nearest Hollow.";
            }
            default -> {
                return "Unknown global action: " + action;
            }
        }
    }

    private static void setKept(DevRegistryState st, UUID id, boolean kept) {
        if (kept) {
            st.kept.add(id);
        } else {
            st.kept.remove(id);
        }
        st.markDirty();
    }

    private static void teleportPlayerNear(MinecraftServer server, ServerPlayerEntity player, String dim,
                                           double x, double y, double z, double radius) {
        ServerWorld target = server.getWorld(RegistryKey.of(RegistryKeys.WORLD, new Identifier(dim)));
        if (target == null) {
            target = player.getServerWorld();
        }
        double tx = x + radius + 8.0;
        target.getChunk(MathHelper.floor(tx) >> 4, MathHelper.floor(z) >> 4);
        double ty = Math.max(y, target.getTopY(net.minecraft.world.Heightmap.Type.MOTION_BLOCKING,
                MathHelper.floor(tx), MathHelper.floor(z)));
        player.teleport(target, tx, ty, z, player.getYaw(), player.getPitch());
    }

    private static int spawnTestMobs(HollowCoreEntity core, int count) {
        if (!(core.getWorld() instanceof ServerWorld world)) {
            return 0;
        }
        double radius = Math.max(4.0, core.getCurrentRadius() * 0.7);
        int spawned = 0;
        for (int i = 0; i < count; i++) {
            double angle = world.random.nextDouble() * Math.PI * 2.0;
            double dist = world.random.nextDouble() * radius;
            double x = core.getX() + Math.cos(angle) * dist;
            double z = core.getZ() + Math.sin(angle) * dist;
            world.getChunk(MathHelper.floor(x) >> 4, MathHelper.floor(z) >> 4);
            int ground = world.getTopY(net.minecraft.world.Heightmap.Type.MOTION_BLOCKING, MathHelper.floor(x), MathHelper.floor(z));
            double y = Math.min(Math.max(ground, world.getBottomY() + 2), core.getY() + radius * 0.5);
            MobEntity cow = (MobEntity) EntityType.COW.create(world);
            if (cow != null) {
                cow.refreshPositionAndAngles(x, y, z, world.random.nextFloat() * 360.0F, 0.0F);
                world.spawnEntity(cow);
                spawned++;
            }
        }
        return spawned;
    }

    private DevServer() {
    }
}
