package com.hollowmod.dev;

import com.hollowmod.HollowMod;
import com.hollowmod.entity.HollowCoreEntity;
import com.hollowmod.registry.ModDimensions;
import com.hollowmod.state.HollowWorldState;
import net.minecraft.entity.damage.DamageSource;
import net.minecraft.entity.damage.DamageType;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

/**
 * A Hollow collapses: a countdown (3 to 5 minutes, random, so it cannot be memorised) starts. Players who are inside
 * this Hollow get warnings. When it reaches zero, everyone still inside dies of "compressed into a singularity"
 * and the Hollow core disappears. Leaving through an exit portal before that saves you.
 * Started from the dev menu (Collapse) -- it is not triggered automatically yet.
 */
public final class HollowCollapse {

    /** Damage type "hollowmod:collapse" (see data/hollowmod/damage_type/collapse.json and lang death.attack.hollowmod.collapse). */
    public static final RegistryKey<DamageType> DAMAGE =
            RegistryKey.of(RegistryKeys.DAMAGE_TYPE, new Identifier(HollowMod.MOD_ID, "collapse"));

    private static final int MIN_TICKS = 20 * 60 * 3;
    private static final int MAX_TICKS = 20 * 60 * 5;

    /** Starts the countdown. ticks <= 0 means: pick a random 3-5 minutes. */
    public static void begin(HollowCoreEntity core, int ticks) {
        int t = ticks > 0 ? ticks : MIN_TICKS + core.getWorld().random.nextInt(MAX_TICKS - MIN_TICKS + 1);
        core.setCollapseTicksLeft(t);
    }

    public static void cancel(HollowCoreEntity core) {
        core.setCollapseTicksLeft(-1);
    }

    /** Called every server tick by the Hollow core while a collapse is running. */
    public static void tick(HollowCoreEntity core) {
        int left = core.getCollapseTicksLeft();
        if (left < 0 || !(core.getWorld() instanceof ServerWorld)) {
            return;
        }
        MinecraftServer server = core.getServer();
        if (server == null) {
            return;
        }

        if (left == 0) {
            finish(core, server);
            return;
        }
        core.setCollapseTicksLeft(left - 1);

        // warnings once a second for the players inside this Hollow
        if (left % 20 == 0) {
            int seconds = left / 20;
            for (ServerPlayerEntity p : playersInside(server, core)) {
                p.sendMessage(Text.literal("\u00a7cThe Hollow is collapsing... " + (seconds / 60) + ":"
                        + String.format("%02d", seconds % 60) + " to find the exit"), true);
                if (seconds <= 20) {
                    p.addStatusEffect(new StatusEffectInstance(StatusEffects.NAUSEA, 60, 0, false, false, false));
                }
                if (seconds <= 10) {
                    p.addStatusEffect(new StatusEffectInstance(StatusEffects.DARKNESS, 60, 0, false, false, false));
                }
            }
        }
    }

    private static List<ServerPlayerEntity> playersInside(MinecraftServer server, HollowCoreEntity core) {
        List<ServerPlayerEntity> result = new ArrayList<>();
        ServerWorld hollowWorld = server.getWorld(ModDimensions.HOLLOW_DIMENSION_KEY);
        if (hollowWorld == null) {
            return result;
        }
        HollowWorldState state = HollowWorldState.get(server);
        for (ServerPlayerEntity p : hollowWorld.getPlayers()) {
            if (core.getUuid().equals(state.getCurrentHollow(p.getUuid()))) {
                result.add(p);
            }
        }
        return result;
    }

    private static void finish(HollowCoreEntity core, MinecraftServer server) {
        HollowWorldState state = HollowWorldState.get(server);
        int killed = 0;
        for (ServerPlayerEntity p : playersInside(server, core)) {
            DamageSource source = p.getServerWorld().getDamageSources().create(DAMAGE);
            state.clearCurrentHollow(p.getUuid());
            p.damage(source, Float.MAX_VALUE);
            killed++;
        }
        DevServer.note(server, false, "Hollow " + core.getUuid().toString().substring(0, 8)
                + " collapsed. Players compressed: " + killed);
        core.discard();
    }

    private HollowCollapse() {
    }
}
