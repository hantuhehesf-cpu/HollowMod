package com.hollowmod.dev;

import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtElement;
import net.minecraft.nbt.NbtList;
import net.minecraft.nbt.NbtString;
import net.minecraft.server.MinecraftServer;
import net.minecraft.world.PersistentState;

import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

/**
 * Saved with the world (same pattern as HollowWorldState). It lets the dev map show Hollows that are not loaded right now,
 * remembers which Hollows are "kept loaded", and stores the server-side dev settings.
 */
public class DevRegistryState extends PersistentState {

    private static final String STATE_ID = "hollowmod_dev_registry";

    /** Last known data of every Hollow, by id. Removed when the Hollow is really destroyed. */
    public final Map<UUID, HollowInfo> snapshots = new LinkedHashMap<>();
    /** Hollows whose chunk is force-loaded. */
    public final Set<UUID> kept = new HashSet<>();
    /** Chunks this mod force-loaded, as "dimension|chunkX|chunkZ", so stale ones can be released. */
    public final Set<String> forcedChunks = new HashSet<>();
    /** Mass from deaths that happened while the Hollow was not loaded. Applied when it loads again. */
    public final Map<UUID, Double> pendingMass = new HashMap<>();

    // ---- server dev settings (change them from the dev menu) ----
    public boolean swallowEnabled = true;
    public boolean keepAllLoaded = false;
    /** Mass added to the Hollow per health point of a swallowed creature that dies. 1.0 mass = 0.5% Ether Activity. */
    public double mobMassPerHealth = 0.03D;

    public static DevRegistryState get(MinecraftServer server) {
        return server.getOverworld().getPersistentStateManager().getOrCreate(
                DevRegistryState::fromNbt,
                DevRegistryState::new,
                STATE_ID);
    }

    public static DevRegistryState fromNbt(NbtCompound nbt) {
        DevRegistryState s = new DevRegistryState();
        NbtList snaps = nbt.getList("Snapshots", NbtElement.COMPOUND_TYPE);
        for (int i = 0; i < snaps.size(); i++) {
            HollowInfo h = HollowInfo.fromNbt(snaps.getCompound(i));
            s.snapshots.put(h.uuid, h);
        }
        NbtList keptList = nbt.getList("Kept", NbtElement.INT_ARRAY_TYPE);
        for (int i = 0; i < keptList.size(); i++) {
            s.kept.add(net.minecraft.nbt.NbtHelper.toUuid(keptList.get(i)));
        }
        NbtList forced = nbt.getList("Forced", NbtElement.STRING_TYPE);
        for (int i = 0; i < forced.size(); i++) {
            s.forcedChunks.add(forced.getString(i));
        }
        NbtList pending = nbt.getList("Pending", NbtElement.COMPOUND_TYPE);
        for (int i = 0; i < pending.size(); i++) {
            NbtCompound c = pending.getCompound(i);
            s.pendingMass.put(c.getUuid("Id"), c.getDouble("Mass"));
        }
        if (nbt.contains("SwallowEnabled")) {
            s.swallowEnabled = nbt.getBoolean("SwallowEnabled");
        }
        if (nbt.contains("KeepAll")) {
            s.keepAllLoaded = nbt.getBoolean("KeepAll");
        }
        if (nbt.contains("MobMass")) {
            s.mobMassPerHealth = nbt.getDouble("MobMass");
        }
        return s;
    }

    @Override
    public NbtCompound writeNbt(NbtCompound nbt) {
        NbtList snaps = new NbtList();
        for (HollowInfo h : snapshots.values()) {
            snaps.add(h.toNbt());
        }
        nbt.put("Snapshots", snaps);

        NbtList keptList = new NbtList();
        for (UUID id : kept) {
            keptList.add(net.minecraft.nbt.NbtHelper.fromUuid(id));
        }
        nbt.put("Kept", keptList);

        NbtList forced = new NbtList();
        for (String f : forcedChunks) {
            forced.add(NbtString.of(f));
        }
        nbt.put("Forced", forced);

        NbtList pending = new NbtList();
        for (Map.Entry<UUID, Double> e : pendingMass.entrySet()) {
            NbtCompound c = new NbtCompound();
            c.putUuid("Id", e.getKey());
            c.putDouble("Mass", e.getValue());
            pending.add(c);
        }
        nbt.put("Pending", pending);

        nbt.putBoolean("SwallowEnabled", swallowEnabled);
        nbt.putBoolean("KeepAll", keepAllLoaded);
        nbt.putDouble("MobMass", mobMassPerHealth);
        return nbt;
    }
}
