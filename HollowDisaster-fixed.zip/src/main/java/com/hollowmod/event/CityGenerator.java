package com.hollowmod.event;

import com.hollowmod.HollowMod;
import com.hollowmod.maze.MazeConfig;
import com.hollowmod.registry.ModDimensions;
import com.hollowmod.state.HollowWorldState;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.block.Block;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.structure.StructurePlacementData;
import net.minecraft.structure.StructureTemplate;
import net.minecraft.structure.processor.BlockRotStructureProcessor;
import net.minecraft.util.BlockMirror;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3i;

import java.util.HashSet;
import java.util.Optional;
import java.util.Set;
import java.util.UUID;

/**
 * HOLLOW ENVIRONMENT: ruined city lots on the flat Hollow plain.
 *
 * The sub-region is divided into LOT_PITCH x LOT_PITCH lots (relative to the maze center). When a
 * player is near, lots that haven't been decided yet get a deterministic roll: empty, or one of the
 * hand-built buildings (data/hollowmod/structures/building_1..6.nbt) with a random rotation and a
 * little random damage (BlockRotStructureProcessor integrity). Density is higher near the maze and
 * thinner toward the edge. Lots in the maze zone and around the player spawn stay empty. One building
 * per Hollow per check, so it never hitches. A lot whose .nbt is missing stays undecided until the
 * file exists.
 *
 * Building convention: the BOTTOM layer of the saved structure is placed on the first block above
 * the ground (so include your own floor slab, no dirt underneath).
 */
public final class CityGenerator {

    public static final String[] BUILDINGS = {
            "building_1", "building_2", "building_3", "building_4", "building_5", "building_6"
    };

    private static final int LOT_PITCH = 64;
    private static final int ACTIVATE_RADIUS = 112;
    private static final int CITY_HALF_EXTENT = 320;
    private static final int MAZE_CLEARANCE = 24;
    private static final int SPAWN_CLEARANCE = 48;
    private static final float INTEGRITY = 0.93f;
    private static final int CHECK_INTERVAL_TICKS = 10;

    private static final Set<String> WARNED = new HashSet<>();

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(CityGenerator::tick);
    }

    private static void tick(MinecraftServer server) {
        if (server.getTicks() % CHECK_INTERVAL_TICKS != 0) {
            return;
        }
        ServerWorld world = server.getWorld(ModDimensions.HOLLOW_DIMENSION_KEY);
        if (world == null || world.getPlayers().isEmpty()) {
            return;
        }
        HollowWorldState hs = HollowWorldState.get(server);
        Set<UUID> handled = new HashSet<>();
        for (ServerPlayerEntity p : world.getPlayers()) {
            UUID id = hs.getCurrentHollow(p.getUuid());
            if (id == null || handled.contains(id)) {
                continue;
            }
            if (placeNextLot(world, hs, id, p)) {
                handled.add(id);
            }
        }
    }

    private static long lotKey(int lx, int lz) {
        return ((long) lx << 32) | (lz & 0xFFFFFFFFL);
    }

    /** Looks at the lots around the player and places at most one building. */
    private static boolean placeNextLot(ServerWorld world, HollowWorldState hs, UUID id, ServerPlayerEntity player) {
        int slot = hs.getOrAssignSlot(id);
        BlockPos c = HollowWorldState.slotToSubRegionCenter(slot);
        BlockPos spawnCol = HollowWorldState.slotToFragmentColumn(slot);
        int ground = SubRegionReplicator.groundY(world, hs, id);
        long seed = id.getMostSignificantBits() ^ id.getLeastSignificantBits();

        int px = MathHelper.floor(player.getX());
        int pz = MathHelper.floor(player.getZ());
        int minLx = Math.floorDiv(px - ACTIVATE_RADIUS - c.getX(), LOT_PITCH);
        int maxLx = Math.floorDiv(px + ACTIVATE_RADIUS - c.getX(), LOT_PITCH);
        int minLz = Math.floorDiv(pz - ACTIVATE_RADIUS - c.getZ(), LOT_PITCH);
        int maxLz = Math.floorDiv(pz + ACTIVATE_RADIUS - c.getZ(), LOT_PITCH);
        int mazeHalf = MazeConfig.NX * MazeConfig.CELL / 2 + MAZE_CLEARANCE + LOT_PITCH / 2;

        for (int lz = minLz; lz <= maxLz; lz++) {
            for (int lx = minLx; lx <= maxLx; lx++) {
                long key = lotKey(lx, lz);
                if (hs.isLotDone(id, key)) {
                    continue;
                }
                int x0 = c.getX() + lx * LOT_PITCH;
                int z0 = c.getZ() + lz * LOT_PITCH;
                double cx = x0 + LOT_PITCH / 2.0;
                double cz = z0 + LOT_PITCH / 2.0;

                boolean outsideCity = Math.abs(cx - c.getX()) > CITY_HALF_EXTENT || Math.abs(cz - c.getZ()) > CITY_HALF_EXTENT;
                boolean inMazeZone = Math.max(Math.abs(cx - c.getX()), Math.abs(cz - c.getZ())) < mazeHalf;
                boolean nearSpawn = Math.hypot(cx - spawnCol.getX(), cz - spawnCol.getZ()) < SPAWN_CLEARANCE + LOT_PITCH / 2.0;
                if (outsideCity || inMazeZone || nearSpawn) {
                    hs.markLotDone(id, key);
                    continue;
                }

                java.util.Random rnd = new java.util.Random(seed ^ (key * 0x9E3779B97F4A7C15L));
                double dist = Math.hypot(cx - c.getX(), cz - c.getZ());
                double chance = 0.85 - 0.5 * MathHelper.clamp((dist - 100.0) / 220.0, 0.0, 1.0);
                boolean build = rnd.nextDouble() < chance;
                int index = rnd.nextInt(BUILDINGS.length);
                int rotation = rnd.nextInt(4);
                long placeSeed = rnd.nextLong();
                if (!build) {
                    hs.markLotDone(id, key);
                    continue;
                }

                Optional<StructureTemplate> template =
                        world.getStructureTemplateManager().getTemplate(new Identifier(HollowMod.MOD_ID, BUILDINGS[index]));
                if (template.isEmpty()) {
                    if (WARNED.add(BUILDINGS[index])) {
                        HollowMod.LOGGER.warn("[HollowMod] Missing structure {}; lots using it stay empty until it exists", BUILDINGS[index]);
                    }
                    continue; // stays undecided
                }
                hs.markLotDone(id, key);
                if (place(world, template.get(), rotation, x0, z0, ground, placeSeed)) {
                    return true;
                }
            }
        }
        return false;
    }

    private static boolean place(ServerWorld world, StructureTemplate template, int rotationIndex,
                                 int x0, int z0, int ground, long seed) {
        BlockRotation rotation = BlockRotation.values()[rotationIndex];
        Vec3i size = template.getSize();
        boolean swapped = rotation == BlockRotation.CLOCKWISE_90 || rotation == BlockRotation.COUNTERCLOCKWISE_90;
        int footX = swapped ? size.getZ() : size.getX();
        int footZ = swapped ? size.getX() : size.getZ();
        if (footX > LOT_PITCH - 4 || footZ > LOT_PITCH - 4) {
            HollowMod.LOGGER.warn("[HollowMod] A building is bigger than a lot ({}x{} > {}), skipped", footX, footZ, LOT_PITCH - 4);
            return false;
        }
        // center the footprint in the lot, then shift the pivot so the rotated footprint lands there
        BlockPos min = new BlockPos(x0 + (LOT_PITCH - footX) / 2, ground, z0 + (LOT_PITCH - footZ) / 2);
        BlockPos pos = switch (rotation) {
            case CLOCKWISE_90 -> min.add(size.getZ() - 1, 0, 0);
            case CLOCKWISE_180 -> min.add(size.getX() - 1, 0, size.getZ() - 1);
            case COUNTERCLOCKWISE_90 -> min.add(0, 0, size.getX() - 1);
            default -> min;
        };
        StructurePlacementData data = new StructurePlacementData()
                .setRotation(rotation)
                .setMirror(BlockMirror.NONE)
                .setIgnoreEntities(true)
                .addProcessor(new BlockRotStructureProcessor(INTEGRITY));
        return template.place(world, pos, pos, data, net.minecraft.util.math.random.Random.create(seed), Block.NOTIFY_LISTENERS);
    }

    private CityGenerator() {
    }
}
