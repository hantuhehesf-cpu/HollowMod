package com.hollowmod.event;

import com.hollowmod.entity.HollowCoreEntity;
import com.hollowmod.registry.ModDimensions;
import com.hollowmod.state.HollowWorldState;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerWorldEvents;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.List;

/**
 * Everything here uses plain Fabric API events -- no mixins. Nothing in the mod's spec actually
 * needs a mixin: dome-touch detection has no vanilla collision to hook (the dome is a pure
 * client-side visual with no real hitbox), so it's checked with a cheap per-tick squared-distance
 * pass over active cores x nearby players, same as vanilla itself does for e.g. sweeping-edge
 * attacks. Preferring events over mixins here means this keeps working across Yarn mapping/Loom
 * updates without needing remapped injection points.
 */
public final class HollowDimensionEvents {

    public static void register() {
        ServerTickEvents.END_WORLD_TICK.register(HollowDimensionEvents::checkDomeBoundary);
        ServerWorldEvents.LOAD.register(HollowDimensionEvents::onWorldLoad);
        ServerPlayerEvents.AFTER_RESPAWN.register(HollowDimensionEvents::lockRespawnInsideHollow);
    }

    /** Requirement #3: touching the visual dome wall in the Overworld teleports the player in. */
    private static void checkDomeBoundary(ServerWorld world) {
        if (world.getRegistryKey() != World.OVERWORLD) {
            return;
        }

        // Collect first, teleport after: teleporting a player changes which world they belong
        // to, which would modify world.getPlayers() while we're still iterating it directly
        // (that's what caused the ConcurrentModificationException crash).
        List<ServerPlayerEntity> toTeleport = new ArrayList<>();

        for (HollowCoreEntity core : HollowCoreEntity.getActiveCores()) {
            if (core.getWorld() != world) {
                continue;
            }
            double radius = core.getCurrentRadius();
            if (radius < 1.0D) {
                continue;
            }
            double radiusSq = radius * radius;
            Vec3d center = core.getPos();

            for (ServerPlayerEntity player : world.getPlayers()) {
                if (player.isSpectator()) {
                    continue;
                }
                if (player.getPos().squaredDistanceTo(center) <= radiusSq && !toTeleport.contains(player)) {
                    toTeleport.add(player);
                }
            }
        }

        for (ServerPlayerEntity player : toTeleport) {
            teleportToHollowDimension(player);
        }
    }

    private static void teleportToHollowDimension(ServerPlayerEntity player) {
        MinecraftServer server = player.getServer();
        if (server == null) {
            return;
        }
        ServerWorld hollowWorld = server.getWorld(ModDimensions.HOLLOW_DIMENSION_KEY);
        if (hollowWorld == null) {
            return; // dimension json missing/not loaded -- nothing to do
        }

        // Remember where they came from so the exit portal (and death-respawn lock) can send
        // them back later.
        HollowWorldState.get(server).setReturnPosition(
                player.getUuid(), player.getWorld().getRegistryKey(),
                player.getX(), player.getY(), player.getZ());

        BlockPos spawnPos = findSafeHollowSpawn(hollowWorld);
        player.teleport(hollowWorld, spawnPos.getX() + 0.5, spawnPos.getY(), spawnPos.getZ() + 0.5,
                player.getYaw(), player.getPitch());
    }

    /** Requirement #4: enforce the ~1000x1000 dimension bound as a real vanilla world border. */
    private static void onWorldLoad(MinecraftServer server, ServerWorld world) {
        if (world.getRegistryKey() == ModDimensions.HOLLOW_DIMENSION_KEY) {
            world.getWorldBorder().setCenter(0, 0);
            world.getWorldBorder().setSize(ModDimensions.HOLLOW_BORDER_SIZE);
        }
    }

    /**
     * Requirement #4 ("keluar susah"): vanilla respawn would otherwise pull a player who dies
     * inside the Hollow back to their Overworld bed/anchor/world-spawn, which would trivialize
     * the "find the exit portal" requirement. This keeps them trapped on death too -- the only
     * scripted way out stays HollowExitPortalBlock.
     */
    private static void lockRespawnInsideHollow(ServerPlayerEntity oldPlayer, ServerPlayerEntity newPlayer, boolean alive) {
        if (newPlayer.getServerWorld().getRegistryKey() == ModDimensions.HOLLOW_DIMENSION_KEY) {
            ServerWorld hollowWorld = newPlayer.getServerWorld();
            BlockPos spawnPos = findSafeHollowSpawn(hollowWorld);
            newPlayer.teleport(hollowWorld, spawnPos.getX() + 0.5, spawnPos.getY(), spawnPos.getZ() + 0.5, 0, 0);
        }
    }

    /**
     * The End-based noise settings this dimension reuses generate mostly void with sparse
     * islands, so there is no guarantee solid ground exists at/near the origin. Rather than
     * gamble on natural terrain, this carves out a small guaranteed platform the first time
     * it's needed, so players never fall into empty void on arrival.
     */
    private static BlockPos findSafeHollowSpawn(ServerWorld world) {
        BlockPos anchor = new BlockPos(0, 32, 0);

        // If a platform (or natural ground) is already there from a previous visit, reuse it.
        if (!world.getBlockState(anchor.down()).isAir() && world.getBlockState(anchor).isAir()) {
            return anchor;
        }

        for (int x = -2; x <= 2; x++) {
            for (int z = -2; z <= 2; z++) {
                BlockPos floor = anchor.add(x, -1, z);
                world.setBlockState(floor, Blocks.BLACKSTONE.getDefaultState(), Block.NOTIFY_LISTENERS);
                world.setBlockState(floor.up(), Blocks.AIR.getDefaultState(), Block.NOTIFY_LISTENERS);
                world.setBlockState(floor.up(2), Blocks.AIR.getDefaultState(), Block.NOTIFY_LISTENERS);
            }
        }
        return anchor;
    }

    /**
     * Used when sending a player OUT of the Hollow (exit portal) to make sure their destination
     * isn't still inside some Hollow's current radius -- the return position recorded on entry is
     * literally the point where distance <= radius was true, so returning them there verbatim
     * would make checkDomeBoundary immediately suck them back in the very next tick (worse if the
     * dome grew while they were inside, since the entry point is then even further inside). Pushes
     * them radially outward past every active core's current radius (with a small margin) in the
     * given world, snapping to solid ground at the new XZ via the heightmap.
     */
    public static BlockPos pushOutsideAnyDome(ServerWorld world, double x, double y, double z) {
        boolean pushedByDome = false;

        for (HollowCoreEntity core : HollowCoreEntity.getActiveCores()) {
            if (core.getWorld() != world) {
                continue;
            }
            double safeRadius = core.getCurrentRadius() + 4.0D; // margin against further growth mid-check
            Vec3d center = core.getPos();
            double dx = x - center.x;
            double dy = y - center.y;
            double dz = z - center.z;
            double distSq = dx * dx + dy * dy + dz * dz;

            if (distSq < safeRadius * safeRadius) {
                double dist = Math.sqrt(Math.max(distSq, 1.0e-4));
                double scale = safeRadius / dist;
                x = center.x + dx * scale;
                z = center.z + dz * scale;
                pushedByDome = true;
            }
        }

        int ix = (int) Math.floor(x);
        int iz = (int) Math.floor(z);
        int iy = (int) Math.floor(y);

        // BUGFIX (v1.1.3): previously always snapped Y to world.getTopY(...) (the world's
        // *surface* height) whenever any repositioning was needed. That's wrong for a Hollow
        // placed underground/in a cave -- the dome-push above is ALWAYS triggered for an
        // underground Hollow (the return point near its center is naturally within the push
        // radius), so every underground exit was getting yanked all the way up to the surface at
        // the same X/Z, regardless of how deep the actual cave was. Now it searches for solid
        // footing near the ORIGINAL Y first (both directions), and only falls back to the world
        // surface if nothing usable is found nearby at all.
        if (pushedByDome || !hasStandableGround(world, ix, iy, iz)) {
            iy = findSafeYNear(world, ix, iz, iy);
        }

        return new BlockPos(ix, iy, iz);
    }

    private static boolean hasStandableGround(ServerWorld world, int x, int y, int z) {
        BlockPos below = new BlockPos(x, y - 1, z);
        BlockPos feet = new BlockPos(x, y, z);
        BlockPos head = new BlockPos(x, y + 1, z);
        return !world.getBlockState(below).isAir()
                && world.getBlockState(feet).isAir()
                && world.getBlockState(head).isAir();
    }

    /** Expands outward (up AND down) from preferredY looking for standable footing before giving
     *  up and falling back to the world surface -- keeps an underground exit underground. */
    private static int findSafeYNear(ServerWorld world, int x, int z, int preferredY) {
        int minY = world.getBottomY() + 1;
        int maxY = world.getTopY() - 2; // getTopY() is exclusive in 1.20.1, so -2 leaves room for feet+head

        for (int offset = 0; offset <= 64; offset++) {
            int down = preferredY - offset;
            if (down >= minY && down <= maxY && hasStandableGround(world, x, down, z)) {
                return down;
            }
            if (offset > 0) {
                int up = preferredY + offset;
                if (up >= minY && up <= maxY && hasStandableGround(world, x, up, z)) {
                    return up;
                }
            }
        }

        // Nothing usable found nearby at all -- surface is the last resort, not the default.
        return world.getTopY(net.minecraft.world.Heightmap.Type.MOTION_BLOCKING, x, z);
    }

    private HollowDimensionEvents() {
    }
}
