package com.hollowmod.event;

import com.hollowmod.entity.HollowCoreEntity;
import com.hollowmod.registry.ModDimensions;
import com.hollowmod.state.HollowWorldState;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerWorldEvents;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.ArrayList;
import java.util.List;

/**
 * Everything here uses plain Fabric API events -- no mixins. Nothing in the mod's spec actually
 * needs a mixin: dome-touch detection has no vanilla collision to hook (the dome is a pure
 * client-side visual with no real hitbox), so it's checked with a cheap per-tick squared-distance
 * pass over active cores x nearby players, same as vanilla itself does for e.g. sweeping-edge
 * attacks. Preferring events over mixins here means this keeps working across Yarn mapping/Loom
 * updates without needing remapped injection points.
 */
public final class HollowDimensionEvents {

    public static void register() {
        ServerTickEvents.END_WORLD_TICK.register(HollowDimensionEvents::checkDomeBoundary);
        ServerWorldEvents.LOAD.register(HollowDimensionEvents::onWorldLoad);
        ServerPlayerEvents.AFTER_RESPAWN.register(HollowDimensionEvents::lockRespawnInsideHollow);
    }

    /** Requirement #3: touching the visual dome wall in the Overworld teleports the player in. */
    private static void checkDomeBoundary(ServerWorld world) {
        if (world.getRegistryKey() != World.OVERWORLD) {
            return;
        }

        // Collect first, teleport after: teleporting a player changes which world they belong
        // to, which would modify world.getPlayers() while we're still iterating it directly
        // (that's what caused the ConcurrentModificationException crash).
        List<ServerPlayerEntity> toTeleport = new ArrayList<>();

        for (HollowCoreEntity core : HollowCoreEntity.getActiveCores()) {
            if (core.getWorld() != world) {
                continue;
            }
            double radius = core.getCurrentRadius();
            if (radius < 1.0D) {
                continue;
            }
            double radiusSq = radius * radius;
            Vec3d center = core.getPos();

            for (ServerPlayerEntity player : world.getPlayers()) {
                if (player.isSpectator()) {
                    continue;
                }
                if (player.getPos().squaredDistanceTo(center) <= radiusSq && !toTeleport.contains(player)) {
                    toTeleport.add(player);
                }
            }
        }

        for (ServerPlayerEntity player : toTeleport) {
            teleportToHollowDimension(player);
        }
    }

    private static void teleportToHollowDimension(ServerPlayerEntity player) {
        MinecraftServer server = player.getServer();
        if (server == null) {
            return;
        }
        ServerWorld hollowWorld = server.getWorld(ModDimensions.HOLLOW_DIMENSION_KEY);
        if (hollowWorld == null) {
            return; // dimension json missing/not loaded -- nothing to do
        }

        // Remember where they came from so the exit portal (and death-respawn lock) can send
        // them back later.
        HollowWorldState.get(server).setReturnPosition(
                player.getUuid(), player.getWorld().getRegistryKey(),
                player.getX(), player.getY(), player.getZ());

        BlockPos spawnPos = findSafeHollowSpawn(hollowWorld);
        player.teleport(hollowWorld, spawnPos.getX() + 0.5, spawnPos.getY(), spawnPos.getZ() + 0.5,
                player.getYaw(), player.getPitch());
    }

    /** Requirement #4: enforce the ~1000x1000 dimension bound as a real vanilla world border. */
    private static void onWorldLoad(MinecraftServer server, ServerWorld world) {
        if (world.getRegistryKey() == ModDimensions.HOLLOW_DIMENSION_KEY) {
            world.getWorldBorder().setCenter(0, 0);
            world.getWorldBorder().setSize(ModDimensions.HOLLOW_BORDER_SIZE);
        }
    }

    /**
     * Requirement #4 ("keluar susah"): vanilla respawn would otherwise pull a player who dies
     * inside the Hollow back to their Overworld bed/anchor/world-spawn, which would trivialize
     * the "find the exit portal" requirement. This keeps them trapped on death too -- the only
     * scripted way out stays HollowExitPortalBlock.
     */
    private static void lockRespawnInsideHollow(ServerPlayerEntity oldPlayer, ServerPlayerEntity newPlayer, boolean alive) {
        if (newPlayer.getServerWorld().getRegistryKey() == ModDimensions.HOLLOW_DIMENSION_KEY) {
            ServerWorld hollowWorld = newPlayer.getServerWorld();
            BlockPos spawnPos = findSafeHollowSpawn(hollowWorld);
            newPlayer.teleport(hollowWorld, spawnPos.getX() + 0.5, spawnPos.getY(), spawnPos.getZ() + 0.5, 0, 0);
        }
    }

    /**
     * The End-based noise settings this dimension reuses generate mostly void with sparse
     * islands, so there is no guarantee solid ground exists at/near the origin. Rather than
     * gamble on natural terrain, this carves out a small guaranteed platform the first time
     * it's needed, so players never fall into empty void on arrival.
     */
    private static BlockPos findSafeHollowSpawn(ServerWorld world) {
        BlockPos anchor = new BlockPos(0, 32, 0);

        // If a platform (or natural ground) is already there from a previous visit, reuse it.
        if (!world.getBlockState(anchor.down()).isAir() && world.getBlockState(anchor).isAir()) {
            return anchor;
        }

        for (int x = -2; x <= 2; x++) {
            for (int z = -2; z <= 2; z++) {
                BlockPos floor = anchor.add(x, -1, z);
                world.setBlockState(floor, Blocks.BLACKSTONE.getDefaultState(), Block.NOTIFY_LISTENERS);
                world.setBlockState(floor.up(), Blocks.AIR.getDefaultState(), Block.NOTIFY_LISTENERS);
                world.setBlockState(floor.up(2), Blocks.AIR.getDefaultState(), Block.NOTIFY_LISTENERS);
            }
        }
        return anchor;
    }

    private HollowDimensionEvents() {
    }
}
