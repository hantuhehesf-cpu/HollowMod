package com.hollowmod.event;

import com.hollowmod.entity.HollowCoreEntity;
import com.hollowmod.registry.ModDimensions;
import com.hollowmod.state.HollowWorldState;
import net.fabricmc.fabric.api.entity.event.v1.ServerPlayerEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerWorldEvents;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

/**
 * Everything here uses plain Fabric API events -- no mixins. Nothing in the mod's spec actually
 * needs a mixin: dome-touch detection has no vanilla collision to hook (the dome is a pure
 * client-side visual with no real hitbox), so it's checked with a cheap per-tick squared-distance
 * pass over active cores x nearby players, same as vanilla itself does for e.g. sweeping-edge
 * attacks. Preferring events over mixins here means this keeps working across Yarn mapping/Loom
 * updates without needing remapped injection points.
 */
public final class HollowDimensionEvents {

    public static void register() {
        ServerTickEvents.END_WORLD_TICK.register(HollowDimensionEvents::checkDomeBoundary);
        ServerWorldEvents.LOAD.register(HollowDimensionEvents::onWorldLoad);
        ServerPlayerEvents.AFTER_RESPAWN.register(HollowDimensionEvents::lockRespawnInsideHollow);
    }

    /** Requirement #3: touching the visual dome wall in the Overworld teleports the player in. */
    private static void checkDomeBoundary(ServerWorld world) {
        if (world.getRegistryKey() != World.OVERWORLD) {
            return;
        }
        for (HollowCoreEntity core : HollowCoreEntity.getActiveCores()) {
            if (core.getWorld() != world) {
                continue;
            }
            double radius = core.getCurrentRadius();
            if (radius < 1.0D) {
                continue;
            }
            double radiusSq = radius * radius;
            Vec3d center = core.getPos();

            for (ServerPlayerEntity player : world.getPlayers()) {
                if (player.isSpectator()) {
                    continue;
                }
                if (player.getPos().squaredDistanceTo(center) <= radiusSq) {
                    teleportToHollowDimension(player);
                }
            }
        }
    }

    private static void teleportToHollowDimension(ServerPlayerEntity player) {
        MinecraftServer server = player.getServer();
        if (server == null) {
            return;
        }
        ServerWorld hollowWorld = server.getWorld(ModDimensions.HOLLOW_DIMENSION_KEY);
        if (hollowWorld == null) {
            return; // dimension json missing/not loaded -- nothing to do
        }

        // Remember where they came from so the exit portal (and death-respawn lock) can send
        // them back later.
        HollowWorldState.get(server).setReturnPosition(
                player.getUuid(), player.getWorld().getRegistryKey(),
                player.getX(), player.getY(), player.getZ());

        BlockPos spawnPos = findSafeHollowSpawn(hollowWorld);
        player.teleport(hollowWorld, spawnPos.getX() + 0.5, spawnPos.getY(), spawnPos.getZ() + 0.5,
                player.getYaw(), player.getPitch());
    }

    /** Requirement #4: enforce the ~1000x1000 dimension bound as a real vanilla world border. */
    private static void onWorldLoad(MinecraftServer server, ServerWorld world) {
        if (world.getRegistryKey() == ModDimensions.HOLLOW_DIMENSION_KEY) {
            world.getWorldBorder().setCenter(0, 0);
            world.getWorldBorder().setSize(ModDimensions.HOLLOW_BORDER_SIZE);
        }
    }

    /**
     * Requirement #4 ("keluar susah"): vanilla respawn would otherwise pull a player who dies
     * inside the Hollow back to their Overworld bed/anchor/world-spawn, which would trivialize
     * the "find the exit portal" requirement. This keeps them trapped on death too -- the only
     * scripted way out stays HollowExitPortalBlock.
     */
    private static void lockRespawnInsideHollow(ServerPlayerEntity oldPlayer, ServerPlayerEntity newPlayer, boolean alive) {
        if (newPlayer.getServerWorld().getRegistryKey() == ModDimensions.HOLLOW_DIMENSION_KEY) {
            ServerWorld hollowWorld = newPlayer.getServerWorld();
            BlockPos spawnPos = findSafeHollowSpawn(hollowWorld);
            newPlayer.teleport(hollowWorld, spawnPos.getX() + 0.5, spawnPos.getY(), spawnPos.getZ() + 0.5, 0, 0);
        }
    }

    /**
     * Simple top-of-world-at-origin placeholder. Replace with real logic (e.g. searching
     * outward from origin for a solid, unobstructed surface) once your Hollow terrain exists --
     * the End-based noise settings this dimension reuses are mostly void, so "top motion blocking
     * block at (0,0)" may sometimes be far below the player; treat this as a TODO marker.
     */
    private static BlockPos findSafeHollowSpawn(ServerWorld world) {
        BlockPos origin = new BlockPos(0, 0, 0);
        int topY = world.getTopY(net.minecraft.world.Heightmap.Type.MOTION_BLOCKING, origin.getX(), origin.getZ());
        return new BlockPos(origin.getX(), Math.max(topY, world.getBottomY() + 4), origin.getZ());
    }

    private HollowDimensionEvents() {
    }
}
