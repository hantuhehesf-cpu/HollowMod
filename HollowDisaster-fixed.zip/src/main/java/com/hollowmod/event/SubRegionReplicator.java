package com.hollowmod.event;

import com.hollowmod.HollowMod;
import com.hollowmod.registry.ModDimensions;
import com.hollowmod.state.FragmentLog;
import com.hollowmod.state.HollowWorldState;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.FluidBlock;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.world.Heightmap;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * SYSTEM 5 (fixed): recreates whatever a Hollow eats as floating fragments in its sub-region.
 *
 * Why the old version showed nothing: it only placed a block if that chunk was ALREADY loaded in
 * HollowDimension, and the sub-region sits ~10,000 blocks away, so while you watch the Hollow
 * eat in the Overworld nothing is loaded there and every block was silently dropped.
 *
 * Now: if someone is inside the sub-region and the target chunk is loaded, the block is placed
 * immediately. Otherwise it goes into a persistent, capped backlog (FragmentLog) that is replayed
 * at PLACE_PER_TICK blocks/tick as soon as a player is inside that Hollow's sub-region.
 *
 * Height: fragments are centered FRAGMENT_LIFT blocks above the measured ground at the sub-region
 * center (see HollowWorldState). A small column around the spawn point is kept clear.
 */
public final class SubRegionReplicator {

    /** Replay budget per server tick (same spirit as the devour time-slicing). */
    private static final int PLACE_PER_TICK = 400;

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(SubRegionReplicator::tick);
    }

    /**
     * Ground height (feet Y) at this Hollow's sub-region center. Measured once (loading the
     * chunk if needed) and stored, so later fragments in that column can't change the answer.
     * Also the Y the player spawns at.
     */
    public static int groundY(ServerWorld hollowWorld, HollowWorldState hs, UUID hollowId) {
        Integer stored = hs.getFragmentGroundY(hollowId);
        if (stored != null) {
            return stored;
        }
        BlockPos c = HollowWorldState.slotToSubRegionCenter(hs.getOrAssignSlot(hollowId));
        hollowWorld.getChunk(c.getX() >> 4, c.getZ() >> 4); // World#getTopY returns bottom Y for unloaded chunks
        int top = hollowWorld.getTopY(Heightmap.Type.MOTION_BLOCKING, c.getX(), c.getZ());
        int y = Math.max(top, hollowWorld.getBottomY() + 4);
        hs.setFragmentGroundY(hollowId, y);
        return y;
    }

    /** Called by HollowCoreEntity for every block it eats. relative = eaten pos - Hollow center. */
    public static void onBlockEaten(MinecraftServer server, UUID hollowId, BlockPos relative, BlockState state) {
        if (state.getBlock() instanceof FluidBlock) {
            return; // placed fluid sources would start flowing in the sub-region: skip
        }
        ServerWorld hollowWorld = server.getWorld(ModDimensions.HOLLOW_DIMENSION_KEY);
        if (hollowWorld == null) {
            return;
        }
        HollowWorldState hs = HollowWorldState.get(server);

        FragmentLog existing = hs.peekFragmentLog(hollowId);
        boolean backlog = existing != null && existing.hasPending();
        Integer ground = hs.getFragmentGroundY(hollowId);

        // Direct placement only when: nothing is queued, the ground height is already known (so
        // we never force-load the far-away chunk from here), someone is inside, chunk is loaded.
        if (!backlog && ground != null && isOccupied(hollowWorld, hs, hollowId)) {
            int slot = hs.getOrAssignSlot(hollowId);
            BlockPos anchor = HollowWorldState.slotToFragmentAnchor(slot, ground);
            BlockPos target = anchor.add(relative);
            if (hollowWorld.isChunkLoaded(target.getX() >> 4, target.getZ() >> 4)) {
                place(hollowWorld, target, state, HollowWorldState.slotToSubRegionCenter(slot), ground);
                return;
            }
        }

        if (hs.getFragmentLog(hollowId).add(relative, state)) {
            hs.markDirty();
        }
    }

    private static boolean isOccupied(ServerWorld hollowWorld, HollowWorldState hs, UUID hollowId) {
        for (ServerPlayerEntity p : hollowWorld.getPlayers()) {
            if (hollowId.equals(hs.getCurrentHollow(p.getUuid()))) {
                return true;
            }
        }
        return false;
    }

    private static void tick(MinecraftServer server) {
        ServerWorld hollowWorld = server.getWorld(ModDimensions.HOLLOW_DIMENSION_KEY);
        if (hollowWorld == null || hollowWorld.getPlayers().isEmpty()) {
            return;
        }
        HollowWorldState hs = HollowWorldState.get(server);

        Set<UUID> hollowsWithPlayers = new HashSet<>();
        for (ServerPlayerEntity p : hollowWorld.getPlayers()) {
            UUID id = hs.getCurrentHollow(p.getUuid());
            if (id != null) {
                hollowsWithPlayers.add(id);
            }
        }

        for (UUID id : hollowsWithPlayers) {
            FragmentLog log = hs.peekFragmentLog(id);
            if (log == null || !log.hasPending()) {
                continue;
            }
            int slot = hs.getOrAssignSlot(id);
            int ground = groundY(hollowWorld, hs, id);
            BlockPos center = HollowWorldState.slotToSubRegionCenter(slot);
            BlockPos anchor = HollowWorldState.slotToFragmentAnchor(slot, ground);
            int budget = PLACE_PER_TICK;
            while (budget-- > 0 && log.hasPending()) {
                long entry = log.next();
                place(hollowWorld, anchor.add(FragmentLog.relativePos(entry)), log.stateOf(entry), center, ground);
            }
            if (!log.hasPending()) {
                log.reset();
                HollowMod.LOGGER.info("[HollowMod] Sub-region backlog fully replayed for Hollow {}", id);
            }
            hs.markDirty();
        }
    }

    private static void place(ServerWorld world, BlockPos target, BlockState state, BlockPos center, int groundY) {
        if (world.isOutOfHeightLimit(target.getY())) {
            return;
        }
        // Keep the spawn pocket (a small column right above the spawn point) free of fragments.
        int r = HollowWorldState.SPAWN_CLEAR_RADIUS;
        if (Math.abs(target.getX() - center.getX()) <= r
                && Math.abs(target.getZ() - center.getZ()) <= r
                && target.getY() >= groundY && target.getY() <= groundY + 3) {
            return;
        }
        world.setBlockState(target, state, Block.NOTIFY_LISTENERS);
    }

    private SubRegionReplicator() {
    }
}
