package com.hollowmod.network;

import com.hollowmod.HollowMod;
import net.minecraft.util.Identifier;

public final class HollowNetworking {

    /** Server -> client: the scan map snapshot that opens the Carrot screen. */
    public static final Identifier CARROT_MAP = new Identifier(HollowMod.MOD_ID, "carrot_map");

    private HollowNetworking() {
    }
}
