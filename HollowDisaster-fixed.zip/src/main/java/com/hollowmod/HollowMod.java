package com.hollowmod;

import com.hollowmod.entity.HollowCoreEntity;
import com.hollowmod.event.HollowDimensionEvents;
import com.hollowmod.registry.ModBlocks;
import com.hollowmod.registry.ModCommands;
import com.hollowmod.registry.ModEntities;
import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Common (server + client) entrypoint for the Hollow mod.
 *
 * Design notes for the mobile / PojavLauncher + MobileGlues target:
 *  - All world-mutating logic in this mod (block clearing, item absorption, boundary checks)
 *    is written to stay strictly within Fabric/vanilla APIs that go through Minecraft's own
 *    rendering & world abstractions. Nothing here calls LWJGL/GL11/GL30 directly, so it should
 *    behave the same under MobileGlues' OpenGL ES 3.2 translation layer as it does on desktop.
 *  - Everything that can be done with a data-driven datapack (dimension, dimension_type, biome
 *    spawn lists) is done that way instead of in Java, which keeps the mod lighter and easier
 *    to tweak without recompiling.
 */
public class HollowMod implements ModInitializer {

    public static final String MOD_ID = "hollowmod";
    public static final Logger LOGGER = LoggerFactory.getLogger("HollowMod");

    @Override
    public void onInitialize() {
        LOGGER.info("[HollowMod] Initializing Hollow anomaly systems...");

        ModBlocks.register();
        ModEntities.register();
        ModCommands.register();
        HollowDimensionEvents.register();
        HollowCoreEntity.registerTracking();

        LOGGER.info("[HollowMod] Ready. Spawn a HollowCoreEntity to begin an anomaly.");
    }
}
