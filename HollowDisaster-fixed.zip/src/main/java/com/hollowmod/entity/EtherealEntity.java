package com.hollowmod.entity;

import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnReason;
import net.minecraft.entity.attribute.DefaultAttributeContainer;
import net.minecraft.entity.attribute.EntityAttributes;
import net.minecraft.entity.ai.goal.ActiveTargetGoal;
import net.minecraft.entity.ai.goal.LookAroundGoal;
import net.minecraft.entity.ai.goal.LookAtEntityGoal;
import net.minecraft.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.entity.ai.goal.RevengeGoal;
import net.minecraft.entity.ai.goal.SwimGoal;
import net.minecraft.entity.ai.goal.WanderAroundFarGoal;
import net.minecraft.entity.mob.HostileEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.sound.SoundEvent;
import net.minecraft.sound.SoundEvents;
import net.minecraft.world.LocalDifficulty;
import net.minecraft.world.ServerWorldAccess;
import net.minecraft.world.World;
import net.minecraft.world.WorldAccess;

/**
 * The only mob allowed to naturally spawn inside HollowDimension. Deliberately NOT spawnable
 * anywhere else: it is never added to any vanilla biome's spawn list, and the Hollow biome's
 * spawn list (data/hollowmod/worldgen/biome/hollow_void.json) contains *only* this entity --
 * that alone is enough to stop every vanilla mob from spawning there, no code required.
 *
 * This is a minimal, functional skeleton. Swap getAmbientSound()/add a real model+texture
 * (assets/hollowmod/textures/entity/ethereal_entity.png) before shipping.
 */
public class EtherealEntity extends HostileEntity {

    public EtherealEntity(EntityType<? extends HostileEntity> type, World world) {
        super(type, world);
        this.experiencePoints = 8;
    }

    public static DefaultAttributeContainer.Builder createEtherealAttributes() {
        return HostileEntity.createHostileAttributes()
                .add(EntityAttributes.GENERIC_MAX_HEALTH, 20.0D)
                .add(EntityAttributes.GENERIC_MOVEMENT_SPEED, 0.28D)
                .add(EntityAttributes.GENERIC_ATTACK_DAMAGE, 4.0D)
                .add(EntityAttributes.GENERIC_FOLLOW_RANGE, 32.0D)
                .add(EntityAttributes.GENERIC_ARMOR, 2.0D);
    }

    @Override
    protected void initGoals() {
        this.goalSelector.add(1, new SwimGoal(this));
        this.goalSelector.add(2, new MeleeAttackGoal(this, 1.0D, false));
        this.goalSelector.add(3, new WanderAroundFarGoal(this, 0.8D));
        this.goalSelector.add(4, new LookAtEntityGoal(this, PlayerEntity.class, 12.0F));
        this.goalSelector.add(5, new LookAroundGoal(this));
        this.targetSelector.add(1, new RevengeGoal(this));
        this.targetSelector.add(2, new ActiveTargetGoal<>(this, PlayerEntity.class, true));
    }

    @Override
    public boolean canSpawn(WorldAccess world, SpawnReason spawnReason) {
        // Belt-and-suspenders: even though the biome spawn list already restricts this mob to
        // the Hollow biome, this guard makes the restriction explicit in code too.
        return super.canSpawn(world, spawnReason);
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.ENTITY_VEX_AMBIENT; // placeholder eerie sound; replace with a custom one
    }

    @Override
    protected SoundEvent getHurtSound(net.minecraft.entity.damage.DamageSource source) {
        return SoundEvents.ENTITY_VEX_HURT;
    }

    @Override
    protected SoundEvent getDeathSound() {
        return SoundEvents.ENTITY_VEX_DEATH;
    }

    public static boolean canSpawnHere(EntityType<EtherealEntity> type, ServerWorldAccess world,
                                        SpawnReason reason, net.minecraft.util.math.BlockPos pos,
                                        net.minecraft.util.math.random.Random random) {
        LocalDifficulty difficulty = world.getLocalDifficulty(pos);
        return difficulty.getGlobalDifficulty() != net.minecraft.world.Difficulty.PEACEFUL
                && HostileEntity.canMobSpawn(type, world, reason, pos, random);
    }

    /**
     * v1.2: killing a regular Ethereal weakens the nearest Hollow's Ether Activity by
     * HollowCoreEntity.ETHEREAL_KILL_ACTIVITY_PENALTY (-1%, System 1). Notorious Ethereal will
     * override this with its own much larger penalty + wounded-state trigger once it exists
     * (System 7).
     */
    @Override
    public void onDeath(net.minecraft.entity.damage.DamageSource damageSource) {
        super.onDeath(damageSource);
        if (!this.getWorld().isClient) {
            HollowCoreEntity.notifyEtherealDeath(this.getWorld(), this.getPos());
        }
    }
}
