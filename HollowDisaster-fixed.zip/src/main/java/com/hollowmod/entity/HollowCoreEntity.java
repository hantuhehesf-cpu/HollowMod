package com.hollowmod.entity;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.ShulkerBoxBlock;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.packet.s2c.play.EntitySpawnS2CPacket;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.ArrayDeque;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * The anomaly's core. A plain {@link Entity} (NOT LivingEntity/MobEntity) on purpose: it has no
 * AI, no pathfinding, no attributes, no combat logic, and no brain -- all of which cost CPU we
 * don't need to spend on mid-range Android hardware. It just ticks, grows, and eats blocks.
 *
 * v1.2: adds the Ether Activity system (System 1/1b from the design spec). Ether Activity is a
 * single 0-100% value (levels 1-5 in the spec are pure labels for ranges of this same number,
 * not a separate mechanic) that rises from eating blocks/items (mass-based, see BLOCK_MASS /
 * ITEM_MASS / MASS_TO_ACTIVITY_PERCENT) and falls from starvation or from Ethereal/Notorious
 * Ethereal deaths nearby. It is intentionally NOT the same thing as the Zenless Limit Gauge
 * (System 2, not yet implemented) -- the two are fully independent per the confirmed design.
 */
public class HollowCoreEntity extends Entity {

    // ---- Synced to client (float, not double: halves network traffic, plenty of precision) ----
    private static final TrackedData<Float> CURRENT_RADIUS =
            DataTracker.registerData(HollowCoreEntity.class, TrackedDataHandlerRegistry.FLOAT);
    private static final TrackedData<Float> ETHER_ACTIVITY =
            DataTracker.registerData(HollowCoreEntity.class, TrackedDataHandlerRegistry.FLOAT);

    // ---- Server-only growth state ----
    private double targetRadius = 128.0D; // matches the spec's "up to 250x250" dome (~125 radius)
    private int growthTickInterval = 20;   // ticks between +growthStep; configurable via /hollow speed
    private float growthStep = 1.0F;
    private int growthTickCounter = 0;
    private int lastScannedShellRadius = 0;

    // ---- Time-sliced devour queue (spec: 100-150 blocks/tick) ----
    private static final int MAX_BLOCKS_PER_TICK = 120;
    private final ArrayDeque<BlockPos> devourQueue = new ArrayDeque<>();

    // ---- Item devouring scan ----
    private static final int ITEM_SCAN_INTERVAL_TICKS = 10; // scan twice/sec, not every tick
    private int itemScanCounter = 0;

    // ---- Ether Activity: mass feeding (design spec System 1b, all numbers confirmed) ----
    private static final double BLOCK_MASS = 0.03D;
    private static final double ITEM_MASS = 0.03D;
    private static final double MASS_TO_ACTIVITY_PERCENT = 0.5D; // 1.0 mass = 0.5% Activity
    // A non-empty shulker box is a flat "container absorbed" event worth one stack's mass,
    // regardless of whether it actually holds 1 item or 27 stacks -- prevents packed shulkers
    // from being a linear shortcut around the Activity pacing (confirmed design decision).
    private static final double SHULKER_FLAT_MASS_EQUIVALENT = 64.0D * ITEM_MASS;

    // ---- Ether Activity: decay (design spec System 1, all numbers confirmed) ----
    private static final double STARVATION_DECAY_PER_MINUTE = 2.0D;
    private static final double STARVATION_DECAY_PER_TICK = STARVATION_DECAY_PER_MINUTE / (20.0D * 60.0D);
    /** -1% instant per regular Ethereal kill (EtherealEntity#onDeath calls notifyEtherealDeath). */
    public static final double ETHEREAL_KILL_ACTIVITY_PENALTY = 1.0D;
    /** -15% instant on a Notorious Ethereal kill (System 7, not implemented yet -- this constant
     *  and applyWoundedState() below are ready for it). */
    public static final double NOTORIOUS_KILL_ACTIVITY_PENALTY = 15.0D;
    public static final int NOTORIOUS_WOUNDED_DURATION_TICKS = 20 * 60 * 5; // 5 minutes @ 2x decay
    private int woundedTicksRemaining = 0;

    /**
     * Modular hook for future tech-mod integration (Create Mod / an Energy API, etc).
     * Not wired to anything yet on purpose -- just accumulates so a future addon can read it.
     */
    private double etherDensity = 0.0D;

    // Lets /hollow speed and the boundary-check event iterate active cores without a world-wide
    // bounding-box entity scan every tick.
    private static final List<HollowCoreEntity> ACTIVE_CORES = new CopyOnWriteArrayList<>();

    public HollowCoreEntity(EntityType<? extends HollowCoreEntity> type, World world) {
        super(type, world);
        this.noClip = true; // the entity itself has no physical presence beyond its 1x1 hitbox
        this.setInvulnerable(true); // lore-accurate: not meant to be punched down; gate its
                                     // defeat behind the exit-portal / boss flow instead.
    }

    public static List<HollowCoreEntity> getActiveCores() {
        return Collections.unmodifiableList(ACTIVE_CORES);
    }

    /**
     * Vanilla's plain Entity class has no reliably-overridable "added/removed from world" hook
     * in 1.20.1 (unlike some later versions), so ACTIVE_CORES is kept in sync via Fabric API's
     * world-load events instead. Call this once from HollowMod#onInitialize().
     */
    public static void registerTracking() {
        ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
            if (entity instanceof HollowCoreEntity core) {
                ACTIVE_CORES.add(core);
            }
        });
        ServerEntityEvents.ENTITY_UNLOAD.register((entity, world) -> {
            if (entity instanceof HollowCoreEntity core) {
                ACTIVE_CORES.remove(core);
            }
        });
    }

    /**
     * Called by EtherealEntity#onDeath. Finds the nearest active Hollow core in the given world
     * and applies the regular-kill Activity penalty to it. Spatial "nearest" lookup rather than
     * a stored owner reference -- deliberately, so this keeps working correctly once sub-regions
     * (System 4) exist and there are multiple Hollows/dimension copies to disambiguate between.
     */
    public static void notifyEtherealDeath(World world, Vec3d deathPos) {
        HollowCoreEntity nearest = findNearestCore(world, deathPos);
        if (nearest != null) {
            nearest.applyEtherActivityDelta(-ETHEREAL_KILL_ACTIVITY_PENALTY);
        }
    }

    private static HollowCoreEntity findNearestCore(World world, Vec3d pos) {
        HollowCoreEntity nearest = null;
        double nearestDistSq = Double.MAX_VALUE;
        for (HollowCoreEntity core : ACTIVE_CORES) {
            if (core.getWorld() != world) {
                continue;
            }
            double distSq = core.getPos().squaredDistanceTo(pos);
            if (distSq < nearestDistSq) {
                nearestDistSq = distSq;
                nearest = core;
            }
        }
        return nearest;
    }

    @Override
    protected void initDataTracker() {
        this.dataTracker.startTracking(CURRENT_RADIUS, 2.0F);
        this.dataTracker.startTracking(ETHER_ACTIVITY, 0.0F); // freshly spawned = dormant, hasn't eaten yet
    }

    public float getCurrentRadius() {
        return this.dataTracker.get(CURRENT_RADIUS);
    }

    // v1.1: last tick's radius, kept purely so the renderer can smoothly interpolate between it
    // and the current value using the frame's partial-tick fraction, instead of the visual size
    // "popping" every time the server applies a growth step.
    private float prevRadius = 2.0F;

    public float getPrevRadius() {
        return prevRadius;
    }

    public double getEtherDensity() {
        return etherDensity;
    }

    // ------------------------------------------------------------------
    // Ether Activity: public API
    // ------------------------------------------------------------------

    public double getEtherActivity() {
        return this.dataTracker.get(ETHER_ACTIVITY);
    }

    /** 0 = fully dormant, otherwise 1-5 per the design spec's fixed 20%-wide bands. */
    public int getEtherActivityLevel() {
        double a = getEtherActivity();
        if (a >= 81.0D) return 5;
        if (a >= 61.0D) return 4;
        if (a >= 41.0D) return 3;
        if (a >= 21.0D) return 2;
        if (a >= 1.0D) return 1;
        return 0;
    }

    /** Positive to raise Activity, negative to lower it (e.g. a kill penalty). Always clamped 0-100. */
    public void applyEtherActivityDelta(double percent) {
        setEtherActivity(getEtherActivity() + percent);
    }

    /** Starts (or refreshes, taking the longer remaining duration) the post-Notorious-kill
     *  "wounded" state, during which starvation decay runs at 2x. Not called anywhere yet --
     *  ready for System 7 (Notorious Ethereal) to call once it exists. */
    public void applyWoundedState(int ticks) {
        this.woundedTicksRemaining = Math.max(this.woundedTicksRemaining, ticks);
    }

    private void setEtherActivity(double value) {
        double clamped = MathHelper.clamp(value, 0.0D, 100.0D);
        this.dataTracker.set(ETHER_ACTIVITY, (float) clamped);
    }

    private void addMassToActivity(double mass) {
        applyEtherActivityDelta(mass * MASS_TO_ACTIVITY_PERCENT);
    }

    public void setGrowthTickInterval(int ticks) {
        this.growthTickInterval = Math.max(1, ticks);
    }

    public void setTargetRadius(double radius) {
        this.targetRadius = Math.max(this.getCurrentRadius(), radius);
    }

    public double getTargetRadius() {
        return this.targetRadius;
    }

    /**
     * Testing helper (/hollow setsize): jumps the CURRENT radius straight to newRadius instead
     * of growing there gradually over time, unlike setTargetRadius() which only moves the
     * ceiling the normal time-based growth is still climbing toward. Still enqueues the
     * intervening shells for devouring (terrain catches up over the next several ticks through
     * the normal time-sliced queue, same as regular growth) rather than silently skipping them,
     * and raises targetRadius to at least newRadius so growth doesn't just stop dead afterward.
     */
    public void setSizeInstant(int newRadius) {
        int clamped = Math.max(0, newRadius);
        this.dataTracker.set(CURRENT_RADIUS, (float) clamped);
        this.prevRadius = clamped; // avoids a visible "grow" interpolation from the old value

        if (clamped > lastScannedShellRadius) {
            enqueueShell(lastScannedShellRadius, clamped);
            lastScannedShellRadius = clamped;
        }
        if (clamped > targetRadius) {
            this.targetRadius = clamped;
        }
    }

    // ------------------------------------------------------------------
    // Tick
    // ------------------------------------------------------------------

    @Override
    public void tick() {
        super.tick();
        // Capture BEFORE any growth logic runs this tick, and on BOTH sides (client needs this
        // for interpolation; server just carries the field along for free). Runs every tick
        // regardless of whether the radius actually changes -- cheap (one float copy).
        this.prevRadius = this.getCurrentRadius();

        if (this.getWorld().isClient) {
            return; // client only ever reads CURRENT_RADIUS/ETHER_ACTIVITY for rendering/UI; no logic here
        }

        // PERFORMANCE FILTER (spec #2): if there's truly nothing to do this tick, bail out early.
        boolean stillGrowing = this.getCurrentRadius() < targetRadius;
        boolean queueHasWork = !devourQueue.isEmpty();
        if (!stillGrowing && !queueHasWork) {
            tickItemAbsorption(); // still worth checking for item absorption even at rest
            tickEtherActivityDecay();
            return;
        }

        if (stillGrowing) {
            tickGrowth();
        }
        if (queueHasWork) {
            tickDevourQueue();
        }
        tickItemAbsorption();
        tickEtherActivityDecay();
    }

    /** Advances the visual/logical radius by growthStep every growthTickInterval ticks. */
    private void tickGrowth() {
        growthTickCounter++;
        if (growthTickCounter < growthTickInterval) {
            return;
        }
        growthTickCounter = 0;

        float newRadius = (float) Math.min(this.getCurrentRadius() + growthStep, targetRadius);
        this.dataTracker.set(CURRENT_RADIUS, newRadius);

        int newShell = (int) Math.floor(newRadius);
        if (newShell > lastScannedShellRadius) {
            enqueueShell(lastScannedShellRadius, newShell);
            lastScannedShellRadius = newShell;
        }
    }

    /**
     * BENTUK KAWAH (smooth rounded crater): only scans the thin spherical *shell* between the
     * previous and new radius -- never the whole sphere volume -- so growth cost stays bounded
     * as the dome gets large. All distance comparisons use squared distance (no Math.sqrt()).
     */
    private void enqueueShell(int fromRadius, int toRadius) {
        BlockPos center = this.getBlockPos();
        int r = toRadius;
        long rSq = (long) r * r;
        long fromSq = (long) fromRadius * fromRadius;

        for (int x = -r; x <= r; x++) {
            long xSq = (long) x * x;
            if (xSq > rSq) continue;
            for (int y = -r; y <= r; y++) {
                long xySq = xSq + (long) y * y;
                if (xySq > rSq) continue;
                for (int z = -r; z <= r; z++) {
                    long distSq = xySq + (long) z * z; // squared distance, deliberately no sqrt()
                    if (distSq > rSq || distSq < fromSq) continue; // keep only the new shell
                    devourQueue.add(center.add(x, y, z));
                }
            }
        }
    }

    /**
     * ANTI-LAG METHOD: pulls at most MAX_BLOCKS_PER_TICK positions off the queue per tick.
     * Skips air outright (performance filter) and skips bedrock (blacklist), and clears
     * everything else to air with block-update flag 2 (NOTIFY_LISTENERS) only -- this still
     * pushes the change to clients for rendering, but suppresses NOTIFY_NEIGHBORS (flag 1),
     * so we don't trigger cascades of redstone/fluid/fence-connection updates on neighbors
     * while mass-clearing terrain. Each block actually cleared feeds mass into Ether Activity
     * (System 1b).
     */
    private void tickDevourQueue() {
        ServerWorld world = (ServerWorld) this.getWorld();
        int processed = 0;

        while (processed < MAX_BLOCKS_PER_TICK && !devourQueue.isEmpty()) {
            BlockPos pos = devourQueue.poll();
            BlockState state = world.getBlockState(pos);

            if (state.isAir()) {
                continue; // PERFORMANCE FILTER: nothing to do, don't count it against the budget
            }
            if (state.isOf(Blocks.BEDROCK)) {
                continue; // BLACKLIST: bedrock is never removed
            }

            world.setBlockState(pos, Blocks.AIR.getDefaultState(), Block.NOTIFY_LISTENERS); // flag 2
            addMassToActivity(BLOCK_MASS);
            processed++;
        }
    }

    /**
     * ITEM DEVOURING (v1.2: feeds Ether Activity via mass, System 1b -- no longer bumps radius
     * directly; see the design spec's rejected-Option-B reasoning for why). Every
     * ITEM_SCAN_INTERVAL_TICKS, scans for nearby item entities and discards each one, adding its
     * mass to Activity. A non-empty shulker box counts as one flat "container absorbed" event
     * worth a full stack's mass regardless of actual contents, rather than scaling with what's
     * inside it.
     */
    private void tickItemAbsorption() {
        if (++itemScanCounter < ITEM_SCAN_INTERVAL_TICKS) {
            return;
        }
        itemScanCounter = 0;

        double radius = this.getCurrentRadius();
        if (radius < 1.0D) {
            return;
        }

        Box scanBox = this.getBoundingBox().expand(radius);
        List<ItemEntity> items = this.getWorld().getEntitiesByClass(ItemEntity.class, scanBox, ItemEntity::isAlive);
        if (items.isEmpty()) {
            return;
        }

        for (ItemEntity item : items) {
            ItemStack stack = item.getStack();
            double mass = isNonEmptyShulkerBox(stack) ? SHULKER_FLAT_MASS_EQUIVALENT : stack.getCount() * ITEM_MASS;
            addMassToActivity(mass);
            item.discard();
        }
    }

    private static boolean isNonEmptyShulkerBox(ItemStack stack) {
        if (!(stack.getItem() instanceof BlockItem blockItem)) {
            return false;
        }
        if (!(blockItem.getBlock() instanceof ShulkerBoxBlock)) {
            return false;
        }
        NbtCompound nbt = stack.getNbt();
        if (nbt == null || !nbt.contains("BlockEntityTag")) {
            return false;
        }
        NbtCompound blockEntityTag = nbt.getCompound("BlockEntityTag");
        return blockEntityTag.contains("Items") && !blockEntityTag.getList("Items", 10).isEmpty();
    }

    /**
     * Starvation decay (System 1): constant background drain, always applied regardless of
     * growth state -- this is what makes "don't feed the Hollow" a real deliberate choice rather
     * than something the player has to actively trigger. Runs at 2x while "wounded" from a
     * Notorious Ethereal kill (not wired up yet, see applyWoundedState()).
     */
    private void tickEtherActivityDecay() {
        double rate = STARVATION_DECAY_PER_TICK;
        if (woundedTicksRemaining > 0) {
            rate *= 2.0D;
            woundedTicksRemaining--;
        }
        applyEtherActivityDelta(-rate);
    }

    // ------------------------------------------------------------------
    // Persistence / networking plumbing
    // ------------------------------------------------------------------

    @Override
    protected void readCustomDataFromNbt(NbtCompound nbt) {
        // BUGFIX (v1.1.2): previously read every key unconditionally. /summon routes entity
        // creation through this same method with an EMPTY NbtCompound (no keys at all) when no
        // explicit NBT is given in the command -- and NbtCompound#getFloat/getDouble/getInt all
        // return 0 for a missing key. That silently zeroed out targetRadius (default 128) and
        // currentRadius right after construction, permanently stalling growth (0 < 0 is false)
        // until an item-absorption event nudged targetRadius up by 1 from outside. Spawning via
        // the mod's own item never went through this method at all, which is why only /summon
        // was affected. Guarding each field behind nbt.contains(...) means "no data for this key"
        // correctly leaves the constructor's defaults alone instead of zeroing them. The same
        // guard pattern is used for EtherActivity below for the same reason.
        if (nbt.contains("CurrentRadius")) {
            this.dataTracker.set(CURRENT_RADIUS, nbt.getFloat("CurrentRadius"));
        }
        if (nbt.contains("EtherActivity")) {
            this.dataTracker.set(ETHER_ACTIVITY, nbt.getFloat("EtherActivity"));
        }
        if (nbt.contains("TargetRadius")) {
            this.targetRadius = nbt.getDouble("TargetRadius");
        }
        if (nbt.contains("EtherDensity")) {
            this.etherDensity = nbt.getDouble("EtherDensity");
        }
        if (nbt.contains("LastScannedShell")) {
            this.lastScannedShellRadius = nbt.getInt("LastScannedShell");
        }
        if (nbt.contains("GrowthTickInterval")) {
            this.growthTickInterval = Math.max(1, nbt.getInt("GrowthTickInterval"));
        }
        if (nbt.contains("WoundedTicksRemaining")) {
            this.woundedTicksRemaining = nbt.getInt("WoundedTicksRemaining");
        }
        // Note: the in-flight devourQueue is intentionally NOT persisted (it can be large and is
        // fully rebuilt on the next shell boundary); on reload we simply re-scan the current shell.
    }

    @Override
    protected void writeCustomDataToNbt(NbtCompound nbt) {
        nbt.putFloat("CurrentRadius", this.getCurrentRadius());
        nbt.putFloat("EtherActivity", (float) this.getEtherActivity());
        nbt.putDouble("TargetRadius", this.targetRadius);
        nbt.putDouble("EtherDensity", this.etherDensity);
        nbt.putInt("LastScannedShell", this.lastScannedShellRadius);
        nbt.putInt("GrowthTickInterval", this.growthTickInterval);
        nbt.putInt("WoundedTicksRemaining", this.woundedTicksRemaining);
    }

    @Override
    public EntitySpawnS2CPacket createSpawnPacket() {
        return new EntitySpawnS2CPacket(this);
    }

    /** Convenience for ModCommands: is this player currently allowed to command this core? */
    public boolean canBeManagedBy(ServerPlayerEntity player) {
        return player.hasPermissionLevel(2);
    }
}
