package com.hollowmod.entity;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.block.ShulkerBoxBlock;
import com.hollowmod.registry.ModEntities;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.item.BlockItem;
import net.minecraft.item.ItemStack;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.nbt.NbtHelper;
import net.minecraft.nbt.NbtList;
import net.minecraft.network.packet.s2c.play.EntitySpawnS2CPacket;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.World;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * The anomaly's core. A plain {@link Entity} (NOT LivingEntity/MobEntity) on purpose: it has no
 * AI, no pathfinding, no attributes, no combat logic, and no brain -- all of which cost CPU we
 * don't need to spend on mid-range Android hardware. It just ticks, grows, and eats blocks.
 *
 * v1.2: adds the Ether Activity system (System 1/1b) and the Zenless Limit Gauge (System 2) from
 * the design spec. These are DELIBERATELY fully independent 0-100% values -- Activity reacts to
 * feeding/starvation/kills in real time, the Gauge only ever advances with time and is untouched
 * by anything else. They only interact at the future Overflow event (System 3, not implemented
 * yet -- needs the parent/child Hollow relationship data model first).
 */
public class HollowCoreEntity extends Entity {

    // ---- Synced to client (float, not double: halves network traffic, plenty of precision) ----
    private static final TrackedData<Float> CURRENT_RADIUS =
            DataTracker.registerData(HollowCoreEntity.class, TrackedDataHandlerRegistry.FLOAT);
    private static final TrackedData<Float> ETHER_ACTIVITY =
            DataTracker.registerData(HollowCoreEntity.class, TrackedDataHandlerRegistry.FLOAT);
    private static final TrackedData<Float> ZENLESS_LIMIT_GAUGE =
            DataTracker.registerData(HollowCoreEntity.class, TrackedDataHandlerRegistry.FLOAT);

    // ---- Server-only growth state ----
    private double targetRadius = 128.0D; // matches the spec's "up to 250x250" dome (~125 radius)
    private int growthTickInterval = 20;   // ticks between +growthStep; configurable via /hollow speed
    private float growthStep = 1.0F;
    private int growthTickCounter = 0;
    private int lastScannedShellRadius = 0;

    // ---- Time-sliced devour queue (spec: 100-150 blocks/tick) ----
    private static final int MAX_BLOCKS_PER_TICK = 120;
    private final ArrayDeque<BlockPos> devourQueue = new ArrayDeque<>();

    // ---- Item devouring scan ----
    private static final int ITEM_SCAN_INTERVAL_TICKS = 10; // scan twice/sec, not every tick
    private int itemScanCounter = 0;

    // ---- Ether Activity: mass feeding (design spec System 1b) ----
    // BUGFIX #1 (v1.2, pre-release testing): originally BLOCK_MASS matched ITEM_MASS (0.03,
    // "same stuff either way"), which ignored the huge difference in HOW MANY of each get
    // consumed. A sphere's volume scales with radius^3, not linearly -- radius 15 alone devours
    // ~14,000 blocks (the crater is a full sphere, not just its shell), which at 0.03 mass/block
    // flooded Activity to 100% within seconds of a Hollow existing. Items are individually placed
    // by deliberate player action and stay naturally bounded, so their mass held up; blocks
    // needed a much smaller value. See BUGFIX #2 below for the corrected number -- the first
    // attempt (0.0005) was itself based on a math error and still overshot badly.
    //
    // BUGFIX #2 (v1.2, pre-release testing): the first fix (0.0005) was itself based on a math
    // error on Claude's part -- the claimed "~22% Activity at max radius" was computed wrong; the
    // real result at 0.0005 is ~2196% at radius 128 (confirmed by on-device testing: radius 50
    // alone hit 67%, consistent with the error, not with the claimed fix). Corrected math:
    // Activity% = totalBlocksEaten * BLOCK_MASS * MASS_TO_ACTIVITY_PERCENT (0.5), so to land the
    // *originally intended* ~20-22% ceiling at radius 128 (~8.78M blocks in a full sphere):
    // BLOCK_MASS = 20 / (8,784,000 * 0.5) ≈ 0.0000046 -- rounded to 0.000005. Verified at several
    // radii: r15 ≈ 0.04%, r30 ≈ 0.28%, r50 ≈ 1.3%, r128 ≈ 22%. Item mass is untouched (0.03) --
    // that number's math held up correctly the first time (1,333 items ≈ 20%, unaffected by this
    // error, which was isolated to the block constant only). On-device results after this fix:
    // radius 50 (no feeding) -> 1.6%, matching the ~1.3% prediction closely (real terrain has air
    // pockets/caves so isn't a perfectly solid sphere, explaining the small difference).
    //
    // Lore note: this ended up matching research the user did independently -- organic matter
    // (mobs) and, later, machinery/technology are meant to be the Hollow's primary "food", not
    // terrain. So it's fitting that blocks contribute so little. Planned mob-eating should likely
    // use a mass value much closer to ITEM_MASS than to this tiny BLOCK_MASS when it's built.
    private static final double BLOCK_MASS = 0.000005D;
    private static final double ITEM_MASS = 0.03D;
    private static final double MASS_TO_ACTIVITY_PERCENT = 0.5D; // 1.0 mass = 0.5% Activity
    // A non-empty shulker box is a flat "container absorbed" event worth one stack's mass,
    // regardless of whether it actually holds 1 item or 27 stacks -- prevents packed shulkers
    // from being a linear shortcut around the Activity pacing (confirmed design decision).
    private static final double SHULKER_FLAT_MASS_EQUIVALENT = 64.0D * ITEM_MASS;

    // ---- Ether Activity: decay (design spec System 1, all numbers confirmed) ----
    private static final double STARVATION_DECAY_PER_MINUTE = 2.0D;
    private static final double STARVATION_DECAY_PER_TICK = STARVATION_DECAY_PER_MINUTE / (20.0D * 60.0D);
    /** -1% instant per regular Ethereal kill (EtherealEntity#onDeath calls notifyEtherealDeath). */
    public static final double ETHEREAL_KILL_ACTIVITY_PENALTY = 1.0D;
    /** -15% instant on a Notorious Ethereal kill (System 7, not implemented yet -- this constant
     *  and applyWoundedState() below are ready for it). */
    public static final double NOTORIOUS_KILL_ACTIVITY_PENALTY = 15.0D;
    public static final int NOTORIOUS_WOUNDED_DURATION_TICKS = 20 * 60 * 5; // 5 minutes @ 2x decay
    private int woundedTicksRemaining = 0;

    // ---- Zenless Limit Gauge (design spec System 2): fully independent of Ether Activity,
    // advances purely with time, never touched by feeding/starvation/kills. ----
    private static final double GAUGE_INCREASE_PER_MINUTE = 0.2D;
    private static final double GAUGE_INCREASE_PER_TICK = GAUGE_INCREASE_PER_MINUTE / (20.0D * 60.0D);

    // ---- Hollow relationships / generations / Overflow (design spec System 3) ----
    // "Independent" is not a separate state machine -- per the confirmed design, a Companion
    // becomes "Independent" at the EXACT moment it successfully Overflows (Activity 5 + Gauge
    // 100 together, same as the Parent needs). So the only real state needed is generation +
    // how many children this Hollow has already had vs. its allowance.
    private static final int PARENT_MAX_CHILDREN = 3;
    private static final int OTHER_MAX_CHILDREN = 1;
    private static final int MAX_GENERATION = 3; // Gen 3 is terminal: explodes instead of birthing
    private static final double COMPANION_MASS_SHARE = 0.30D; // 30% of the parent's radius/mass
    private static final int GLOBAL_HOLLOW_CAP = 10;
    private static final int OVERFLOW_CHECK_INTERVAL_TICKS = 20; // once/second is plenty

    private UUID parentId = null; // null = this is a Parent (generation 0)
    private final List<UUID> childIds = new ArrayList<>();
    private int generation = 0;
    private int overflowCheckCounter = 0;

    /**
     * Modular hook for future tech-mod integration (Create Mod / an Energy API, etc).
     * Not wired to anything yet on purpose -- just accumulates so a future addon can read it.
     */
    private double etherDensity = 0.0D;

    // Lets /hollow speed and the boundary-check event iterate active cores without a world-wide
    // bounding-box entity scan every tick.
    private static final List<HollowCoreEntity> ACTIVE_CORES = new CopyOnWriteArrayList<>();

    public HollowCoreEntity(EntityType<? extends HollowCoreEntity> type, World world) {
        super(type, world);
        this.noClip = true; // the entity itself has no physical presence beyond its 1x1 hitbox
        this.setInvulnerable(true); // lore-accurate: not meant to be punched down; gate its
                                     // defeat behind the exit-portal / boss flow instead.
    }

    public static List<HollowCoreEntity> getActiveCores() {
        return Collections.unmodifiableList(ACTIVE_CORES);
    }

    /**
     * Vanilla's plain Entity class has no reliably-overridable "added/removed from world" hook
     * in 1.20.1 (unlike some later versions), so ACTIVE_CORES is kept in sync via Fabric API's
     * world-load events instead. Call this once from HollowMod#onInitialize().
     */
    public static void registerTracking() {
        ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
            if (entity instanceof HollowCoreEntity core) {
                ACTIVE_CORES.add(core);
            }
        });
        ServerEntityEvents.ENTITY_UNLOAD.register((entity, world) -> {
            if (entity instanceof HollowCoreEntity core) {
                ACTIVE_CORES.remove(core);
            }
        });
    }

    /**
     * Called by EtherealEntity#onDeath. Finds the nearest active Hollow core in the given world
     * and applies the regular-kill Activity penalty to it. Spatial "nearest" lookup rather than
     * a stored owner reference -- deliberately, so this keeps working correctly once sub-regions
     * (System 4) exist and there are multiple Hollows/dimension copies to disambiguate between.
     */
    public static void notifyEtherealDeath(World world, Vec3d deathPos) {
        HollowCoreEntity nearest = findNearestCore(world, deathPos);
        if (nearest != null) {
            nearest.applyEtherActivityDelta(-ETHEREAL_KILL_ACTIVITY_PENALTY);
        }
    }

    private static HollowCoreEntity findNearestCore(World world, Vec3d pos) {
        HollowCoreEntity nearest = null;
        double nearestDistSq = Double.MAX_VALUE;
        for (HollowCoreEntity core : ACTIVE_CORES) {
            if (core.getWorld() != world) {
                continue;
            }
            double distSq = core.getPos().squaredDistanceTo(pos);
            if (distSq < nearestDistSq) {
                nearestDistSq = distSq;
                nearest = core;
            }
        }
        return nearest;
    }

    @Override
    protected void initDataTracker() {
        this.dataTracker.startTracking(CURRENT_RADIUS, 2.0F);
        this.dataTracker.startTracking(ETHER_ACTIVITY, 0.0F); // freshly spawned = dormant, hasn't eaten yet
        this.dataTracker.startTracking(ZENLESS_LIMIT_GAUGE, 0.0F); // freshly spawned = just born
    }

    public float getCurrentRadius() {
        return this.dataTracker.get(CURRENT_RADIUS);
    }

    // v1.1: last tick's radius, kept purely so the renderer can smoothly interpolate between it
    // and the current value using the frame's partial-tick fraction, instead of the visual size
    // "popping" every time the server applies a growth step.
    private float prevRadius = 2.0F;

    public float getPrevRadius() {
        return prevRadius;
    }

    public double getEtherDensity() {
        return etherDensity;
    }

    // ------------------------------------------------------------------
    // Ether Activity: public API
    // ------------------------------------------------------------------

    public double getEtherActivity() {
        return this.dataTracker.get(ETHER_ACTIVITY);
    }

    /** 0 = fully dormant, otherwise 1-5 per the design spec's fixed 20%-wide bands. */
    public int getEtherActivityLevel() {
        double a = getEtherActivity();
        if (a >= 81.0D) return 5;
        if (a >= 61.0D) return 4;
        if (a >= 41.0D) return 3;
        if (a >= 21.0D) return 2;
        if (a >= 1.0D) return 1;
        return 0;
    }

    /** Positive to raise Activity, negative to lower it (e.g. a kill penalty). Always clamped 0-100. */
    public void applyEtherActivityDelta(double percent) {
        setEtherActivity(getEtherActivity() + percent);
    }

    /** Starts (or refreshes, taking the longer remaining duration) the post-Notorious-kill
     *  "wounded" state, during which starvation decay runs at 2x. Not called anywhere yet --
     *  ready for System 7 (Notorious Ethereal) to call once it exists. */
    public void applyWoundedState(int ticks) {
        this.woundedTicksRemaining = Math.max(this.woundedTicksRemaining, ticks);
    }

    private void setEtherActivity(double value) {
        double clamped = MathHelper.clamp(value, 0.0D, 100.0D);
        this.dataTracker.set(ETHER_ACTIVITY, (float) clamped);
    }

    private void addMassToActivity(double mass) {
        applyEtherActivityDelta(mass * MASS_TO_ACTIVITY_PERCENT);
    }

    // ------------------------------------------------------------------
    // Zenless Limit Gauge: public API (System 2)
    // ------------------------------------------------------------------

    public double getZenlessLimitGauge() {
        return this.dataTracker.get(ZENLESS_LIMIT_GAUGE);
    }

    /** Testing helper (/hollow gauge) and the future Overflow event (drops it to 50 instead of
     *  resetting to 0) both go through this. Always clamped 0-100. */
    public void setZenlessLimitGauge(double value) {
        double clamped = MathHelper.clamp(value, 0.0D, 100.0D);
        this.dataTracker.set(ZENLESS_LIMIT_GAUGE, (float) clamped);
    }

    /** Pure time-based advance, deliberately touched by nothing else -- no feeding, no kills, no
     *  growth state. Always runs, every tick, regardless of anything happening to the Hollow. */
    private void tickZenlessLimitGauge() {
        setZenlessLimitGauge(getZenlessLimitGauge() + GAUGE_INCREASE_PER_TICK);
    }

    // ------------------------------------------------------------------
    // Hollow relationships / Overflow (System 3): public API
    // ------------------------------------------------------------------

    public int getGeneration() {
        return generation;
    }

    public UUID getParentId() {
        return parentId;
    }

    public List<UUID> getChildIds() {
        return Collections.unmodifiableList(childIds);
    }

    /** Parent (generation 0) may have 3 children; every other Hollow (Companion/Independent, any
     *  generation) may have at most 1 -- deliberately NOT "3 per Hollow" (see design spec: that
     *  would compound exponentially every generation and blow past the population cap fast). */
    public int getMaxChildren() {
        return generation == 0 ? PARENT_MAX_CHILDREN : OTHER_MAX_CHILDREN;
    }

    /**
     * Checked periodically (not every tick -- once/second is plenty for something that takes
     * minutes/hours to trigger). When Ether Activity is critical (level 5) AND the Zenless Limit
     * Gauge is full at the same time:
     *  - Generation 3 (terminal): explodes in the Overworld instead of reproducing (safety valve).
     *  - Otherwise, if this Hollow hasn't used up its children allowance yet: spawns a Companion
     *    (Overflow), taking 30% of this Hollow's own radius to give it a real starting size, and
     *    drops THIS Hollow's Gauge (not Activity) back to 50%.
     *  - If the allowance is already used up (non-terminal generation that's already had its one
     *    child): nothing happens -- that Hollow simply doesn't reproduce again.
     *  - If the population cap is full: the birth is delayed (held at peak) until a slot frees up
     *    elsewhere, per the confirmed design -- never forces another Hollow to collapse early.
     */
    private void tickOverflowCheck() {
        if (++overflowCheckCounter < OVERFLOW_CHECK_INTERVAL_TICKS) {
            return;
        }
        overflowCheckCounter = 0;

        if (getEtherActivityLevel() != 5 || getZenlessLimitGauge() < 100.0D) {
            return;
        }

        if (generation >= MAX_GENERATION) {
            explode();
            return;
        }

        if (childIds.size() >= getMaxChildren()) {
            return; // already used up this Hollow's one reproduction chance
        }

        if (ACTIVE_CORES.size() >= GLOBAL_HOLLOW_CAP) {
            return; // held at peak until a slot frees up elsewhere -- confirmed design (option a)
        }

        spawnCompanion();
    }

    private void spawnCompanion() {
        if (!(this.getWorld() instanceof ServerWorld world)) {
            return;
        }

        double originalRadius = this.getCurrentRadius(); // captured BEFORE shrinking below
        double childRadius = originalRadius * COMPANION_MASS_SHARE;
        double newSelfRadius = originalRadius * (1.0D - COMPANION_MASS_SHARE);

        // "Memotong massa" -- this Hollow genuinely shrinks by what it gives the Companion, it
        // doesn't just clone a bonus out of nowhere. Terrain already eaten stays eaten either way
        // (shrinking the dome doesn't un-eat the crater) -- same accepted quirk as /hollow setsize.
        this.dataTracker.set(CURRENT_RADIUS, (float) newSelfRadius);
        this.prevRadius = (float) newSelfRadius;
        this.lastScannedShellRadius = Math.min(this.lastScannedShellRadius, (int) newSelfRadius);

        double angle = this.random.nextDouble() * 2.0D * Math.PI;
        // BUGFIX: this used to call this.getCurrentRadius() AFTER the shrink above already ran,
        // so the separation distance was computed from the wrong (smaller, post-shrink) radius --
        // confirmed by on-device testing showing overlap. Now uses originalRadius, captured
        // before shrinking. Buffer also bumped 20 -> 80 per the user's suggestion. Still based on
        // radius AT BIRTH, not either Hollow's eventual target size -- delays overlap for the
        // common small/medium case rather than mathematically guaranteeing it can never happen if
        // both later grow toward max radius simultaneously (accepted as "good enough" for now).
        double spawnDist = originalRadius + childRadius + 80.0D;
        double spawnX = this.getX() + Math.cos(angle) * spawnDist;
        double spawnZ = this.getZ() + Math.sin(angle) * spawnDist;

        HollowCoreEntity child = new HollowCoreEntity(ModEntities.HOLLOW_CORE_ENTITY, world);
        child.setPosition(spawnX, this.getY(), spawnZ);
        child.setSizeInstant((int) Math.round(childRadius));
        child.setTargetRadius(128.0D); // free to keep growing normally after birth, like any Hollow
        child.parentId = this.getUuid();
        child.generation = this.generation + 1;

        world.spawnEntity(child);

        this.childIds.add(child.getUuid());
        setZenlessLimitGauge(50.0D); // Gauge resets on Overflow -- Activity is untouched
    }

    /** Generation-3 safety/performance valve: no further replication, ever -- just removes itself
     *  from the world with an explosion instead. Always happens in the Overworld, since that's
     *  where HollowCoreEntity itself always lives (HollowDimension is the separate pocket players
     *  get pulled into, not where the core entities exist). */
    private void explode() {
        if (this.getWorld() instanceof ServerWorld world) {
            world.createExplosion(this, this.getX(), this.getY(), this.getZ(), 4.0F, false,
                    World.ExplosionSourceType.MOB);
        }
        this.discard();
    }

    public void setGrowthTickInterval(int ticks) {
        this.growthTickInterval = Math.max(1, ticks);
    }

    public void setTargetRadius(double radius) {
        this.targetRadius = Math.max(this.getCurrentRadius(), radius);
    }

    public double getTargetRadius() {
        return this.targetRadius;
    }

    /**
     * Testing helper (/hollow setsize): jumps the CURRENT radius straight to newRadius instead
     * of growing there gradually over time, unlike setTargetRadius() which only moves the
     * ceiling the normal time-based growth is still climbing toward. Still enqueues the
     * intervening shells for devouring (terrain catches up over the next several ticks through
     * the normal time-sliced queue, same as regular growth) rather than silently skipping them,
     * and raises targetRadius to at least newRadius so growth doesn't just stop dead afterward.
     */
    public void setSizeInstant(int newRadius) {
        int clamped = Math.max(0, newRadius);
        this.dataTracker.set(CURRENT_RADIUS, (float) clamped);
        this.prevRadius = clamped; // avoids a visible "grow" interpolation from the old value

        if (clamped > lastScannedShellRadius) {
            enqueueShell(lastScannedShellRadius, clamped);
            lastScannedShellRadius = clamped;
        }
        if (clamped > targetRadius) {
            this.targetRadius = clamped;
        }
    }

    // ------------------------------------------------------------------
    // Tick
    // ------------------------------------------------------------------

    @Override
    public void tick() {
        super.tick();
        // Capture BEFORE any growth logic runs this tick, and on BOTH sides (client needs this
        // for interpolation; server just carries the field along for free). Runs every tick
        // regardless of whether the radius actually changes -- cheap (one float copy).
        this.prevRadius = this.getCurrentRadius();

        if (this.getWorld().isClient) {
            return; // client only ever reads CURRENT_RADIUS/ETHER_ACTIVITY/GAUGE for rendering/UI
        }

        // Gauge always runs, unconditionally -- it must not depend on growth state at all.
        tickZenlessLimitGauge();
        // Overflow check also always runs -- reproduction shouldn't depend on whether the
        // Hollow happens to still be actively growing this exact tick.
        tickOverflowCheck();

        // PERFORMANCE FILTER (spec #2): if there's truly nothing to do this tick, bail out early.
        boolean stillGrowing = this.getCurrentRadius() < targetRadius;
        boolean queueHasWork = !devourQueue.isEmpty();
        if (!stillGrowing && !queueHasWork) {
            tickItemAbsorption(); // still worth checking for item absorption even at rest
            tickEtherActivityDecay();
            return;
        }

        if (stillGrowing) {
            tickGrowth();
        }
        if (queueHasWork) {
            tickDevourQueue();
        }
        tickItemAbsorption();
        tickEtherActivityDecay();
    }

    /** Advances the visual/logical radius by growthStep every growthTickInterval ticks. */
    private void tickGrowth() {
        growthTickCounter++;
        if (growthTickCounter < growthTickInterval) {
            return;
        }
        growthTickCounter = 0;

        float newRadius = (float) Math.min(this.getCurrentRadius() + growthStep, targetRadius);
        this.dataTracker.set(CURRENT_RADIUS, newRadius);

        int newShell = (int) Math.floor(newRadius);
        if (newShell > lastScannedShellRadius) {
            enqueueShell(lastScannedShellRadius, newShell);
            lastScannedShellRadius = newShell;
        }
    }

    /**
     * BENTUK KAWAH (smooth rounded crater): only scans the thin spherical *shell* between the
     * previous and new radius -- never the whole sphere volume -- so growth cost stays bounded
     * as the dome gets large. All distance comparisons use squared distance (no Math.sqrt()).
     */
    private void enqueueShell(int fromRadius, int toRadius) {
        BlockPos center = this.getBlockPos();
        int r = toRadius;
        long rSq = (long) r * r;
        long fromSq = (long) fromRadius * fromRadius;

        for (int x = -r; x <= r; x++) {
            long xSq = (long) x * x;
            if (xSq > rSq) continue;
            for (int y = -r; y <= r; y++) {
                long xySq = xSq + (long) y * y;
                if (xySq > rSq) continue;
                for (int z = -r; z <= r; z++) {
                    long distSq = xySq + (long) z * z; // squared distance, deliberately no sqrt()
                    if (distSq > rSq || distSq < fromSq) continue; // keep only the new shell
                    devourQueue.add(center.add(x, y, z));
                }
            }
        }
    }

    /**
     * ANTI-LAG METHOD: pulls at most MAX_BLOCKS_PER_TICK positions off the queue per tick.
     * Skips air outright (performance filter) and skips bedrock (blacklist), and clears
     * everything else to air with block-update flag 2 (NOTIFY_LISTENERS) only -- this still
     * pushes the change to clients for rendering, but suppresses NOTIFY_NEIGHBORS (flag 1),
     * so we don't trigger cascades of redstone/fluid/fence-connection updates on neighbors
     * while mass-clearing terrain. Each block actually cleared feeds mass into Ether Activity
     * (System 1b).
     */
    private void tickDevourQueue() {
        ServerWorld world = (ServerWorld) this.getWorld();
        int processed = 0;

        while (processed < MAX_BLOCKS_PER_TICK && !devourQueue.isEmpty()) {
            BlockPos pos = devourQueue.poll();
            BlockState state = world.getBlockState(pos);

            if (state.isAir()) {
                continue; // PERFORMANCE FILTER: nothing to do, don't count it against the budget
            }
            if (state.isOf(Blocks.BEDROCK)) {
                continue; // BLACKLIST: bedrock is never removed
            }

            world.setBlockState(pos, Blocks.AIR.getDefaultState(), Block.NOTIFY_LISTENERS); // flag 2
            addMassToActivity(BLOCK_MASS);
            processed++;
        }
    }

    /**
     * ITEM DEVOURING (v1.2: feeds Ether Activity via mass, System 1b -- no longer bumps radius
     * directly; see the design spec's rejected-Option-B reasoning for why). Every
     * ITEM_SCAN_INTERVAL_TICKS, scans for nearby item entities and discards each one, adding its
     * mass to Activity. A non-empty shulker box counts as one flat "container absorbed" event
     * worth a full stack's mass regardless of actual contents, rather than scaling with what's
     * inside it.
     */
    private void tickItemAbsorption() {
        if (++itemScanCounter < ITEM_SCAN_INTERVAL_TICKS) {
            return;
        }
        itemScanCounter = 0;

        double radius = this.getCurrentRadius();
        if (radius < 1.0D) {
            return;
        }

        Box scanBox = this.getBoundingBox().expand(radius);
        List<ItemEntity> items = this.getWorld().getEntitiesByClass(ItemEntity.class, scanBox, ItemEntity::isAlive);
        if (items.isEmpty()) {
            return;
        }

        for (ItemEntity item : items) {
            ItemStack stack = item.getStack();
            double mass = isNonEmptyShulkerBox(stack) ? SHULKER_FLAT_MASS_EQUIVALENT : stack.getCount() * ITEM_MASS;
            addMassToActivity(mass);
            item.discard();
        }
    }

    private static boolean isNonEmptyShulkerBox(ItemStack stack) {
        if (!(stack.getItem() instanceof BlockItem blockItem)) {
            return false;
        }
        if (!(blockItem.getBlock() instanceof ShulkerBoxBlock)) {
            return false;
        }
        NbtCompound nbt = stack.getNbt();
        if (nbt == null || !nbt.contains("BlockEntityTag")) {
            return false;
        }
        NbtCompound blockEntityTag = nbt.getCompound("BlockEntityTag");
        return blockEntityTag.contains("Items") && !blockEntityTag.getList("Items", 10).isEmpty();
    }

    /**
     * Starvation decay (System 1): constant background drain, always applied regardless of
     * growth state -- this is what makes "don't feed the Hollow" a real deliberate choice rather
     * than something the player has to actively trigger. Runs at 2x while "wounded" from a
     * Notorious Ethereal kill (not wired up yet, see applyWoundedState()).
     */
    private void tickEtherActivityDecay() {
        double rate = STARVATION_DECAY_PER_TICK;
        if (woundedTicksRemaining > 0) {
            rate *= 2.0D;
            woundedTicksRemaining--;
        }
        applyEtherActivityDelta(-rate);
    }

    // ------------------------------------------------------------------
    // Persistence / networking plumbing
    // ------------------------------------------------------------------

    @Override
    protected void readCustomDataFromNbt(NbtCompound nbt) {
        // BUGFIX (v1.1.2): previously read every key unconditionally. /summon routes entity
        // creation through this same method with an EMPTY NbtCompound (no keys at all) when no
        // explicit NBT is given in the command -- and NbtCompound#getFloat/getDouble/getInt all
        // return 0 for a missing key. That silently zeroed out targetRadius (default 128) and
        // currentRadius right after construction, permanently stalling growth (0 < 0 is false)
        // until an item-absorption event nudged targetRadius up by 1 from outside. Spawning via
        // the mod's own item never went through this method at all, which is why only /summon
        // was affected. Guarding each field behind nbt.contains(...) means "no data for this key"
        // correctly leaves the constructor's defaults alone instead of zeroing them. The same
        // guard pattern is used for EtherActivity/Gauge below for the same reason.
        if (nbt.contains("CurrentRadius")) {
            this.dataTracker.set(CURRENT_RADIUS, nbt.getFloat("CurrentRadius"));
        }
        if (nbt.contains("EtherActivity")) {
            this.dataTracker.set(ETHER_ACTIVITY, nbt.getFloat("EtherActivity"));
        }
        if (nbt.contains("ZenlessLimitGauge")) {
            this.dataTracker.set(ZENLESS_LIMIT_GAUGE, nbt.getFloat("ZenlessLimitGauge"));
        }
        if (nbt.contains("TargetRadius")) {
            this.targetRadius = nbt.getDouble("TargetRadius");
        }
        if (nbt.contains("EtherDensity")) {
            this.etherDensity = nbt.getDouble("EtherDensity");
        }
        if (nbt.contains("LastScannedShell")) {
            this.lastScannedShellRadius = nbt.getInt("LastScannedShell");
        }
        if (nbt.contains("GrowthTickInterval")) {
            this.growthTickInterval = Math.max(1, nbt.getInt("GrowthTickInterval"));
        }
        if (nbt.contains("WoundedTicksRemaining")) {
            this.woundedTicksRemaining = nbt.getInt("WoundedTicksRemaining");
        }
        if (nbt.contains("Generation")) {
            this.generation = nbt.getInt("Generation");
        }
        if (nbt.contains("ParentId")) {
            this.parentId = nbt.getUuid("ParentId");
        }
        if (nbt.contains("ChildIds")) {
            this.childIds.clear();
            NbtList childList = nbt.getList("ChildIds", 11); // 11 = NbtIntArray tag id (UUIDs stored as int-array)
            for (int i = 0; i < childList.size(); i++) {
                this.childIds.add(NbtHelper.toUuid(childList.get(i)));
            }
        }
        // Note: the in-flight devourQueue is intentionally NOT persisted (it can be large and is
        // fully rebuilt on the next shell boundary); on reload we simply re-scan the current shell.
    }

    @Override
    protected void writeCustomDataToNbt(NbtCompound nbt) {
        nbt.putFloat("CurrentRadius", this.getCurrentRadius());
        nbt.putFloat("EtherActivity", (float) this.getEtherActivity());
        nbt.putFloat("ZenlessLimitGauge", (float) this.getZenlessLimitGauge());
        nbt.putDouble("TargetRadius", this.targetRadius);
        nbt.putDouble("EtherDensity", this.etherDensity);
        nbt.putInt("LastScannedShell", this.lastScannedShellRadius);
        nbt.putInt("GrowthTickInterval", this.growthTickInterval);
        nbt.putInt("WoundedTicksRemaining", this.woundedTicksRemaining);
        nbt.putInt("Generation", this.generation);
        if (this.parentId != null) {
            nbt.putUuid("ParentId", this.parentId);
        }
        NbtList childList = new NbtList();
        for (UUID childId : this.childIds) {
            childList.add(NbtHelper.fromUuid(childId));
        }
        nbt.put("ChildIds", childList);
    }

    @Override
    public EntitySpawnS2CPacket createSpawnPacket() {
        return new EntitySpawnS2CPacket(this);
    }

    /** Convenience for ModCommands: is this player currently allowed to command this core? */
    public boolean canBeManagedBy(ServerPlayerEntity player) {
        return player.hasPermissionLevel(2);
    }
}
