package com.hollowmod.entity;

import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.ItemEntity;
import net.minecraft.entity.data.DataTracker;
import net.minecraft.entity.data.TrackedData;
import net.minecraft.entity.data.TrackedDataHandlerRegistry;
import net.minecraft.nbt.NbtCompound;
import net.minecraft.network.packet.s2c.play.EntitySpawnS2CPacket;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Box;
import net.minecraft.world.World;

import java.util.ArrayDeque;
import java.util.Collections;
import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * The anomaly's core. A plain {@link Entity} (NOT LivingEntity/MobEntity) on purpose: it has no
 * AI, no pathfinding, no attributes, no combat logic, and no brain -- all of which cost CPU we
 * don't need to spend on mid-range Android hardware. It just ticks, grows, and eats blocks.
 *
 * Requirement mapping (see mod spec):
 *  #1 Visual dome + border    -> current radius is exposed via DataTracker for the client
 *                                 renderer (com.hollowmod.client.render.HollowCoreEntityRenderer).
 *                                 Hitbox stays fixed at 1x1 (set at EntityType registration).
 *  #2 Devouring logic          -> tickGrowth() / enqueueShell() / tickDevourQueue() below.
 *  #5 Item devouring growth    -> tickItemAbsorption() below.
 *  #6 /hollow speed & etherDensity -> setGrowthTickInterval() and etherDensity field/getters.
 */
public class HollowCoreEntity extends Entity {

    // ---- Synced to client (float, not double: halves network traffic, plenty of precision for a radius) ----
    private static final TrackedData<Float> CURRENT_RADIUS =
            DataTracker.registerData(HollowCoreEntity.class, TrackedDataHandlerRegistry.FLOAT);

    // ---- Server-only growth state ----
    private double targetRadius = 4.0D;
    private int growthTickInterval = 20;   // ticks between +growthStep; configurable via /hollow speed
    private float growthStep = 1.0F;
    private int growthTickCounter = 0;
    private int lastScannedShellRadius = 0;

    // ---- Time-sliced devour queue (spec: 100-150 blocks/tick) ----
    private static final int MAX_BLOCKS_PER_TICK = 120;
    private final ArrayDeque<BlockPos> devourQueue = new ArrayDeque<>();

    // ---- Item devouring (spec #5: "1-3 stack" -> we treat this as a total item-count threshold) ----
    private static final int ITEM_SCAN_INTERVAL_TICKS = 10; // scan twice/sec, not every tick
    private static final int ITEM_COUNT_THRESHOLD = 128;    // ~2 stacks; tune to taste
    private int itemScanCounter = 0;

    /**
     * Modular hook for future tech-mod integration (Create Mod / an Energy API, etc).
     * Not wired to anything yet on purpose -- just accumulates so a future addon can read it.
     */
    private double etherDensity = 0.0D;

    // Lets /hollow speed and the boundary-check event iterate active cores without a world-wide
    // bounding-box entity scan every tick.
    private static final List<HollowCoreEntity> ACTIVE_CORES = new CopyOnWriteArrayList<>();

    public HollowCoreEntity(EntityType<? extends HollowCoreEntity> type, World world) {
        super(type, world);
        this.noClip = true; // the entity itself has no physical presence beyond its 1x1 hitbox
        this.setInvulnerable(true); // lore-accurate: not meant to be punched down; gate its
                                     // defeat behind the exit-portal / boss flow instead.
    }

    public static List<HollowCoreEntity> getActiveCores() {
        return Collections.unmodifiableList(ACTIVE_CORES);
    }

    @Override
    public void onAddedToWorld() {
        super.onAddedToWorld();
        if (!this.getWorld().isClient) {
            ACTIVE_CORES.add(this);
        }
    }

    @Override
    public void onRemoved() {
        super.onRemoved();
        ACTIVE_CORES.remove(this);
    }

    @Override
    protected void initDataTracker() {
        this.dataTracker.startTracking(CURRENT_RADIUS, 2.0F);
    }

    public float getCurrentRadius() {
        return this.dataTracker.get(CURRENT_RADIUS);
    }

    public double getEtherDensity() {
        return etherDensity;
    }

    public void setGrowthTickInterval(int ticks) {
        this.growthTickInterval = Math.max(1, ticks);
    }

    public void setTargetRadius(double radius) {
        this.targetRadius = Math.max(this.getCurrentRadius(), radius);
    }

    // ------------------------------------------------------------------
    // Tick
    // ------------------------------------------------------------------

    @Override
    public void tick() {
        super.tick();
        if (this.getWorld().isClient) {
            return; // client only ever reads CURRENT_RADIUS for rendering; no logic here
        }

        // PERFORMANCE FILTER (spec #2): if there's truly nothing to do this tick, bail out early.
        boolean stillGrowing = this.getCurrentRadius() < targetRadius;
        boolean queueHasWork = !devourQueue.isEmpty();
        if (!stillGrowing && !queueHasWork) {
            tickItemAbsorption(); // still worth checking for item absorption even at rest
            return;
        }

        if (stillGrowing) {
            tickGrowth();
        }
        if (queueHasWork) {
            tickDevourQueue();
        }
        tickItemAbsorption();
    }

    /** Advances the visual/logical radius by growthStep every growthTickInterval ticks. */
    private void tickGrowth() {
        growthTickCounter++;
        if (growthTickCounter < growthTickInterval) {
            return;
        }
        growthTickCounter = 0;

        float newRadius = (float) Math.min(this.getCurrentRadius() + growthStep, targetRadius);
        this.dataTracker.set(CURRENT_RADIUS, newRadius);

        int newShell = (int) Math.floor(newRadius);
        if (newShell > lastScannedShellRadius) {
            enqueueShell(lastScannedShellRadius, newShell);
            lastScannedShellRadius = newShell;
        }
    }

    /**
     * BENTUK KAWAH (smooth rounded crater): only scans the thin spherical *shell* between the
     * previous and new radius -- never the whole sphere volume -- so growth cost stays bounded
     * as the dome gets large. All distance comparisons use squared distance (no Math.sqrt()).
     */
    private void enqueueShell(int fromRadius, int toRadius) {
        BlockPos center = this.getBlockPos();
        int r = toRadius;
        long rSq = (long) r * r;
        long fromSq = (long) fromRadius * fromRadius;

        for (int x = -r; x <= r; x++) {
            long xSq = (long) x * x;
            if (xSq > rSq) continue;
            for (int y = -r; y <= r; y++) {
                long xySq = xSq + (long) y * y;
                if (xySq > rSq) continue;
                for (int z = -r; z <= r; z++) {
                    long distSq = xySq + (long) z * z; // squared distance, deliberately no sqrt()
                    if (distSq > rSq || distSq < fromSq) continue; // keep only the new shell
                    devourQueue.add(center.add(x, y, z));
                }
            }
        }
    }

    /**
     * ANTI-LAG METHOD: pulls at most MAX_BLOCKS_PER_TICK positions off the queue per tick.
     * Skips air outright (performance filter) and skips bedrock (blacklist), and clears
     * everything else to air with block-update flag 2 (NOTIFY_LISTENERS) only -- this still
     * pushes the change to clients for rendering, but suppresses NOTIFY_NEIGHBORS (flag 1),
     * so we don't trigger cascades of redstone/fluid/fence-connection updates on neighbors
     * while mass-clearing terrain.
     */
    private void tickDevourQueue() {
        ServerWorld world = (ServerWorld) this.getWorld();
        int processed = 0;

        while (processed < MAX_BLOCKS_PER_TICK && !devourQueue.isEmpty()) {
            BlockPos pos = devourQueue.poll();
            BlockState state = world.getBlockState(pos);

            if (state.isAir()) {
                continue; // PERFORMANCE FILTER: nothing to do, don't count it against the budget
            }
            if (state.isOf(Blocks.BEDROCK)) {
                continue; // BLACKLIST: bedrock is never removed
            }

            world.setBlockState(pos, Blocks.AIR.getDefaultState(), Block.NOTIFY_LISTENERS); // flag 2
            processed++;
        }
    }

    /**
     * ITEM DEVOURING GROWTH (spec #5): every ITEM_SCAN_INTERVAL_TICKS, count item entities
     * inside the current radius. Once the total count crosses ITEM_COUNT_THRESHOLD, discard
     * them all (itemEntity.discard(), cheaper than killing/dropping) and bump the target
     * radius (and etherDensity) by 1.
     */
    private void tickItemAbsorption() {
        if (++itemScanCounter < ITEM_SCAN_INTERVAL_TICKS) {
            return;
        }
        itemScanCounter = 0;

        double radius = this.getCurrentRadius();
        if (radius < 1.0D) {
            return;
        }

        Box scanBox = this.getBoundingBox().expand(radius);
        List<ItemEntity> items = this.getWorld().getEntitiesByClass(ItemEntity.class, scanBox, ItemEntity::isAlive);
        if (items.isEmpty()) {
            return;
        }

        int totalCount = 0;
        for (ItemEntity item : items) {
            totalCount += item.getStack().getCount();
        }

        if (totalCount >= ITEM_COUNT_THRESHOLD) {
            for (ItemEntity item : items) {
                item.discard();
            }
            this.etherDensity += 1.0D;
            this.targetRadius += 1.0D;
        }
    }

    // ------------------------------------------------------------------
    // Persistence / networking plumbing
    // ------------------------------------------------------------------

    @Override
    protected void readCustomDataFromNbt(NbtCompound nbt) {
        this.dataTracker.set(CURRENT_RADIUS, nbt.getFloat("CurrentRadius"));
        this.targetRadius = nbt.getDouble("TargetRadius");
        this.etherDensity = nbt.getDouble("EtherDensity");
        this.lastScannedShellRadius = nbt.getInt("LastScannedShell");
        this.growthTickInterval = Math.max(1, nbt.getInt("GrowthTickInterval"));
        // Note: the in-flight devourQueue is intentionally NOT persisted (it can be large and is
        // fully rebuilt on the next shell boundary); on reload we simply re-scan the current shell.
    }

    @Override
    protected void writeCustomDataToNbt(NbtCompound nbt) {
        nbt.putFloat("CurrentRadius", this.getCurrentRadius());
        nbt.putDouble("TargetRadius", this.targetRadius);
        nbt.putDouble("EtherDensity", this.etherDensity);
        nbt.putInt("LastScannedShell", this.lastScannedShellRadius);
        nbt.putInt("GrowthTickInterval", this.growthTickInterval);
    }

    @Override
    public EntitySpawnS2CPacket createSpawnPacket() {
        return new EntitySpawnS2CPacket(this);
    }

    /** Convenience for ModCommands: is this player currently allowed to command this core? */
    public boolean canBeManagedBy(ServerPlayerEntity player) {
        return player.hasPermissionLevel(2);
    }
}
