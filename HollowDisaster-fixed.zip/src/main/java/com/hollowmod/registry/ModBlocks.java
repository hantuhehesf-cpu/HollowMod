package com.hollowmod.registry;

import com.hollowmod.HollowMod;
import com.hollowmod.block.HollowExitPortalBlock;
import com.hollowmod.block.ObservationPillarBlock;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.fabricmc.fabric.api.object.builder.v1.block.FabricBlockSettings;
import net.minecraft.block.Block;
import net.minecraft.block.MapColor;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.sound.BlockSoundGroup;
import net.minecraft.util.Identifier;

public final class ModBlocks {

    public static final Block HOLLOW_EXIT_PORTAL = new HollowExitPortalBlock(
            FabricBlockSettings.create()
                    .mapColor(MapColor.BLACK)
                    .luminance(state -> 12)
                    .noCollision()
                    .strength(-1.0F, 3600000.0F) // unbreakable by normal means, like a portal frame
                    .sounds(BlockSoundGroup.AMETHYST_CLUSTER));

    public static final Item HOLLOW_EXIT_PORTAL_ITEM = new BlockItem(
            HOLLOW_EXIT_PORTAL,
            new FabricItemSettings());

    public static final Block OBSERVATION_PILLAR = new ObservationPillarBlock(
            FabricBlockSettings.create()
                    .mapColor(MapColor.BLACK)
                    .luminance(state -> state.get(ObservationPillarBlock.ACTIVE) ? 12 : 3)
                    .strength(3.0F, 6.0F)
                    .sounds(BlockSoundGroup.AMETHYST_BLOCK));

    public static final Item OBSERVATION_PILLAR_ITEM = new BlockItem(
            OBSERVATION_PILLAR,
            new FabricItemSettings());

    public static void register() {
        Registry.register(Registries.BLOCK, new Identifier(HollowMod.MOD_ID, "observation_pillar"), OBSERVATION_PILLAR);
        Registry.register(Registries.ITEM, new Identifier(HollowMod.MOD_ID, "observation_pillar"), OBSERVATION_PILLAR_ITEM);
        Registry.register(Registries.BLOCK, new Identifier(HollowMod.MOD_ID, "hollow_exit_portal"), HOLLOW_EXIT_PORTAL);
        Registry.register(Registries.ITEM, new Identifier(HollowMod.MOD_ID, "hollow_exit_portal"), HOLLOW_EXIT_PORTAL_ITEM);
    }

    private ModBlocks() {
    }
}
