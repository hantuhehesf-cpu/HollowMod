package com.hollowmod.registry;

import com.hollowmod.HollowMod;
import net.fabricmc.fabric.api.itemgroup.v1.FabricItemGroup;
import net.minecraft.item.ItemGroup;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

/**
 * A dedicated creative tab, rather than folding these into a vanilla one -- this is also the
 * natural home for the v1.2 items (Zenless Limit Gauge, Ether Radiation Counter) once they exist.
 */
public final class ModItemGroups {

    public static final ItemGroup HOLLOW_MOD_GROUP = Registry.register(
            Registries.ITEM_GROUP,
            new Identifier(HollowMod.MOD_ID, "hollow_mod"),
            FabricItemGroup.builder()
                    .displayName(Text.translatable("itemGroup.hollowmod.hollow_mod"))
                    .icon(() -> new ItemStack(ModItems.HOLLOW_CORE_SPAWNER))
                    .entries((displayContext, entries) -> {
                        entries.add(ModItems.HOLLOW_CORE_SPAWNER);
                        entries.add(ModBlocks.HOLLOW_EXIT_PORTAL_ITEM);
                    })
                    .build());

    public static void register() {
        // triggers the static init above
    }

    private ModItemGroups() {
    }
}
