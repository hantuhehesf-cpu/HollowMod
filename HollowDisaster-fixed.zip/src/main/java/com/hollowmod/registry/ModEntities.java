package com.hollowmod.registry;

import com.hollowmod.HollowMod;
import com.hollowmod.entity.EtherealEntity;
import com.hollowmod.entity.HollowCoreEntity;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricDefaultAttributeRegistry;
import net.fabricmc.fabric.api.object.builder.v1.entity.FabricEntityTypeBuilder;
import net.minecraft.entity.EntityDimensions;
import net.minecraft.entity.EntityType;
import net.minecraft.entity.SpawnGroup;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public final class ModEntities {

    /**
     * SpawnGroup.MISC keeps this out of vanilla mob-cap/despawn-radius logic that assumes a
     * living creature. Hitbox fixed at 1x1 per spec ("hemat kalkulasi tabrakan"), independent of
     * the huge *visual* dome the renderer draws around it.
     */
    public static final EntityType<HollowCoreEntity> HOLLOW_CORE_ENTITY = Registry.register(
            Registries.ENTITY_TYPE,
            new Identifier(HollowMod.MOD_ID, "hollow_core"),
            FabricEntityTypeBuilder.create(SpawnGroup.MISC, HollowCoreEntity::new)
                    .dimensions(EntityDimensions.fixed(1.0F, 1.0F))
                    .trackRangeBlocks(320) // dome can be visible from far away; keep it tracked
                    .trackedUpdateRate(40) // radius changes slowly; no need for frequent packets
                    .build());

    public static final EntityType<EtherealEntity> ETHEREAL_ENTITY = Registry.register(
            Registries.ENTITY_TYPE,
            new Identifier(HollowMod.MOD_ID, "ethereal_entity"),
            FabricEntityTypeBuilder.create(SpawnGroup.MONSTER, EtherealEntity::new)
                    .dimensions(EntityDimensions.fixed(0.6F, 1.95F))
                    .trackRangeBlocks(64)
                    .build());

    public static void register() {
        FabricDefaultAttributeRegistry.register(ETHEREAL_ENTITY, EtherealEntity.createEtherealAttributes());
    }

    private ModEntities() {
    }
}
