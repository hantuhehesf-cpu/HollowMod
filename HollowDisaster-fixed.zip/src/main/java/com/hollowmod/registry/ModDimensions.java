package com.hollowmod.registry;

import com.hollowmod.HollowMod;
import net.minecraft.registry.RegistryKey;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.util.Identifier;
import net.minecraft.world.World;
import net.minecraft.world.dimension.DimensionType;

/**
 * The actual dimension is entirely data-driven (see src/main/resources/data/hollowmod/...),
 * matching vanilla's own approach for the Nether/End. These RegistryKeys are just handles Java
 * code uses to look the dimension up (server.getWorld(HOLLOW_DIMENSION_KEY)) and to teleport
 * players into/out of it.
 */
public final class ModDimensions {

    public static final RegistryKey<World> HOLLOW_DIMENSION_KEY = RegistryKey.of(
            RegistryKeys.WORLD,
            new Identifier(HollowMod.MOD_ID, "hollow_dimension"));

    public static final RegistryKey<DimensionType> HOLLOW_DIMENSION_TYPE_KEY = RegistryKey.of(
            RegistryKeys.DIMENSION_TYPE,
            new Identifier(HollowMod.MOD_ID, "hollow_dimension_type"));

    /** Radius (in blocks) of the world border enforced inside the Hollow dimension. Spec: ~1000x1000. */
    public static final double HOLLOW_BORDER_SIZE = 1000.0D;

    private ModDimensions() {
    }
}
