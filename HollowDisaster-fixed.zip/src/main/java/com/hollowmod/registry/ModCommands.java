package com.hollowmod.registry;

import com.hollowmod.entity.HollowCoreEntity;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.command.CommandRegistryAccess;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

public final class ModCommands {

    public static void register() {
        CommandRegistrationCallback.EVENT.register(ModCommands::onRegisterCommands);
    }

    private static void onRegisterCommands(com.mojang.brigadier.CommandDispatcher<ServerCommandSource> dispatcher,
                                            CommandRegistryAccess registryAccess,
                                            net.minecraft.server.command.CommandManager.RegistrationEnvironment environment) {
        dispatcher.register(CommandManager.literal("hollow")
                .requires(source -> source.hasPermissionLevel(2))
                .then(CommandManager.literal("speed")
                        .then(CommandManager.argument("tick", IntegerArgumentType.integer(1, 6000))
                                .executes(ModCommands::executeSpeed)))
                .then(CommandManager.literal("radius")
                        .then(CommandManager.argument("target", IntegerArgumentType.integer(1, 128))
                                .executes(ModCommands::executeRadius)))
                .then(CommandManager.literal("setsize")
                        .then(CommandManager.argument("size", IntegerArgumentType.integer(0, 128))
                                .executes(ModCommands::executeSetSize)))
                .then(CommandManager.literal("activity")
                        .then(CommandManager.argument("value", IntegerArgumentType.integer(0, 100))
                                .executes(ModCommands::executeSetActivity)))
                .then(CommandManager.literal("gauge")
                        .then(CommandManager.argument("value", IntegerArgumentType.integer(0, 100))
                                .executes(ModCommands::executeSetGauge)))
                .then(CommandManager.literal("status")
                        .executes(ModCommands::executeStatus))
                .then(MazeCommands.build())
                .then(CommandManager.literal("remove")
                        .executes(ModCommands::executeRemoveNearest)
                        .then(CommandManager.literal("all")
                                .executes(ModCommands::executeRemoveAll))));
    }

    /** Sets growth-tick-interval (ticks between +1 radius step) on every active core in this world. */
    private static int executeSpeed(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        int tick = IntegerArgumentType.getInteger(ctx, "tick");
        ServerCommandSource source = ctx.getSource();

        int updated = 0;
        for (HollowCoreEntity core : HollowCoreEntity.getActiveCores()) {
            if (core.getWorld() == source.getWorld()) {
                core.setGrowthTickInterval(tick);
                updated++;
            }
        }

        final int finalUpdated = updated;
        if (updated == 0) {
            source.sendError(Text.literal("No active Hollow core found in this dimension."));
        } else {
            source.sendFeedback(() -> Text.literal(
                    "Hollow growth interval set to " + tick + " tick(s) for " + finalUpdated + " core(s)."), true);
        }
        return updated;
    }

    /** Sets the target radius (final size the dome grows toward) on every active core in this world. */
    private static int executeRadius(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        int target = IntegerArgumentType.getInteger(ctx, "target");
        ServerCommandSource source = ctx.getSource();

        int updated = 0;
        for (HollowCoreEntity core : HollowCoreEntity.getActiveCores()) {
            if (core.getWorld() == source.getWorld()) {
                core.setTargetRadius(target);
                updated++;
            }
        }

        final int finalUpdated = updated;
        if (updated == 0) {
            source.sendError(Text.literal("No active Hollow core found in this dimension."));
        } else {
            source.sendFeedback(() -> Text.literal(
                    "Hollow target radius set to " + target + " for " + finalUpdated + " core(s)."), true);
        }
        return updated;
    }

    /**
     * Instantly jumps the radius to the given size (testing shortcut), unlike /hollow radius
     * which only moves the ceiling that the normal gradual growth is climbing toward.
     */
    private static int executeSetSize(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        int size = IntegerArgumentType.getInteger(ctx, "size");
        ServerCommandSource source = ctx.getSource();

        int updated = 0;
        for (HollowCoreEntity core : HollowCoreEntity.getActiveCores()) {
            if (core.getWorld() == source.getWorld()) {
                core.setSizeInstant(size);
                updated++;
            }
        }

        final int finalUpdated = updated;
        if (updated == 0) {
            source.sendError(Text.literal("No active Hollow core found in this dimension."));
        } else {
            source.sendFeedback(() -> Text.literal(
                    "Hollow size instantly set to " + size + " for " + finalUpdated + " core(s)."), true);
        }
        return updated;
    }

    /** Testing helper: directly sets Ether Activity (System 1), no need to wait for natural
     *  feeding/decay to see a particular value/level in action. */
    private static int executeSetActivity(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        int value = IntegerArgumentType.getInteger(ctx, "value");
        ServerCommandSource source = ctx.getSource();

        int updated = 0;
        for (HollowCoreEntity core : HollowCoreEntity.getActiveCores()) {
            if (core.getWorld() == source.getWorld()) {
                core.applyEtherActivityDelta(value - core.getEtherActivity());
                updated++;
            }
        }

        final int finalUpdated = updated;
        if (updated == 0) {
            source.sendError(Text.literal("No active Hollow core found in this dimension."));
        } else {
            source.sendFeedback(() -> Text.literal(
                    "Ether Activity set to " + value + "% for " + finalUpdated + " core(s)."), true);
        }
        return updated;
    }

    /** Testing helper: directly sets the Zenless Limit Gauge (System 2), no need to wait ~8-9
     *  hours of real time to see a particular value in action. */
    private static int executeSetGauge(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        int value = IntegerArgumentType.getInteger(ctx, "value");
        ServerCommandSource source = ctx.getSource();

        int updated = 0;
        for (HollowCoreEntity core : HollowCoreEntity.getActiveCores()) {
            if (core.getWorld() == source.getWorld()) {
                core.setZenlessLimitGauge(value);
                updated++;
            }
        }

        final int finalUpdated = updated;
        if (updated == 0) {
            source.sendError(Text.literal("No active Hollow core found in this dimension."));
        } else {
            source.sendFeedback(() -> Text.literal(
                    "Zenless Limit Gauge set to " + value + "% for " + finalUpdated + " core(s)."), true);
        }
        return updated;
    }

    /** No Zenless Limit Gauge item exists yet -- this is a stand-in way to check a core's
     *  current numbers while testing Systems 1/1b/2 in isolation. */
    private static int executeStatus(CommandContext<ServerCommandSource> ctx) {
        ServerCommandSource source = ctx.getSource();

        List<HollowCoreEntity> cores = new ArrayList<>();
        for (HollowCoreEntity core : HollowCoreEntity.getActiveCores()) {
            if (core.getWorld() == source.getWorld()) {
                cores.add(core);
            }
        }

        if (cores.isEmpty()) {
            source.sendError(Text.literal("No active Hollow core found in this dimension."));
            return 0;
        }

        for (HollowCoreEntity core : cores) {
            source.sendFeedback(() -> Text.literal(String.format(
                    "Hollow @ %.0f,%.0f,%.0f -- radius %.1f/%.0f, Ether Activity %.2f%% (level %d), Zenless Limit Gauge %.3f%%, Gen %d, children %d/%d",
                    core.getX(), core.getY(), core.getZ(),
                    core.getCurrentRadius(), core.getTargetRadius(),
                    core.getEtherActivity(), core.getEtherActivityLevel(),
                    core.getZenlessLimitGauge(),
                    core.getGeneration(), core.getChildIds().size(), core.getMaxChildren())), false);
        }
        return cores.size();
    }

    /**
     * Guaranteed-to-work removal that doesn't depend on how vanilla /kill happens to interact
     * with an invulnerable, non-living Entity (verified to be genuinely ambiguous for this
     * exact case rather than assumed) -- discard() always cleanly removes the entity outright.
     * Removes the Hollow core nearest to wherever the command was run from.
     */
    private static int executeRemoveNearest(CommandContext<ServerCommandSource> ctx) {
        ServerCommandSource source = ctx.getSource();
        Vec3d pos = source.getPosition();

        HollowCoreEntity nearest = null;
        double nearestDistSq = Double.MAX_VALUE;
        for (HollowCoreEntity core : HollowCoreEntity.getActiveCores()) {
            if (core.getWorld() != source.getWorld()) {
                continue;
            }
            double distSq = core.getPos().squaredDistanceTo(pos);
            if (distSq < nearestDistSq) {
                nearestDistSq = distSq;
                nearest = core;
            }
        }

        if (nearest == null) {
            source.sendError(Text.literal("No active Hollow core found in this dimension."));
            return 0;
        }

        nearest.discard();
        source.sendFeedback(() -> Text.literal("Removed the nearest Hollow core."), true);
        return 1;
    }

    /** Removes every active Hollow core in the current dimension -- for a clean testing reset. */
    private static int executeRemoveAll(CommandContext<ServerCommandSource> ctx) {
        ServerCommandSource source = ctx.getSource();

        List<HollowCoreEntity> toRemove = new ArrayList<>();
        for (HollowCoreEntity core : HollowCoreEntity.getActiveCores()) {
            if (core.getWorld() == source.getWorld()) {
                toRemove.add(core);
            }
        }

        for (HollowCoreEntity core : toRemove) {
            core.discard();
        }

        int removed = toRemove.size();
        if (removed == 0) {
            source.sendError(Text.literal("No active Hollow core found in this dimension."));
        } else {
            source.sendFeedback(() -> Text.literal("Removed " + removed + " Hollow core(s)."), true);
        }
        return removed;
    }

    private ModCommands() {
    }
}
