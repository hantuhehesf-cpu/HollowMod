package com.hollowmod.registry;

import com.hollowmod.entity.HollowCoreEntity;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.command.CommandRegistryAccess;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.text.Text;

public final class ModCommands {

    public static void register() {
        CommandRegistrationCallback.EVENT.register(ModCommands::onRegisterCommands);
    }

    private static void onRegisterCommands(com.mojang.brigadier.CommandDispatcher<ServerCommandSource> dispatcher,
                                            CommandRegistryAccess registryAccess,
                                            net.minecraft.server.command.CommandManager.RegistrationEnvironment environment) {
        dispatcher.register(CommandManager.literal("hollow")
                .requires(source -> source.hasPermissionLevel(2))
                .then(CommandManager.literal("speed")
                        .then(CommandManager.argument("tick", IntegerArgumentType.integer(1, 6000))
                                .executes(ModCommands::executeSpeed)))
                .then(CommandManager.literal("radius")
                        .then(CommandManager.argument("target", IntegerArgumentType.integer(1, 128))
                                .executes(ModCommands::executeRadius))));
    }

    /** Sets growth-tick-interval (ticks between +1 radius step) on every active core in this world. */
    private static int executeSpeed(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        int tick = IntegerArgumentType.getInteger(ctx, "tick");
        ServerCommandSource source = ctx.getSource();

        int updated = 0;
        for (HollowCoreEntity core : HollowCoreEntity.getActiveCores()) {
            if (core.getWorld() == source.getWorld()) {
                core.setGrowthTickInterval(tick);
                updated++;
            }
        }

        final int finalUpdated = updated;
        if (updated == 0) {
            source.sendError(Text.literal("No active Hollow core found in this dimension."));
        } else {
            source.sendFeedback(() -> Text.literal(
                    "Hollow growth interval set to " + tick + " tick(s) for " + finalUpdated + " core(s)."), true);
        }
        return updated;
    }

    /** Sets the target radius (final size the dome grows toward) on every active core in this world. */
    private static int executeRadius(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        int target = IntegerArgumentType.getInteger(ctx, "target");
        ServerCommandSource source = ctx.getSource();

        int updated = 0;
        for (HollowCoreEntity core : HollowCoreEntity.getActiveCores()) {
            if (core.getWorld() == source.getWorld()) {
                core.setTargetRadius(target);
                updated++;
            }
        }

        final int finalUpdated = updated;
        if (updated == 0) {
            source.sendError(Text.literal("No active Hollow core found in this dimension."));
        } else {
            source.sendFeedback(() -> Text.literal(
                    "Hollow target radius set to " + target + " for " + finalUpdated + " core(s)."), true);
        }
        return updated;
    }

    private ModCommands() {
    }
}
