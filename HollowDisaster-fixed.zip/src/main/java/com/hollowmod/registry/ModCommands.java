package com.hollowmod.registry;

import com.hollowmod.entity.HollowCoreEntity;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.command.CommandRegistryAccess;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.text.Text;
import net.minecraft.util.math.Vec3d;

import java.util.ArrayList;
import java.util.List;

public final class ModCommands {

    public static void register() {
        CommandRegistrationCallback.EVENT.register(ModCommands::onRegisterCommands);
    }

    private static void onRegisterCommands(com.mojang.brigadier.CommandDispatcher<ServerCommandSource> dispatcher,
                                            CommandRegistryAccess registryAccess,
                                            net.minecraft.server.command.CommandManager.RegistrationEnvironment environment) {
        dispatcher.register(CommandManager.literal("hollow")
                .requires(source -> source.hasPermissionLevel(2))
                .then(CommandManager.literal("speed")
                        .then(CommandManager.argument("tick", IntegerArgumentType.integer(1, 6000))
                                .executes(ModCommands::executeSpeed)))
                .then(CommandManager.literal("radius")
                        .then(CommandManager.argument("target", IntegerArgumentType.integer(1, 128))
                                .executes(ModCommands::executeRadius)))
                .then(CommandManager.literal("setsize")
                        .then(CommandManager.argument("size", IntegerArgumentType.integer(0, 128))
                                .executes(ModCommands::executeSetSize)))
                .then(CommandManager.literal("remove")
                        .executes(ModCommands::executeRemoveNearest)
                        .then(CommandManager.literal("all")
                                .executes(ModCommands::executeRemoveAll))));
    }

    /** Sets growth-tick-interval (ticks between +1 radius step) on every active core in this world. */
    private static int executeSpeed(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        int tick = IntegerArgumentType.getInteger(ctx, "tick");
        ServerCommandSource source = ctx.getSource();

        int updated = 0;
        for (HollowCoreEntity core : HollowCoreEntity.getActiveCores()) {
            if (core.getWorld() == source.getWorld()) {
                core.setGrowthTickInterval(tick);
                updated++;
            }
        }

        final int finalUpdated = updated;
        if (updated == 0) {
            source.sendError(Text.literal("No active Hollow core found in this dimension."));
        } else {
            source.sendFeedback(() -> Text.literal(
                    "Hollow growth interval set to " + tick + " tick(s) for " + finalUpdated + " core(s)."), true);
        }
        return updated;
    }

    /** Sets the target radius (final size the dome grows toward) on every active core in this world. */
    private static int executeRadius(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        int target = IntegerArgumentType.getInteger(ctx, "target");
        ServerCommandSource source = ctx.getSource();

        int updated = 0;
        for (HollowCoreEntity core : HollowCoreEntity.getActiveCores()) {
            if (core.getWorld() == source.getWorld()) {
                core.setTargetRadius(target);
                updated++;
            }
        }

        final int finalUpdated = updated;
        if (updated == 0) {
            source.sendError(Text.literal("No active Hollow core found in this dimension."));
        } else {
            source.sendFeedback(() -> Text.literal(
                    "Hollow target radius set to " + target + " for " + finalUpdated + " core(s)."), true);
        }
        return updated;
    }

    private ModCommands() {
    }

    /**
     * Instantly jumps the radius to the given size (testing shortcut), unlike /hollow radius
     * which only moves the ceiling that the normal gradual growth is climbing toward.
     */
    private static int executeSetSize(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        int size = IntegerArgumentType.getInteger(ctx, "size");
        ServerCommandSource source = ctx.getSource();

        int updated = 0;
        for (HollowCoreEntity core : HollowCoreEntity.getActiveCores()) {
            if (core.getWorld() == source.getWorld()) {
                core.setSizeInstant(size);
                updated++;
            }
        }

        final int finalUpdated = updated;
        if (updated == 0) {
            source.sendError(Text.literal("No active Hollow core found in this dimension."));
        } else {
            source.sendFeedback(() -> Text.literal(
                    "Hollow size instantly set to " + size + " for " + finalUpdated + " core(s)."), true);
        }
        return updated;
    }

    /**
     * Guaranteed-to-work removal that doesn't depend on how vanilla /kill happens to interact
     * with an invulnerable, non-living Entity (verified to be genuinely ambiguous for this
     * exact case rather than assumed) -- discard() always cleanly removes the entity outright.
     * Removes the Hollow core nearest to wherever the command was run from.
     */
    private static int executeRemoveNearest(CommandContext<ServerCommandSource> ctx) {
        ServerCommandSource source = ctx.getSource();
        Vec3d pos = source.getPosition();

        HollowCoreEntity nearest = null;
        double nearestDistSq = Double.MAX_VALUE;
        for (HollowCoreEntity core : HollowCoreEntity.getActiveCores()) {
            if (core.getWorld() != source.getWorld()) {
                continue;
            }
            double distSq = core.getPos().squaredDistanceTo(pos);
            if (distSq < nearestDistSq) {
                nearestDistSq = distSq;
                nearest = core;
            }
        }

        if (nearest == null) {
            source.sendError(Text.literal("No active Hollow core found in this dimension."));
            return 0;
        }

        nearest.discard();
        source.sendFeedback(() -> Text.literal("Removed the nearest Hollow core."), true);
        return 1;
    }

    /** Removes every active Hollow core in the current dimension -- for a clean testing reset. */
    private static int executeRemoveAll(CommandContext<ServerCommandSource> ctx) {
        ServerCommandSource source = ctx.getSource();

        // Defensive copy: discard() removes the core from ACTIVE_CORES via ServerEntityEvents
        // as a side effect, and iterating a list while it's being mutated underneath is exactly
        // the class of bug this project already got bitten by once (see HollowDimensionEvents).
        List<HollowCoreEntity> toRemove = new ArrayList<>();
        for (HollowCoreEntity core : HollowCoreEntity.getActiveCores()) {
            if (core.getWorld() == source.getWorld()) {
                toRemove.add(core);
            }
        }

        for (HollowCoreEntity core : toRemove) {
            core.discard();
        }

        int removed = toRemove.size();
        if (removed == 0) {
            source.sendError(Text.literal("No active Hollow core found in this dimension."));
        } else {
            source.sendFeedback(() -> Text.literal("Removed " + removed + " Hollow core(s)."), true);
        }
        return removed;
    }
}
