package com.hollowmod.registry;

import com.hollowmod.prefab.DistrictDemo;
import com.hollowmod.prefab.Prefab;
import com.hollowmod.prefab.PrefabPlacer;
import com.hollowmod.prefab.PrefabRegistry;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.brigadier.suggestion.SuggestionProvider;
import net.minecraft.command.CommandSource;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;
import net.minecraft.util.BlockMirror;
import net.minecraft.util.BlockRotation;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.MathHelper;

import java.util.List;

/**
 * /hollow prefab ...   (op level 2 like the rest of /hollow)
 *   list                          show every prefab
 *   place <id> [rotation] [mirror] paste one in front of you (rotation 0/90/180/270, mirror none/left_right/front_back)
 *   reload                        re-read config/hollowmod/prefabs
 *   demo                          build a 3x3 demo city in front of you
 *   shiftdemo                     run the space-shift demo on that city
 *   cancel                        stop everything that is still being placed
 */
public final class PrefabCommands {

    private static final SuggestionProvider<ServerCommandSource> ID_SUGGESTIONS =
            (ctx, builder) -> CommandSource.suggestMatching(PrefabRegistry.ids(), builder);
    private static final SuggestionProvider<ServerCommandSource> ROTATION_SUGGESTIONS =
            (ctx, builder) -> CommandSource.suggestMatching(List.of("0", "90", "180", "270"), builder);
    private static final SuggestionProvider<ServerCommandSource> MIRROR_SUGGESTIONS =
            (ctx, builder) -> CommandSource.suggestMatching(List.of("none", "left_right", "front_back"), builder);

    public static LiteralArgumentBuilder<ServerCommandSource> build() {
        return CommandManager.literal("prefab")
                .then(CommandManager.literal("list").executes(PrefabCommands::list))
                .then(CommandManager.literal("reload").executes(PrefabCommands::reload))
                .then(CommandManager.literal("cancel").executes(PrefabCommands::cancel))
                .then(CommandManager.literal("demo").executes(ctx -> DistrictDemo.build(ctx.getSource())))
                .then(CommandManager.literal("shiftdemo").executes(ctx -> DistrictDemo.shift(ctx.getSource())))
                .then(CommandManager.literal("place")
                        .then(CommandManager.argument("id", StringArgumentType.word())
                                .suggests(ID_SUGGESTIONS)
                                .executes(ctx -> place(ctx, "0", "none"))
                                .then(CommandManager.argument("rotation", StringArgumentType.word())
                                        .suggests(ROTATION_SUGGESTIONS)
                                        .executes(ctx -> place(ctx, StringArgumentType.getString(ctx, "rotation"), "none"))
                                        .then(CommandManager.argument("mirror", StringArgumentType.word())
                                                .suggests(MIRROR_SUGGESTIONS)
                                                .executes(ctx -> place(ctx,
                                                        StringArgumentType.getString(ctx, "rotation"),
                                                        StringArgumentType.getString(ctx, "mirror")))))));
    }

    private static int list(CommandContext<ServerCommandSource> ctx) {
        ServerCommandSource src = ctx.getSource();
        List<Prefab> all = List.copyOf(PrefabRegistry.all());
        src.sendFeedback(() -> Text.literal("Prefabs (" + all.size() + "):"), false);
        for (Prefab p : all) {
            String line = " " + p.id + "  " + p.sizeX + "x" + p.sizeY + "x" + p.sizeZ
                    + "  roads:" + p.connectionLetters()
                    + "  " + p.tags
                    + (p.groundLayer ? "  (has ground)" : "")
                    + "  [" + p.source + "]";
            src.sendFeedback(() -> Text.literal(line), false);
        }
        src.sendFeedback(() -> Text.literal("Your own files go in: " + PrefabRegistry.folder()), false);
        return all.size();
    }

    private static int reload(CommandContext<ServerCommandSource> ctx) {
        int count = PrefabRegistry.reload();
        ctx.getSource().sendFeedback(() -> Text.literal("Prefabs reloaded: " + count + " available."), true);
        return count;
    }

    private static int cancel(CommandContext<ServerCommandSource> ctx) {
        PrefabPlacer.cancelAll();
        DistrictDemo.reset();
        ctx.getSource().sendFeedback(() -> Text.literal("Prefab placing and shift demo cancelled."), true);
        return 1;
    }

    private static BlockRotation parseRotation(String s) {
        return switch (s.toLowerCase()) {
            case "0", "none" -> BlockRotation.NONE;
            case "90" -> BlockRotation.CLOCKWISE_90;
            case "180" -> BlockRotation.CLOCKWISE_180;
            case "270" -> BlockRotation.COUNTERCLOCKWISE_90;
            default -> null;
        };
    }

    private static BlockMirror parseMirror(String s) {
        return switch (s.toLowerCase()) {
            case "none" -> BlockMirror.NONE;
            case "left_right" -> BlockMirror.LEFT_RIGHT;
            case "front_back" -> BlockMirror.FRONT_BACK;
            default -> null;
        };
    }

    private static int place(CommandContext<ServerCommandSource> ctx, String rotationText, String mirrorText)
            throws CommandSyntaxException {
        ServerCommandSource src = ctx.getSource();
        ServerPlayerEntity player = src.getPlayerOrThrow();
        String id = StringArgumentType.getString(ctx, "id");

        Prefab prefab = PrefabRegistry.get(id);
        if (prefab == null) {
            src.sendError(Text.literal("No prefab called '" + id + "'. Use /hollow prefab list"));
            return 0;
        }
        BlockRotation rotation = parseRotation(rotationText);
        if (rotation == null) {
            src.sendError(Text.literal("Rotation must be 0, 90, 180 or 270."));
            return 0;
        }
        BlockMirror mirror = parseMirror(mirrorText);
        if (mirror == null) {
            src.sendError(Text.literal("Mirror must be none, left_right or front_back."));
            return 0;
        }

        // Put the piece in front of the player. Pieces with their own ground replace the ground surface,
        // other pieces sit on the first block above the ground.
        Direction dir = player.getHorizontalFacing();
        int footX = prefab.footprintX(rotation);
        int footZ = prefab.footprintZ(rotation);
        double reach = 3.0 + (Math.abs(dir.getOffsetX()) * footX + Math.abs(dir.getOffsetZ()) * footZ) / 2.0;
        double centerX = player.getX() + dir.getOffsetX() * reach;
        double centerZ = player.getZ() + dir.getOffsetZ() * reach;
        int minX = MathHelper.floor(centerX - footX / 2.0);
        int minZ = MathHelper.floor(centerZ - footZ / 2.0);
        int y = player.getBlockPos().getY() + (prefab.groundLayer ? -1 : 0);

        long seed = player.getWorld().getTime() ^ ((long) minX * 31L) ^ minZ;
        PrefabPlacer.enqueue(src.getWorld(), prefab, new BlockPos(minX, y, minZ), rotation, mirror,
                prefab.groundLayer, 1.0f, seed, false,
                () -> player.sendMessage(Text.literal("Finished placing " + prefab.id), true));
        src.sendFeedback(() -> Text.literal("Placing " + prefab.id + " (" + footX + "x" + prefab.sizeY + "x" + footZ + ")..."), false);
        return 1;
    }

    private PrefabCommands() {
    }
}
