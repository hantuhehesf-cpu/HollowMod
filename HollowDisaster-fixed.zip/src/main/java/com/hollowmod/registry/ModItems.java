package com.hollowmod.registry;

import com.hollowmod.HollowMod;
import com.hollowmod.item.HollowCoreSpawnerItem;
import net.fabricmc.fabric.api.item.v1.FabricItemSettings;
import net.minecraft.item.Item;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public final class ModItems {

    public static final Item HOLLOW_CORE_SPAWNER = new HollowCoreSpawnerItem(
            new FabricItemSettings().maxCount(1));

    public static void register() {
        Registry.register(Registries.ITEM, new Identifier(HollowMod.MOD_ID, "hollow_core_spawner"), HOLLOW_CORE_SPAWNER);
    }

    private ModItems() {
    }
}
