package com.hollowmod.registry;

import com.hollowmod.maze.MazeConfig;
import com.hollowmod.maze.MazeData;
import com.hollowmod.maze.MazeSystem;
import com.hollowmod.state.HollowWorldState;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.brigadier.exceptions.CommandSyntaxException;
import net.minecraft.server.command.CommandManager;
import net.minecraft.server.command.ServerCommandSource;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.MutableText;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.MathHelper;

import java.util.UUID;

/** Debug tools for System 6: /hollow maze map | truth | shift. Op level 2 like the rest of /hollow. */
public final class MazeCommands {

    public static LiteralArgumentBuilder<ServerCommandSource> build() {
        return CommandManager.literal("maze")
                .then(CommandManager.literal("map").executes(ctx -> showMap(ctx, false)))
                .then(CommandManager.literal("truth").executes(ctx -> showMap(ctx, true)))
                .then(CommandManager.literal("shift").executes(MazeCommands::forceShift));
    }

    private static int showMap(CommandContext<ServerCommandSource> ctx, boolean truth) throws CommandSyntaxException {
        ServerCommandSource src = ctx.getSource();
        ServerPlayerEntity player = src.getPlayerOrThrow();
        HollowWorldState hs = HollowWorldState.get(src.getServer());
        UUID id = hs.getCurrentHollow(player.getUuid());
        if (id == null) {
            src.sendError(Text.literal("Kamu tidak sedang berada di dalam Hollow."));
            return 0;
        }
        MazeData m = hs.getMaze(id);
        if (m == null || !m.built) {
            src.sendError(Text.literal("Labirin belum selesai dibangun."));
            return 0;
        }
        BlockPos o = MazeSystem.origin(hs, id, m);
        int px = Math.floorDiv(MathHelper.floor(player.getX()) - o.getX(), MazeConfig.CELL);
        int pz = Math.floorDiv(MathHelper.floor(player.getZ()) - o.getZ(), MazeConfig.CELL);

        java.util.Set<Integer> sensorCols = new java.util.HashSet<>();
        for (long key : m.sensors) {
            BlockPos sp = BlockPos.fromLong(key);
            int sx = Math.floorDiv(sp.getX() - o.getX(), MazeConfig.CELL);
            int sz = Math.floorDiv(sp.getZ() - o.getZ(), MazeConfig.CELL);
            if (sx >= 0 && sz >= 0 && sx < MazeConfig.NX && sz < MazeConfig.NZ) {
                sensorCols.add(MazeConfig.col(sx, sz));
            }
        }

        for (int z = 0; z < MazeConfig.NZ; z++) {
            MutableText row = Text.empty();
            for (int x = 0; x < MazeConfig.NX; x++) {
                int c = MazeConfig.col(x, z);
                Formatting color;
                boolean known = truth || m.scan[c] != MazeConfig.SCAN_UNKNOWN;
                if (x == px && z == pz) {
                    color = Formatting.RED;
                } else if ((known && isPillar(m, c)) || sensorCols.contains(c)) {
                    color = Formatting.AQUA;
                } else if (c == m.portalCol && (truth || m.scan[c] == MazeConfig.SCAN_PORTAL)) {
                    color = Formatting.GOLD;
                } else if (!known) {
                    color = Formatting.BLACK;
                } else {
                    color = m.solid[c] != 0 && (truth || m.scan[c] == MazeConfig.SCAN_WALL)
                            ? Formatting.GRAY : Formatting.GREEN;
                }
                row.append(Text.literal("\u25A0").formatted(color));
            }
            final MutableText line = row;
            src.sendFeedback(() -> line, false);
        }
        src.sendFeedback(() -> Text.literal("Merah=kamu  Emas=portal  Aqua=pillar  Hijau=jalan  Abu=tembok"), false);
        return 1;
    }

    private static boolean isPillar(MazeData m, int c) {
        for (int p : m.pillarCols) {
            if (p == c) {
                return true;
            }
        }
        return false;
    }

    private static int forceShift(CommandContext<ServerCommandSource> ctx) throws CommandSyntaxException {
        ServerCommandSource src = ctx.getSource();
        ServerPlayerEntity player = src.getPlayerOrThrow();
        HollowWorldState hs = HollowWorldState.get(src.getServer());
        UUID id = hs.getCurrentHollow(player.getUuid());
        MazeData m = id == null ? null : hs.getMaze(id);
        if (m == null || !m.built) {
            src.sendError(Text.literal("Tidak ada labirin yang sudah jadi untuk Hollow ini."));
            return 0;
        }
        m.nextShiftTick = 0;
        hs.markDirty();
        src.sendFeedback(() -> Text.literal("Shift dipaksa pada tick berikutnya (kamu harus berada di dalam kotak labirin)."), true);
        return 1;
    }

    private MazeCommands() {
    }
}
