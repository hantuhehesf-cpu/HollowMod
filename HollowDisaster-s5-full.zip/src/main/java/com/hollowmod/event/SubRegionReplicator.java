package com.hollowmod.event;

import com.hollowmod.HollowMod;
import com.hollowmod.registry.ModDimensions;
import com.hollowmod.state.FragmentLog;
import com.hollowmod.state.HollowWorldState;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.minecraft.block.Block;
import net.minecraft.block.BlockState;
import net.minecraft.block.FluidBlock;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.server.world.ServerWorld;
import net.minecraft.util.math.BlockPos;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

/**
 * SYSTEM 5 (fixed): recreates whatever a Hollow eats as floating fragments in its sub-region.
 *
 * Why the old version showed nothing: it only placed a block if that chunk was ALREADY loaded in
 * HollowDimension, and the sub-region sits ~10,000 blocks away, so while you watch the Hollow
 * eat in the Overworld nothing is loaded there and every block was silently dropped.
 *
 * Now: if someone is inside the sub-region and the target chunk is loaded, the block is placed
 * immediately. Otherwise it goes into a persistent, capped backlog (FragmentLog) that is replayed
 * at PLACE_PER_TICK blocks/tick as soon as a player is inside that Hollow's sub-region.
 */
public final class SubRegionReplicator {

    /** Replay budget per server tick (same spirit as the devour time-slicing). */
    private static final int PLACE_PER_TICK = 400;

    public static void register() {
        ServerTickEvents.END_SERVER_TICK.register(SubRegionReplicator::tick);
    }

    /** Called by HollowCoreEntity for every block it eats. relative = eaten pos - Hollow center. */
    public static void onBlockEaten(MinecraftServer server, UUID hollowId, BlockPos relative, BlockState state) {
        if (state.getBlock() instanceof FluidBlock) {
            return; // placed fluid sources would start flowing in the sub-region: skip
        }
        ServerWorld hollowWorld = server.getWorld(ModDimensions.HOLLOW_DIMENSION_KEY);
        if (hollowWorld == null) {
            return;
        }
        HollowWorldState hs = HollowWorldState.get(server);
        BlockPos anchor = HollowWorldState.slotToFragmentAnchor(hs.getOrAssignSlot(hollowId));
        BlockPos target = anchor.add(relative);

        FragmentLog existing = hs.peekFragmentLog(hollowId);
        boolean backlog = existing != null && existing.hasPending();

        if (!backlog && isOccupied(hollowWorld, hs, hollowId)
                && hollowWorld.isChunkLoaded(target.getX() >> 4, target.getZ() >> 4)) {
            place(hollowWorld, target, state);
            return;
        }

        if (hs.getFragmentLog(hollowId).add(relative, state)) {
            hs.markDirty();
        }
    }

    private static boolean isOccupied(ServerWorld hollowWorld, HollowWorldState hs, UUID hollowId) {
        for (ServerPlayerEntity p : hollowWorld.getPlayers()) {
            if (hollowId.equals(hs.getCurrentHollow(p.getUuid()))) {
                return true;
            }
        }
        return false;
    }

    private static void tick(MinecraftServer server) {
        ServerWorld hollowWorld = server.getWorld(ModDimensions.HOLLOW_DIMENSION_KEY);
        if (hollowWorld == null || hollowWorld.getPlayers().isEmpty()) {
            return;
        }
        HollowWorldState hs = HollowWorldState.get(server);

        Set<UUID> hollowsWithPlayers = new HashSet<>();
        for (ServerPlayerEntity p : hollowWorld.getPlayers()) {
            UUID id = hs.getCurrentHollow(p.getUuid());
            if (id != null) {
                hollowsWithPlayers.add(id);
            }
        }

        for (UUID id : hollowsWithPlayers) {
            FragmentLog log = hs.peekFragmentLog(id);
            if (log == null || !log.hasPending()) {
                continue;
            }
            BlockPos anchor = HollowWorldState.slotToFragmentAnchor(hs.getOrAssignSlot(id));
            int budget = PLACE_PER_TICK;
            while (budget-- > 0 && log.hasPending()) {
                long entry = log.next();
                place(hollowWorld, anchor.add(FragmentLog.relativePos(entry)), log.stateOf(entry));
            }
            if (!log.hasPending()) {
                log.reset();
                HollowMod.LOGGER.info("[HollowMod] Sub-region backlog fully replayed for Hollow {}", id);
            }
            hs.markDirty();
        }
    }

    private static void place(ServerWorld world, BlockPos target, BlockState state) {
        if (world.isOutOfHeightLimit(target.getY())) {
            return;
        }
        world.setBlockState(target, state, Block.NOTIFY_LISTENERS);
    }

    private SubRegionReplicator() {
    }
}
